import { lazy, useEffect } from "react";
import { HashRouter, Route, Routes } from "react-router-dom";
import { Layout } from "./components/Layout";
import { StoreProvider, useStore } from "./lib/store";
import { AuthProvider } from "./lib/authStore";
import { AuthGate } from "./components/AuthGate";
import { WizardProvider } from "./components/WizardHost";
import { BADGES } from "./lib/badges";
import { badgeStats } from "./lib/selectors";

// Dashboard chargé immédiatement, les autres pages à la demande.
import Dashboard from "./pages/Dashboard";
const Training = lazy(() => import("./pages/Training"));
const Journal = lazy(() => import("./pages/Journal"));
const Shopping = lazy(() => import("./pages/Shopping"));
const Goals = lazy(() => import("./pages/Goals"));
const Weight = lazy(() => import("./pages/Weight"));
const Stats = lazy(() => import("./pages/Stats"));
const Notes = lazy(() => import("./pages/Notes"));
const SettingsPage = lazy(() => import("./pages/Settings"));
const Calendar = lazy(() => import("./pages/Calendar"));
const Tasks = lazy(() => import("./pages/Tasks"));

/** Applique le thème (clair/sombre + accent) et débloque les badges automatiquement. */
function SystemEffects() {
  const { state, setBadges } = useStore();
  const { theme, accent } = state.settings;

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", theme === "dark");
    root.classList.toggle("light", theme === "light");
    root.style.setProperty("--accent", accent);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", theme === "dark" ? "#08090c" : "#f4f5f8");
  }, [theme, accent]);

  useEffect(() => {
    const st = badgeStats(state);
    const unlocked = BADGES.filter((b) => b.check(state, st)).map((b) => b.id);
    const cur = state.gamification.unlockedBadges;
    if (unlocked.length !== cur.length || unlocked.some((id) => !cur.includes(id))) {
      setBadges(unlocked);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.cardio, state.strength, state.tasks, state.validatedDays, state.gamification.xp]);

  return null;
}

function AppRoutes() {
  return (
    <HashRouter>
      <SystemEffects />
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/entrainement" element={<Training />} />
          <Route path="/journal" element={<Journal />} />
          <Route path="/poids" element={<Weight />} />
          <Route path="/courses" element={<Shopping />} />
          <Route path="/objectifs" element={<Goals />} />
          <Route path="/stats" element={<Stats />} />
          <Route path="/notes" element={<Notes />} />
          <Route path="/parametres" element={<SettingsPage />} />
          {/* Routes secondaires (accessibles depuis le tableau de bord) */}
          <Route path="/calendrier" element={<Calendar />} />
          <Route path="/taches" element={<Tasks />} />
        </Route>
      </Routes>
    </HashRouter>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AuthGate>
        {(user) => (
          <StoreProvider key={user.id} userId={user.id}>
            <WizardProvider>
              <AppRoutes />
            </WizardProvider>
          </StoreProvider>
        )}
      </AuthGate>
    </AuthProvider>
  );
}
