import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type {
  AppState,
  CardioEntry,
  DailyLog,
  ExerciseDef,
  Goal,
  Note,
  Settings,
  ShoppingItem,
  StrengthSession,
  Task,
  TaskStatus,
  WeightEntry,
} from "./types";
import { defaultState, makeStateRepository, templateTasksFor } from "./storage";
import { todayISO, uid } from "./utils";

// ============================================================
//  Actions du reducer
// ============================================================
type Action =
  | { type: "hydrate"; state: AppState }
  | { type: "settings/patch"; patch: Partial<Settings> }
  // Tâches
  | { type: "task/add"; task: Task }
  | { type: "task/update"; id: string; patch: Partial<Task> }
  | { type: "task/remove"; id: string }
  | { type: "task/cycle"; id: string }
  | { type: "task/reorder"; date: string; orderedIds: string[] }
  // Courses
  | { type: "shop/add"; item: ShoppingItem }
  | { type: "shop/update"; id: string; patch: Partial<ShoppingItem> }
  | { type: "shop/remove"; id: string }
  | { type: "shop/toggle"; id: string }
  | { type: "shop/uncheckAll" }
  | { type: "shop/clearAll" }
  // Objectifs
  | { type: "goal/add"; goal: Goal }
  | { type: "goal/update"; id: string; patch: Partial<Goal> }
  | { type: "goal/remove"; id: string }
  // Poids / cardio / muscu
  | { type: "weight/add"; entry: WeightEntry }
  | { type: "weight/remove"; id: string }
  | { type: "cardio/add"; entry: CardioEntry }
  | { type: "cardio/remove"; id: string }
  | { type: "strength/add"; session: StrengthSession }
  | { type: "strength/remove"; id: string }
  // Journal quotidien
  | { type: "dailyLog/upsert"; log: DailyLog }
  // Base d'exercices
  | { type: "exercise/add"; def: ExerciseDef }
  | { type: "exercise/update"; id: string; patch: Partial<ExerciseDef> }
  | { type: "exercise/remove"; id: string }
  // Génération des tâches quotidiennes
  | { type: "day/ensure"; date: string; tasks: Task[] }
  // Notes
  | { type: "note/add"; note: Note }
  | { type: "note/update"; id: string; patch: Partial<Note> }
  | { type: "note/remove"; id: string }
  // Jour / streak / gamification
  | { type: "day/note"; date: string; note: string }
  | { type: "day/validate"; date: string }
  | { type: "xp/add"; amount: number }
  | { type: "badges/set"; ids: string[] }
  // Global
  | { type: "import"; state: AppState }
  | { type: "reset" };

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "hydrate":
    case "import":
      return action.state;
    case "reset":
      return defaultState();

    case "settings/patch":
      return { ...state, settings: { ...state.settings, ...action.patch } };

    // ---- Tâches ----
    case "task/add":
      return { ...state, tasks: [...state.tasks, action.task] };
    case "task/update":
      return {
        ...state,
        tasks: state.tasks.map((t) => (t.id === action.id ? { ...t, ...action.patch } : t)),
      };
    case "task/remove":
      return { ...state, tasks: state.tasks.filter((t) => t.id !== action.id) };
    case "task/cycle": {
      const next: Record<TaskStatus, TaskStatus> = {
        todo: "done",
        done: "failed",
        failed: "todo",
      };
      return {
        ...state,
        tasks: state.tasks.map((t) =>
          t.id === action.id ? { ...t, status: next[t.status] } : t,
        ),
      };
    }
    case "task/reorder": {
      const orderMap = new Map(action.orderedIds.map((id, i) => [id, i]));
      return {
        ...state,
        tasks: state.tasks.map((t) =>
          t.date === action.date && orderMap.has(t.id)
            ? { ...t, order: orderMap.get(t.id)! }
            : t,
        ),
      };
    }

    // ---- Courses ----
    case "shop/add":
      return { ...state, shopping: [...state.shopping, action.item] };
    case "shop/update":
      return {
        ...state,
        shopping: state.shopping.map((s) =>
          s.id === action.id ? { ...s, ...action.patch } : s,
        ),
      };
    case "shop/remove":
      return { ...state, shopping: state.shopping.filter((s) => s.id !== action.id) };
    case "shop/toggle":
      return {
        ...state,
        shopping: state.shopping.map((s) =>
          s.id === action.id ? { ...s, checked: !s.checked } : s,
        ),
      };
    case "shop/uncheckAll":
      return { ...state, shopping: state.shopping.map((s) => ({ ...s, checked: false })) };
    case "shop/clearAll":
      return { ...state, shopping: [] };

    // ---- Objectifs ----
    case "goal/add":
      return { ...state, goals: [...state.goals, action.goal] };
    case "goal/update":
      return {
        ...state,
        goals: state.goals.map((g) => (g.id === action.id ? { ...g, ...action.patch } : g)),
      };
    case "goal/remove":
      return { ...state, goals: state.goals.filter((g) => g.id !== action.id) };

    // ---- Mesures ----
    case "weight/add":
      return {
        ...state,
        weights: [...state.weights.filter((w) => w.date !== action.entry.date), action.entry].sort(
          (a, b) => a.date.localeCompare(b.date),
        ),
      };
    case "weight/remove":
      return { ...state, weights: state.weights.filter((w) => w.id !== action.id) };
    case "cardio/add":
      return {
        ...state,
        cardio: [...state.cardio, action.entry].sort((a, b) => a.date.localeCompare(b.date)),
      };
    case "cardio/remove":
      return { ...state, cardio: state.cardio.filter((c) => c.id !== action.id) };
    case "strength/add":
      return {
        ...state,
        strength: [action.session, ...state.strength],
      };
    case "strength/remove":
      return { ...state, strength: state.strength.filter((s) => s.id !== action.id) };

    // ---- Journal quotidien ----
    case "dailyLog/upsert":
      return {
        ...state,
        dailyLogs: [
          ...state.dailyLogs.filter((l) => l.date !== action.log.date),
          action.log,
        ].sort((a, b) => a.date.localeCompare(b.date)),
      };

    // ---- Base d'exercices ----
    case "exercise/add":
      return { ...state, exerciseDb: [...state.exerciseDb, action.def] };
    case "exercise/update":
      return {
        ...state,
        exerciseDb: state.exerciseDb.map((e) =>
          e.id === action.id ? { ...e, ...action.patch } : e,
        ),
      };
    case "exercise/remove":
      return { ...state, exerciseDb: state.exerciseDb.filter((e) => e.id !== action.id) };

    // ---- Génération des tâches du jour ----
    case "day/ensure": {
      const has = state.tasks.some((t) => t.date === action.date);
      if (has) return state;
      return { ...state, tasks: [...state.tasks, ...action.tasks] };
    }

    // ---- Notes ----
    case "note/add":
      return { ...state, notes: [action.note, ...state.notes] };
    case "note/update":
      return {
        ...state,
        notes: state.notes.map((n) => (n.id === action.id ? { ...n, ...action.patch } : n)),
      };
    case "note/remove":
      return { ...state, notes: state.notes.filter((n) => n.id !== action.id) };

    // ---- Jour / streak / xp ----
    case "day/note":
      return {
        ...state,
        dayMeta: { ...state.dayMeta, [action.date]: { date: action.date, note: action.note } },
      };
    case "day/validate": {
      if (state.validatedDays.includes(action.date)) return state;
      return { ...state, validatedDays: [...state.validatedDays, action.date].sort() };
    }
    case "xp/add":
      return { ...state, gamification: { ...state.gamification, xp: state.gamification.xp + action.amount } };
    case "badges/set":
      return { ...state, gamification: { ...state.gamification, unlockedBadges: action.ids } };

    default:
      return state;
  }
}

// ============================================================
//  Contexte + actions publiques
// ============================================================
interface StoreValue {
  state: AppState;
  ready: boolean;
  // tâches
  addTask: (t: Omit<Task, "id" | "createdAt" | "order"> & { order?: number }) => void;
  updateTask: (id: string, patch: Partial<Task>) => void;
  removeTask: (id: string) => void;
  cycleTask: (id: string) => void;
  reorderTasks: (date: string, orderedIds: string[]) => void;
  // courses
  addShop: (i: Omit<ShoppingItem, "id" | "order" | "checked">) => void;
  updateShop: (id: string, patch: Partial<ShoppingItem>) => void;
  removeShop: (id: string) => void;
  toggleShop: (id: string) => void;
  uncheckAllShop: () => void;
  clearAllShop: () => void;
  // objectifs
  addGoal: (g: Omit<Goal, "id">) => void;
  updateGoal: (id: string, patch: Partial<Goal>) => void;
  removeGoal: (id: string) => void;
  // mesures
  addWeight: (date: string, weight: number) => void;
  removeWeight: (id: string) => void;
  addCardio: (e: Omit<CardioEntry, "id">) => void;
  removeCardio: (id: string) => void;
  addStrength: (s: Omit<StrengthSession, "id">) => void;
  removeStrength: (id: string) => void;
  // journal quotidien
  upsertDailyLog: (log: DailyLog) => void;
  // base d'exercices
  addExercise: (def: Omit<ExerciseDef, "id">) => void;
  updateExercise: (id: string, patch: Partial<ExerciseDef>) => void;
  removeExercise: (id: string) => void;
  // notes
  addNote: () => string;
  updateNote: (id: string, patch: Partial<Note>) => void;
  removeNote: (id: string) => void;
  // jour
  setDayNote: (date: string, note: string) => void;
  validateDay: (date: string) => void;
  awardXp: (amount: number) => void;
  // paramètres & données
  patchSettings: (patch: Partial<Settings>) => void;
  importState: (s: AppState) => void;
  reset: () => void;
  setBadges: (ids: string[]) => void;
}

const StoreContext = createContext<StoreValue | null>(null);

export function StoreProvider({ userId, children }: { userId: string; children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined as unknown as AppState, defaultState);
  const [ready, setReady] = useState(false);
  const firstSave = useRef(true);
  const repository = useMemo(() => makeStateRepository(userId), [userId]);

  // Hydratation depuis la persistance au démarrage
  useEffect(() => {
    let alive = true;
    repository.load().then((loaded) => {
      if (!alive) return;
      if (loaded) dispatch({ type: "hydrate", state: loaded });
      setReady(true);
    });
    return () => {
      alive = false;
    };
  }, [repository]);

  // Génère automatiquement les objectifs du jour (une fois par jour).
  useEffect(() => {
    if (!ready) return;
    const today = todayISO();
    dispatch({ type: "day/ensure", date: today, tasks: templateTasksFor(today) });
  }, [ready]);

  // Sauvegarde automatique (débounce léger)
  useEffect(() => {
    if (!ready) return;
    if (firstSave.current) {
      firstSave.current = false;
    }
    const h = setTimeout(() => repository.save(state), 250);
    return () => clearTimeout(h);
  }, [state, ready, repository]);

  const value = useMemo<StoreValue>(() => {
    return {
      state,
      ready,
      addTask: (t) =>
        dispatch({
          type: "task/add",
          task: {
            ...t,
            id: uid(),
            createdAt: Date.now(),
            order: t.order ?? Date.now(),
          } as Task,
        }),
      updateTask: (id, patch) => dispatch({ type: "task/update", id, patch }),
      removeTask: (id) => dispatch({ type: "task/remove", id }),
      cycleTask: (id) => dispatch({ type: "task/cycle", id }),
      reorderTasks: (date, orderedIds) => dispatch({ type: "task/reorder", date, orderedIds }),

      addShop: (i) =>
        dispatch({ type: "shop/add", item: { ...i, id: uid(), checked: false, order: Date.now() } }),
      updateShop: (id, patch) => dispatch({ type: "shop/update", id, patch }),
      removeShop: (id) => dispatch({ type: "shop/remove", id }),
      toggleShop: (id) => dispatch({ type: "shop/toggle", id }),
      uncheckAllShop: () => dispatch({ type: "shop/uncheckAll" }),
      clearAllShop: () => dispatch({ type: "shop/clearAll" }),

      addGoal: (g) => dispatch({ type: "goal/add", goal: { ...g, id: uid() } }),
      updateGoal: (id, patch) => dispatch({ type: "goal/update", id, patch }),
      removeGoal: (id) => dispatch({ type: "goal/remove", id }),

      addWeight: (date, weight) =>
        dispatch({ type: "weight/add", entry: { id: uid(), date, weight } }),
      removeWeight: (id) => dispatch({ type: "weight/remove", id }),
      addCardio: (e) => dispatch({ type: "cardio/add", entry: { ...e, id: uid() } }),
      removeCardio: (id) => dispatch({ type: "cardio/remove", id }),
      addStrength: (s) => dispatch({ type: "strength/add", session: { ...s, id: uid() } }),
      removeStrength: (id) => dispatch({ type: "strength/remove", id }),

      upsertDailyLog: (log) => dispatch({ type: "dailyLog/upsert", log }),

      addExercise: (def) => dispatch({ type: "exercise/add", def: { ...def, id: uid() } }),
      updateExercise: (id, patch) => dispatch({ type: "exercise/update", id, patch }),
      removeExercise: (id) => dispatch({ type: "exercise/remove", id }),

      addNote: () => {
        const id = uid();
        dispatch({
          type: "note/add",
          note: { id, title: "Nouvelle note", body: "", updatedAt: Date.now() },
        });
        return id;
      },
      updateNote: (id, patch) =>
        dispatch({ type: "note/update", id, patch: { ...patch, updatedAt: Date.now() } }),
      removeNote: (id) => dispatch({ type: "note/remove", id }),

      setDayNote: (date, note) => dispatch({ type: "day/note", date, note }),
      validateDay: (date) => dispatch({ type: "day/validate", date }),
      awardXp: (amount) => dispatch({ type: "xp/add", amount }),

      patchSettings: (patch) => dispatch({ type: "settings/patch", patch }),
      importState: (s) => dispatch({ type: "import", state: s }),
      reset: () => dispatch({ type: "reset" }),
      setBadges: (ids) => dispatch({ type: "badges/set", ids }),
    };
  }, [state, ready]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore doit être utilisé dans <StoreProvider>");
  return ctx;
}

// Petit hook utilitaire : tâches d'un jour, triées par ordre.
export function useDayTasks(date: string) {
  const { state } = useStore();
  return useMemo(
    () => state.tasks.filter((t) => t.date === date).sort((a, b) => a.order - b.order),
    [state.tasks, date],
  );
}

export const TODAY = todayISO();
