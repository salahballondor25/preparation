// Rendu Markdown minimal et sûr (échappement HTML d'abord). Sans dépendance.
// Supporte : titres, gras, italique, code inline, listes, citations, liens, sauts de ligne.

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function inline(s: string): string {
  return s
    .replace(/`([^`]+)`/g, '<code class="rounded bg-surface-raised px-1 py-0.5 text-[0.85em]">$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    .replace(
      /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
      '<a href="$2" target="_blank" rel="noopener" class="underline" style="color:rgb(var(--accent))">$1</a>',
    );
}

export function renderMarkdown(src: string): string {
  const lines = escapeHtml(src).split("\n");
  const out: string[] = [];
  let inList = false;

  const closeList = () => {
    if (inList) {
      out.push("</ul>");
      inList = false;
    }
  };

  for (const raw of lines) {
    const line = raw.trimEnd();
    if (/^###\s+/.test(line)) {
      closeList();
      out.push(`<h3 class="mt-3 mb-1 text-base font-semibold">${inline(line.replace(/^###\s+/, ""))}</h3>`);
    } else if (/^##\s+/.test(line)) {
      closeList();
      out.push(`<h2 class="mt-4 mb-1.5 text-lg font-semibold">${inline(line.replace(/^##\s+/, ""))}</h2>`);
    } else if (/^#\s+/.test(line)) {
      closeList();
      out.push(`<h1 class="mt-2 mb-2 text-xl font-bold">${inline(line.replace(/^#\s+/, ""))}</h1>`);
    } else if (/^>\s?/.test(line)) {
      closeList();
      out.push(
        `<blockquote class="my-2 border-l-2 pl-3 italic text-content-mid" style="border-color:rgb(var(--accent))">${inline(
          line.replace(/^>\s?/, ""),
        )}</blockquote>`,
      );
    } else if (/^[-*]\s+/.test(line)) {
      if (!inList) {
        out.push('<ul class="my-2 ml-4 list-disc space-y-1">');
        inList = true;
      }
      out.push(`<li>${inline(line.replace(/^[-*]\s+/, ""))}</li>`);
    } else if (line === "") {
      closeList();
      out.push("");
    } else {
      closeList();
      out.push(`<p class="my-1.5 leading-relaxed">${inline(line)}</p>`);
    }
  }
  closeList();
  return out.join("\n");
}
