// Citations motivantes — une par jour (déterministe selon la date) + rotation possible.
export const QUOTES: { text: string; author: string }[] = [
  { text: "La discipline est le pont entre les objectifs et les réalisations.", author: "Jim Rohn" },
  { text: "On ne se lève pas au niveau de ses attentes, on tombe au niveau de son entraînement.", author: "Archiloque" },
  { text: "Ce qui ne te tue pas te rend plus fort.", author: "Friedrich Nietzsche" },
  { text: "Le succès, c'est se promener d'échec en échec tout en restant motivé.", author: "Winston Churchill" },
  { text: "La douleur est temporaire, l'abandon est définitif.", author: "Lance Armstrong" },
  { text: "Fais aujourd'hui ce que les autres ne veulent pas, tu vivras demain comme les autres ne peuvent pas.", author: "Anonyme" },
  { text: "Le corps réalise ce que l'esprit croit.", author: "Anonyme" },
  { text: "La motivation te lance, l'habitude te fait continuer.", author: "Jim Ryun" },
  { text: "Un objectif sans plan n'est qu'un souhait.", author: "Antoine de Saint-Exupéry" },
  { text: "La chance sourit aux esprits préparés.", author: "Louis Pasteur" },
  { text: "Sois plus fort que ton excuse la plus solide.", author: "Anonyme" },
  { text: "Chaque expert a d'abord été un débutant.", author: "Helen Hayes" },
  { text: "La sueur d'aujourd'hui est la médaille de demain.", author: "Anonyme" },
  { text: "Tu n'as pas à être extraordinaire pour commencer, mais tu dois commencer pour devenir extraordinaire.", author: "Zig Ziglar" },
  { text: "L'entraînement dur rend le combat facile.", author: "Proverbe militaire" },
];

/** Citation du jour, déterministe : la même toute la journée. */
export function quoteOfDay(iso: string): { text: string; author: string } {
  const seed = iso.split("-").reduce((a, p) => a + Number(p), 0);
  return QUOTES[seed % QUOTES.length];
}
