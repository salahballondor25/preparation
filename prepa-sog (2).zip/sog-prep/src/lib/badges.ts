import type { AppState } from "./types";

export interface BadgeDef {
  id: string;
  icon: string;
  title: string;
  desc: string;
  /** Renvoie true quand le badge est débloqué, à partir de l'état global. */
  check: (s: AppState, stats: BadgeStats) => boolean;
}

export interface BadgeStats {
  totalKm: number;
  strengthSessions: number;
  bestStreak: number;
  currentStreak: number;
  doneTasks: number;
  goodMeals: number;
}

export const BADGES: BadgeDef[] = [
  {
    id: "first-5k",
    icon: "🏃",
    title: "Premier 5 km",
    desc: "Courir 5 km sur une sortie",
    check: (s) => s.cardio.some((c) => c.distanceKm >= 5),
  },
  {
    id: "10-sessions",
    icon: "🏋️",
    title: "10 séances",
    desc: "Réaliser 10 séances de musculation",
    check: (_s, st) => st.strengthSessions >= 10,
  },
  {
    id: "streak-7",
    icon: "🔥",
    title: "Une semaine",
    desc: "7 jours consécutifs validés",
    check: (_s, st) => st.bestStreak >= 7,
  },
  {
    id: "streak-30",
    icon: "🔥",
    title: "30 jours de suite",
    desc: "30 jours consécutifs validés",
    check: (_s, st) => st.bestStreak >= 30,
  },
  {
    id: "50-km",
    icon: "🛰️",
    title: "50 km au compteur",
    desc: "Cumuler 50 km de course",
    check: (_s, st) => st.totalKm >= 50,
  },
  {
    id: "100-meals",
    icon: "🥗",
    title: "100 repas respectés",
    desc: "Valider 100 tâches d'alimentation",
    check: (_s, st) => st.goodMeals >= 100,
  },
  {
    id: "100-tasks",
    icon: "✅",
    title: "Centurion",
    desc: "100 tâches réussies au total",
    check: (_s, st) => st.doneTasks >= 100,
  },
  {
    id: "level-5",
    icon: "⭐",
    title: "Niveau 5",
    desc: "Atteindre le niveau 5",
    check: (s) => levelFromXp(s.gamification.xp).level >= 5,
  },
];

/** Courbe de niveau : chaque niveau coûte de plus en plus d'XP. */
export function levelFromXp(xp: number) {
  let level = 1;
  let need = 100;
  let remaining = xp;
  let prevTotal = 0;
  while (remaining >= need) {
    remaining -= need;
    prevTotal += need;
    level += 1;
    need = Math.round(need * 1.35);
  }
  return {
    level,
    intoLevel: remaining,
    levelNeed: need,
    xpForNext: need - remaining,
    totalForLevel: prevTotal,
  };
}
