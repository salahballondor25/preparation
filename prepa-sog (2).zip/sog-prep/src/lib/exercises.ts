import type { ExerciseDef, MuscleGroup } from "./types";
import { uid } from "./utils";

// Base d'exercices par défaut. L'utilisateur peut ajouter / modifier / supprimer.
const RAW: [string, MuscleGroup][] = [
  // Pectoraux
  ["Développé couché", "pectoraux"],
  ["Développé incliné haltères", "pectoraux"],
  ["Écarté poulie", "pectoraux"],
  ["Pompes", "pectoraux"],
  ["Dips", "pectoraux"],
  // Dos
  ["Tractions", "dos"],
  ["Rowing barre", "dos"],
  ["Tirage vertical", "dos"],
  ["Tirage horizontal", "dos"],
  ["Soulevé de terre", "dos"],
  // Jambes
  ["Squat", "jambes"],
  ["Presse à cuisses", "jambes"],
  ["Fentes", "jambes"],
  ["Leg curl", "jambes"],
  ["Mollets debout", "jambes"],
  // Épaules
  ["Développé militaire", "epaules"],
  ["Élévations latérales", "epaules"],
  ["Oiseau", "epaules"],
  // Bras
  ["Curl biceps", "bras"],
  ["Curl marteau", "bras"],
  ["Extension triceps poulie", "bras"],
  ["Barre au front", "bras"],
  // Abdos
  ["Gainage", "abdos"],
  ["Relevés de jambes", "abdos"],
  ["Crunch", "abdos"],
];

export function defaultExercises(): ExerciseDef[] {
  return RAW.map(([name, muscle]) => ({ id: uid(), name, muscle }));
}
