import type { AppState } from "./types";
import { addDays, daysBetween, pct, todayISO } from "./utils";
import type { BadgeStats } from "./badges";

/** Progression d'un jour donné (part de tâches réussies parmi celles ayant un statut). */
export function dayProgress(state: AppState, date: string) {
  const tasks = state.tasks.filter((t) => t.date === date);
  const total = tasks.length;
  const done = tasks.filter((t) => t.status === "done").length;
  const failed = tasks.filter((t) => t.status === "failed").length;
  return { total, done, failed, remaining: total - done - failed, percent: pct(done, total) };
}

/** Streak courant : nombre de jours validés consécutifs jusqu'à aujourd'hui (ou hier). */
export function currentStreak(validated: string[]): number {
  const set = new Set(validated);
  const today = todayISO();
  // On autorise un streak "en cours" si aujourd'hui n'est pas encore validé mais hier l'est.
  let cursor = set.has(today) ? today : addDays(today, -1);
  if (!set.has(cursor)) return 0;
  let count = 0;
  while (set.has(cursor)) {
    count += 1;
    cursor = addDays(cursor, -1);
  }
  return count;
}

/** Meilleur streak historique. */
export function bestStreak(validated: string[]): number {
  if (validated.length === 0) return 0;
  const sorted = [...validated].sort();
  let best = 1;
  let run = 1;
  for (let i = 1; i < sorted.length; i++) {
    if (daysBetween(sorted[i - 1], sorted[i]) === 1) {
      run += 1;
      best = Math.max(best, run);
    } else {
      run = 1;
    }
  }
  return best;
}

/** Données heatmap : `weeks` derniers jours, avec une intensité 0..4. */
export function heatmap(state: AppState, weeks = 20) {
  const today = todayISO();
  const totalDays = weeks * 7;
  // On démarre au lundi de la première semaine.
  const startRaw = addDays(today, -(totalDays - 1));
  const dow = (new Date(startRaw).getDay() + 6) % 7;
  const start = addDays(startRaw, -dow);

  const cells: { date: string; level: number; percent: number; count: number }[] = [];
  const cursorTasks = new Map<string, { done: number; total: number }>();
  for (const t of state.tasks) {
    const e = cursorTasks.get(t.date) ?? { done: 0, total: 0 };
    e.total += 1;
    if (t.status === "done") e.done += 1;
    cursorTasks.set(t.date, e);
  }

  const cellCount = Math.ceil((daysBetween(start, today) + 1) / 7) * 7;
  for (let i = 0; i < cellCount; i++) {
    const date = addDays(start, i);
    if (daysBetween(date, today) < 0) {
      cells.push({ date, level: -1, percent: 0, count: 0 }); // futur -> vide
      continue;
    }
    const info = cursorTasks.get(date);
    const percent = info ? pct(info.done, info.total) : 0;
    const validated = state.validatedDays.includes(date);
    let level = 0;
    if (info && info.done > 0) {
      if (percent >= 100) level = 4;
      else if (percent >= 75) level = 3;
      else if (percent >= 40) level = 2;
      else level = 1;
    }
    if (validated && level < 1) level = 1;
    cells.push({ date, level, percent, count: info?.done ?? 0 });
  }
  return { cells, start };
}

/** Statistiques globales agrégées. */
export function globalStats(state: AppState) {
  const done = state.tasks.filter((t) => t.status === "done").length;
  const failed = state.tasks.filter((t) => t.status === "failed").length;
  const settled = done + failed;
  const successRate = pct(done, settled);

  const totalKm = round1(state.cardio.reduce((a, c) => a + c.distanceKm, 0));
  const cardioMinutes = state.cardio.reduce((a, c) => a + c.durationMin, 0);
  const strengthMinutes = state.strength.length * 45; // estimation
  const totalTrainingMin = cardioMinutes + strengthMinutes;
  const caloriesBurned = state.cardio.reduce((a, c) => a + (c.calories ?? 0), 0);
  const goodMeals = state.tasks.filter((t) => t.category === "alimentation" && t.status === "done").length;

  const weightsSorted = [...state.weights].sort((a, b) => a.date.localeCompare(b.date));
  const weightDelta =
    weightsSorted.length >= 2
      ? round1(weightsSorted[weightsSorted.length - 1].weight - weightsSorted[0].weight)
      : 0;

  return {
    done,
    failed,
    successRate,
    sessions: state.strength.length,
    cardioSessions: state.cardio.length,
    shoppingCount: state.shopping.length,
    totalKm,
    totalTrainingMin,
    caloriesBurned,
    goodMeals,
    weightDelta,
    current: currentStreak(state.validatedDays),
    best: bestStreak(state.validatedDays),
  };
}

export function badgeStats(state: AppState): BadgeStats {
  const g = globalStats(state);
  return {
    totalKm: g.totalKm,
    strengthSessions: g.sessions,
    bestStreak: g.best,
    currentStreak: g.current,
    doneTasks: g.done,
    goodMeals: g.goodMeals,
  };
}

/** Nombre de jours restants avant le concours. */
export function daysUntilExam(examDate: string) {
  return Math.max(0, daysBetween(todayISO(), examDate));
}

function round1(n: number) {
  return Math.round(n * 10) / 10;
}
