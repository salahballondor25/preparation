import type { AppState, StrengthSession } from "./types";
import { addDays, daysBetween, epley1RM, paceLabel, todayISO } from "./utils";

// ============================================================
//  Moteur d'analyse — tout est calculé automatiquement à partir
//  des données saisies (aucune API externe requise).
// ============================================================

export interface ExercisePoint {
  date: string;
  topWeight: number; // charge maximale de la séance
  volume: number; // Σ (reps × poids), poids du corps compté forfaitairement
  totalReps: number;
  avgReps: number;
  best1RM: number; // 1RM estimé max de la séance
  sets: number;
}

/** Historique chronologique d'un exercice, agrégé par séance. */
export function exerciseHistory(state: AppState, name: string): ExercisePoint[] {
  const points: ExercisePoint[] = [];
  const sessions = [...state.strength].sort((a, b) => a.date.localeCompare(b.date));
  for (const s of sessions) {
    const ex = s.exercises.find((e) => e.name.toLowerCase() === name.toLowerCase());
    if (!ex || ex.sets.length === 0) continue;
    let volume = 0;
    let totalReps = 0;
    let topWeight = 0;
    let best1RM = 0;
    for (const set of ex.sets) {
      const w = set.weight > 0 ? set.weight : 0;
      volume += set.reps * (set.weight > 0 ? set.weight : 1);
      totalReps += set.reps;
      topWeight = Math.max(topWeight, w);
      best1RM = Math.max(best1RM, epley1RM(set.weight, set.reps));
    }
    points.push({
      date: s.date,
      topWeight,
      volume: Math.round(volume),
      totalReps,
      avgReps: Math.round(totalReps / ex.sets.length),
      best1RM,
      sets: ex.sets.length,
    });
  }
  return points;
}

/** Noms d'exercices ayant au moins une donnée enregistrée. */
export function trackedExercises(state: AppState): string[] {
  const set = new Set<string>();
  for (const s of state.strength) for (const e of s.exercises) if (e.name.trim()) set.add(e.name);
  return [...set].sort((a, b) => a.localeCompare(b));
}

/** Records personnels par exercice. */
export function personalRecords(state: AppState) {
  const map = new Map<string, { maxWeight: number; best1RM: number; maxVolume: number }>();
  for (const name of trackedExercises(state)) {
    const h = exerciseHistory(state, name);
    map.set(name, {
      maxWeight: Math.max(0, ...h.map((p) => p.topWeight)),
      best1RM: Math.max(0, ...h.map((p) => p.best1RM)),
      maxVolume: Math.max(0, ...h.map((p) => p.volume)),
    });
  }
  return map;
}

/** Durée estimée d'une séance de muscu (≈ 3,5 min / série). */
export function sessionMinutes(s: StrengthSession): number {
  const sets = s.exercises.reduce((a, e) => a + e.sets.length, 0);
  return Math.round(sets * 3.5);
}

/** Agrégats d'entraînement calculés automatiquement. */
export function trainingSummary(state: AppState) {
  const today = todayISO();
  const weekAgo = addDays(today, -7);
  const monthAgo = addDays(today, -30);

  const strengthMin = state.strength.reduce((a, s) => a + sessionMinutes(s), 0);
  const cardioMin = state.cardio.reduce((a, c) => a + c.durationMin, 0);

  const weeklyKm = round1(
    state.cardio.filter((c) => c.date >= weekAgo).reduce((a, c) => a + c.distanceKm, 0),
  );
  const monthlyKm = round1(
    state.cardio.filter((c) => c.date >= monthAgo).reduce((a, c) => a + c.distanceKm, 0),
  );

  // Meilleure séance (volume total le plus élevé)
  let bestSession: { title: string; date: string; volume: number } | null = null;
  for (const s of state.strength) {
    const volume = s.exercises.reduce(
      (a, e) => a + e.sets.reduce((b, set) => b + set.reps * (set.weight > 0 ? set.weight : 1), 0),
      0,
    );
    if (!bestSession || volume > bestSession.volume)
      bestSession = { title: s.title, date: s.date, volume: Math.round(volume) };
  }

  // Meilleure semaine (nombre de séances muscu + cardio)
  const weekCounts = new Map<string, number>();
  for (const s of state.strength) {
    const wk = weekKey(s.date);
    weekCounts.set(wk, (weekCounts.get(wk) ?? 0) + 1);
  }
  for (const c of state.cardio) {
    const wk = weekKey(c.date);
    weekCounts.set(wk, (weekCounts.get(wk) ?? 0) + 1);
  }
  const bestWeek = Math.max(0, ...weekCounts.values());

  return {
    strengthSessions: state.strength.length,
    cardioSessions: state.cardio.length,
    totalTrainingMin: strengthMin + cardioMin,
    weeklyKm,
    monthlyKm,
    bestSession,
    bestWeek,
  };
}

export type InsightKind = "success" | "pr" | "warning" | "tip" | "info";
export interface Insight {
  kind: InsightKind;
  icon: string;
  text: string;
}

/**
 * Analyse automatique de la journée : génère un résumé façon coach
 * et détecte records, régressions, plateaus et oublis.
 */
export function analyzeDay(state: AppState, date: string): Insight[] {
  const insights: Insight[] = [];
  const log = state.dailyLogs.find((l) => l.date === date);
  const session = state.strength.find((s) => s.date === date);
  const run = state.cardio.find((c) => c.date === date);

  // -- Ton général de la journée --
  let score = 0;
  let max = 0;
  if (log) {
    if (log.nutrition) {
      max += 1;
      score += log.nutrition === "oui" ? 1 : log.nutrition === "moyen" ? 0.5 : 0;
    }
    if (log.waterL != null) {
      max += 1;
      score += Math.min(1, log.waterL / state.settings.waterTargetL);
    }
    if (log.steps != null) {
      max += 1;
      score += Math.min(1, log.steps / state.settings.stepsTarget);
    }
    if (log.sleepQuality != null) {
      max += 1;
      score += log.sleepQuality / 5;
    }
  }
  if (session || run) {
    max += 1;
    score += 1;
  }
  const ratio = max ? score / max : 0;
  if (ratio >= 0.8)
    insights.push({ kind: "success", icon: "🔥", text: "Très bonne journée, tu coches presque tout." });
  else if (ratio >= 0.55)
    insights.push({ kind: "info", icon: "👍", text: "Journée correcte — encore un cran possible." });
  else if (max > 0)
    insights.push({ kind: "tip", icon: "💪", text: "Journée en dessous de ton standard, on se relance demain." });

  // -- Records & progression muscu --
  if (session) {
    for (const ex of session.exercises) {
      const hist = exerciseHistory(state, ex.name).filter((p) => p.date < date);
      const todayPoint = exerciseHistory(state, ex.name).find((p) => p.date === date);
      if (!todayPoint) continue;
      const prevBestWeight = Math.max(0, ...hist.map((p) => p.topWeight));
      if (hist.length > 0 && todayPoint.topWeight > prevBestWeight && prevBestWeight > 0) {
        insights.push({
          kind: "pr",
          icon: "🏆",
          text: `Record sur ${ex.name} : ${todayPoint.topWeight} kg (+${round1(
            todayPoint.topWeight - prevBestWeight,
          )} kg).`,
        });
      } else if (hist.length >= 2) {
        // Plateau : même charge max sur 3 dernières séances
        const last3 = [...hist.slice(-2), todayPoint];
        if (last3.every((p) => p.topWeight === last3[0].topWeight) && last3[0].topWeight > 0) {
          insights.push({
            kind: "tip",
            icon: "⏸️",
            text: `Plateau sur ${ex.name} (${last3[0].topWeight} kg depuis 3 séances) — tente +2,5 kg ou une série de plus.`,
          });
        } else {
          const prev = hist[hist.length - 1];
          if (todayPoint.volume < prev.volume * 0.85) {
            insights.push({
              kind: "warning",
              icon: "📉",
              text: `Volume en baisse sur ${ex.name} vs séance précédente — fatigue ou récup à surveiller.`,
            });
          } else if (todayPoint.volume > prev.volume * 1.1) {
            insights.push({
              kind: "success",
              icon: "📈",
              text: `Progression du volume sur ${ex.name} (+${Math.round(
                ((todayPoint.volume - prev.volume) / prev.volume) * 100,
              )} %).`,
            });
          }
        }
      }
    }
  }

  // -- Cardio --
  if (run) {
    const prevRuns = state.cardio.filter((c) => c.date < date).sort((a, b) => a.date.localeCompare(b.date));
    const last = prevRuns[prevRuns.length - 1];
    if (last) {
      if (run.distanceKm > last.distanceKm) {
        insights.push({
          kind: "success",
          icon: "🏃",
          text: `Tu cours plus loin que la dernière fois (${run.distanceKm} km vs ${last.distanceKm} km).`,
        });
      }
      const p1 = (run.durationMin * 60) / run.distanceKm;
      const p0 = (last.durationMin * 60) / last.distanceKm;
      if (p1 < p0 - 3) {
        insights.push({ kind: "pr", icon: "⚡", text: `Allure améliorée : ${paceLabel(run.distanceKm, run.durationMin)}.` });
      }
    }
  }

  // -- Sommeil en baisse --
  const recentSleep = state.dailyLogs
    .filter((l) => l.sleepQuality != null && l.date <= date)
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(-4);
  if (recentSleep.length >= 3) {
    const decreasing = recentSleep.every(
      (l, i) => i === 0 || l.sleepQuality! <= recentSleep[i - 1].sleepQuality!,
    );
    if (decreasing && recentSleep[0].sleepQuality! > recentSleep[recentSleep.length - 1].sleepQuality!) {
      insights.push({
        kind: "warning",
        icon: "😴",
        text: "Ton sommeil baisse depuis plusieurs jours — priorité au repos ce soir.",
      });
    }
  }

  // -- Hydratation oubliée --
  const recentLogs = state.dailyLogs
    .filter((l) => l.date <= date)
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(-5);
  const lowWater = recentLogs.filter(
    (l) => l.waterL != null && l.waterL < state.settings.waterTargetL,
  ).length;
  if (recentLogs.length >= 3 && lowWater >= 3) {
    insights.push({
      kind: "tip",
      icon: "💧",
      text: `Hydratation souvent sous ${state.settings.waterTargetL} L ces derniers jours — vise un verre de plus.`,
    });
  }

  // -- Poids vers l'objectif --
  const ws = [...state.weights].sort((a, b) => a.date.localeCompare(b.date));
  if (ws.length >= 2) {
    const cur = ws[ws.length - 1].weight;
    const target = state.settings.targetWeight;
    const start = state.settings.startWeight;
    if (start !== target) {
      const progress = Math.round(((start - cur) / (start - target)) * 100);
      if (progress > 0 && progress < 100) {
        insights.push({
          kind: "info",
          icon: "⚖️",
          text: `Poids : ${cur} kg — ${progress} % du chemin vers ${target} kg.`,
        });
      } else if (progress >= 100) {
        insights.push({ kind: "success", icon: "🎯", text: `Objectif de poids atteint (${cur} kg) !` });
      }
    }
  }

  // -- Motivation / énergie --
  if (log?.motivation != null && log.motivation <= 4) {
    insights.push({
      kind: "tip",
      icon: "🌱",
      text: "Motivation en berne aujourd'hui — un petit pas vaut mieux que rien. Demain est un nouveau jour.",
    });
  }

  if (insights.length === 0)
    insights.push({ kind: "info", icon: "📊", text: "Continue à remplir tes bilans : l'analyse s'affinera de jour en jour." });

  return insights;
}

function weekKey(iso: string): string {
  const monday = addDays(iso, -((new Date(iso).getDay() + 6) % 7));
  return monday;
}
function round1(n: number) {
  return Math.round(n * 10) / 10;
}

export { daysBetween };
