import type { Category, Priority, ShoppingCategory } from "./types";

// ---- ID ----
export const uid = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

// ---- Dates (toutes les clés de jour sont au format ISO "YYYY-MM-DD" en heure locale) ----
export const toISO = (d: Date): string => {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
};

export const todayISO = () => toISO(new Date());

export const fromISO = (iso: string): Date => {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d);
};

export const addDays = (iso: string, n: number): string => {
  const d = fromISO(iso);
  d.setDate(d.getDate() + n);
  return toISO(d);
};

export const daysBetween = (aISO: string, bISO: string): number => {
  const a = fromISO(aISO).getTime();
  const b = fromISO(bISO).getTime();
  return Math.round((b - a) / 86400000);
};

const WEEKDAYS = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
const WEEKDAYS_LONG = [
  "Dimanche",
  "Lundi",
  "Mardi",
  "Mercredi",
  "Jeudi",
  "Vendredi",
  "Samedi",
];
const MONTHS = [
  "Janvier",
  "Février",
  "Mars",
  "Avril",
  "Mai",
  "Juin",
  "Juillet",
  "Août",
  "Septembre",
  "Octobre",
  "Novembre",
  "Décembre",
];

export const formatLongDate = (d: Date = new Date()): string =>
  `${WEEKDAYS_LONG[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;

export const formatDayLabel = (iso: string): string => {
  const d = fromISO(iso);
  return `${WEEKDAYS_LONG[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]}`;
};

export const monthLabel = (year: number, month: number) =>
  `${MONTHS[month]} ${year}`;

export const shortWeekday = (dow: number) => WEEKDAYS[dow];

/** Lundi comme premier jour de la semaine (norme FR). Renvoie l'ISO du lundi. */
export const startOfWeek = (iso: string): string => {
  const d = fromISO(iso);
  const dow = (d.getDay() + 6) % 7; // 0 = lundi
  return addDays(iso, -dow);
};

/** Grille du mois : 6 semaines de 7 jours à partir du lundi. */
export const monthGrid = (year: number, month: number): string[] => {
  const first = new Date(year, month, 1);
  const start = startOfWeek(toISO(first));
  return Array.from({ length: 42 }, (_, i) => addDays(start, i));
};

export const isSameMonth = (iso: string, year: number, month: number) => {
  const d = fromISO(iso);
  return d.getFullYear() === year && d.getMonth() === month;
};

// ---- Formatage ----
export const pct = (num: number, den: number) =>
  den <= 0 ? 0 : Math.round((num / den) * 100);

export const euro = (n: number) =>
  new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(n);

export const clamp = (n: number, min: number, max: number) =>
  Math.max(min, Math.min(max, n));

export const formatDuration = (min: number): string => {
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m ? `${h} h ${m}` : `${h} h`;
};

// ---- Métadonnées catégories ----
export const CATEGORY_META: Record<
  Category,
  { label: string; color: string; emoji: string }
> = {
  sport: { label: "Sport", color: "#38bdf8", emoji: "🏃" },
  alimentation: { label: "Alimentation", color: "#34d399", emoji: "🥗" },
  travail: { label: "Travail", color: "#a78bfa", emoji: "📚" },
  personnel: { label: "Personnel", color: "#f472b6", emoji: "🌿" },
  courses: { label: "Courses", color: "#fbbf24", emoji: "🛒" },
  administratif: { label: "Administratif", color: "#f87171", emoji: "🗂️" },
};

export const PRIORITY_META: Record<
  Priority,
  { label: string; color: string; weight: number }
> = {
  urgent: { label: "Urgent", color: "#f87171", weight: 0 },
  normal: { label: "Normal", color: "#38bdf8", weight: 1 },
  faible: { label: "Faible", color: "#7b8394", weight: 2 },
};

export const SHOPPING_META: Record<
  ShoppingCategory,
  { label: string; emoji: string }
> = {
  proteines: { label: "Protéines", emoji: "🍗" },
  feculents: { label: "Féculents", emoji: "🍚" },
  legumes: { label: "Légumes", emoji: "🥦" },
  fruits: { label: "Fruits", emoji: "🍎" },
  graisses: { label: "Bonnes graisses", emoji: "🥑" },
  divers: { label: "Divers", emoji: "🧂" },
};

// ---- Musculation : groupes musculaires & types de séance ----
export const MUSCLE_META: Record<
  import("./types").MuscleGroup,
  { label: string; emoji: string }
> = {
  pectoraux: { label: "Pectoraux", emoji: "💪" },
  dos: { label: "Dos", emoji: "🔙" },
  jambes: { label: "Jambes", emoji: "🦵" },
  epaules: { label: "Épaules", emoji: "🏋️" },
  bras: { label: "Bras", emoji: "💪" },
  abdos: { label: "Abdos", emoji: "🎯" },
  autre: { label: "Autre", emoji: "⚙️" },
};

export const SESSION_TYPE_META: Record<
  import("./types").SessionType,
  { label: string; emoji: string }
> = {
  push: { label: "Push", emoji: "⬆️" },
  pull: { label: "Pull", emoji: "⬇️" },
  legs: { label: "Legs", emoji: "🦵" },
  full: { label: "Full body", emoji: "🔥" },
  autre: { label: "Autre", emoji: "⚙️" },
};

/** Allure course (min/km) formatée depuis distance + durée. */
export const paceLabel = (distanceKm: number, durationMin: number): string => {
  if (!distanceKm) return "—";
  const secPerKm = (durationMin * 60) / distanceKm;
  const m = Math.floor(secPerKm / 60);
  const s = Math.round(secPerKm % 60);
  return `${m}:${String(s).padStart(2, "0")} /km`;
};

/** Estimation calories course (~1 kcal/kg/km). */
export const estimateRunCalories = (distanceKm: number, weightKg: number) =>
  Math.round(distanceKm * weightKg * 0.95);

/** 1RM estimé (formule d'Epley). */
export const epley1RM = (weight: number, reps: number) =>
  weight <= 0 ? 0 : Math.round(weight * (1 + reps / 30));

/** IMC + interprétation */
export const bmi = (weightKg: number, heightCm: number) => {
  if (!heightCm) return { value: 0, label: "—" };
  const h = heightCm / 100;
  const value = weightKg / (h * h);
  let label = "Normal";
  if (value < 18.5) label = "Maigreur";
  else if (value < 25) label = "Normal";
  else if (value < 30) label = "Surpoids";
  else label = "Obésité";
  return { value: Math.round(value * 10) / 10, label };
};
