// ============================================================
//  Modèle de données — typage central de l'application
// ============================================================

export type TaskStatus = "todo" | "done" | "failed"; // ⚪ 🟢 🔴

export type Category =
  | "sport"
  | "alimentation"
  | "travail"
  | "personnel"
  | "courses"
  | "administratif";

export type Priority = "urgent" | "normal" | "faible";

export interface Task {
  id: string;
  title: string;
  status: TaskStatus;
  date: string; // ISO "YYYY-MM-DD"
  category: Category;
  priority: Priority;
  time?: string;
  reminder?: boolean;
  estimatedMin?: number;
  order: number;
  createdAt: number;
  templateKey?: string; // marque une tâche générée depuis le modèle quotidien
}

export interface DayMeta {
  date: string;
  note: string;
}

export type ShoppingCategory =
  | "proteines"
  | "feculents"
  | "legumes"
  | "fruits"
  | "graisses"
  | "divers";

export interface ShoppingItem {
  id: string;
  name: string;
  qty: number;
  price: number;
  store?: string;
  category: ShoppingCategory;
  checked: boolean;
  order: number;
}

export interface Goal {
  id: string;
  title: string;
  current: number;
  target: number;
  unit: string;
  primary?: boolean;
}

export interface WeightEntry {
  id: string;
  date: string;
  weight: number;
}

export interface CardioEntry {
  id: string;
  date: string;
  distanceKm: number;
  durationMin: number;
  calories?: number;
  comment?: string;
}

// ---- Musculation ----
export type MuscleGroup =
  | "pectoraux"
  | "dos"
  | "jambes"
  | "epaules"
  | "bras"
  | "abdos"
  | "autre";

export type SessionType = "push" | "pull" | "legs" | "full" | "autre";

export interface ExerciseDef {
  id: string;
  name: string;
  muscle: MuscleGroup;
}

export interface StrengthSet {
  reps: number;
  weight: number; // kg (0 = poids du corps)
  rpe?: number; // 1-10, difficulté ressentie
}
export interface StrengthExercise {
  name: string;
  sets: StrengthSet[];
}
export interface StrengthSession {
  id: string;
  date: string;
  title: string;
  type?: SessionType;
  exercises: StrengthExercise[];
  comment?: string;
}

// ---- Journal quotidien (rempli par le bilan du soir) ----
export type NutritionRating = "oui" | "moyen" | "non";

export interface DailyLog {
  date: string;
  trained: boolean;
  ran: boolean;
  nutrition?: NutritionRating;
  waterL?: number;
  steps?: number;
  weight?: number;
  sleepQuality?: number; // 1-5
  bedtime?: string; // "HH:MM"
  waketime?: string; // "HH:MM"
  energy?: number; // 1-10
  motivation?: number; // 1-10
  note?: string;
  completedAt: number; // timestamp de complétion du bilan
}

export interface Note {
  id: string;
  title: string;
  body: string;
  updatedAt: number;
}

export interface Settings {
  name: string;
  objectiveTitle: string;
  examDate: string;
  accent: string; // "R G B"
  theme: "dark" | "light";
  heightCm: number;
  startWeight: number;
  targetWeight: number;
  weeklyTrainingHours: number;
  waterTargetL: number;
  stepsTarget: number;
  sleepTargetH: number;
  eveningHour: number; // heure de déclenchement du bilan
  autoWizard: boolean; // ouverture automatique le soir
  notifications: boolean;
}

export interface Gamification {
  xp: number;
  unlockedBadges: string[];
}

export interface AppState {
  version: number;
  settings: Settings;
  tasks: Task[];
  dayMeta: Record<string, DayMeta>;
  shopping: ShoppingItem[];
  goals: Goal[];
  weights: WeightEntry[];
  cardio: CardioEntry[];
  strength: StrengthSession[];
  dailyLogs: DailyLog[];
  exerciseDb: ExerciseDef[];
  notes: Note[];
  gamification: Gamification;
  validatedDays: string[];
}
