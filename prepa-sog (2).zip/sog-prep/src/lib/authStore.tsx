import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { auth, type AuthResult, type AuthUser } from "./auth";

interface AuthCtx {
  user: AuthUser | null;
  ready: boolean;
  signUp: (username: string, password: string) => Promise<AuthResult>;
  signIn: (username: string, password: string) => Promise<AuthResult>;
  signOut: () => void;
}

const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setUser(auth.current());
    setReady(true);
  }, []);

  const value = useMemo<AuthCtx>(
    () => ({
      user,
      ready,
      signUp: async (u, p) => {
        const r = await auth.signUp(u, p);
        if (r.ok && r.user) setUser(r.user);
        return r;
      },
      signIn: async (u, p) => {
        const r = await auth.signIn(u, p);
        if (r.ok && r.user) setUser(r.user);
        return r;
      },
      signOut: () => {
        void auth.signOut();
        setUser(null);
      },
    }),
    [user, ready],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAuth doit être utilisé dans <AuthProvider>");
  return ctx;
}
