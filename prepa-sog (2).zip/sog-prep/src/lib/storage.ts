import type { AppState, Category, Task } from "./types";
import { todayISO, uid } from "./utils";
import { defaultExercises } from "./exercises";

// ============================================================
//  Couche de persistance
//  Toute l'app passe par l'interface `Repository`. Pour brancher
//  Supabase plus tard : écrire une `SupabaseRepository` respectant
//  cette interface et changer la ligne `export const repository = ...`.
// ============================================================

export const SCHEMA_VERSION = 2;

export interface Repository {
  load(): Promise<AppState | null>;
  save(state: AppState): Promise<void>;
  clear(): Promise<void>;
}

const LEGACY_KEY = "prepa-sog:state:v1"; // données d'avant le système de comptes
const ADOPT_FLAG = "prepa-sog:legacyAdopted";
const stateKey = (userId: string) => `prepa-sog:state:v1:${userId}`;

/**
 * Repository de l'état, cloisonné par utilisateur (clé LocalStorage dédiée).
 * 👉 Point d'extension unique : pour la synchro multi-appareils, remplacer le
 * corps de load/save par des appels Supabase (voir README) sans toucher aux composants.
 */
export function makeStateRepository(userId: string): Repository {
  const KEY = stateKey(userId);
  return {
    async load(): Promise<AppState | null> {
      try {
        let raw = localStorage.getItem(KEY);
        // Le tout premier compte récupère les données créées avant les comptes.
        if (!raw) {
          const legacy = localStorage.getItem(LEGACY_KEY);
          if (legacy && !localStorage.getItem(ADOPT_FLAG)) {
            localStorage.setItem(KEY, legacy);
            localStorage.setItem(ADOPT_FLAG, "1");
            raw = legacy;
          }
        }
        if (!raw) return null;
        return migrate(JSON.parse(raw));
      } catch (e) {
        console.error("Lecture des données impossible :", e);
        return null;
      }
    },
    async save(state: AppState): Promise<void> {
      try {
        localStorage.setItem(KEY, JSON.stringify(state));
      } catch (e) {
        console.error("Sauvegarde impossible :", e);
      }
    },
    async clear(): Promise<void> {
      localStorage.removeItem(KEY);
    },
  };
}

/** Fusion défensive : garde les données existantes, complète les champs manquants. */
function migrate(state: Partial<AppState>): AppState {
  const base = defaultState();
  return {
    ...base,
    ...state,
    settings: { ...base.settings, ...state.settings },
    gamification: { ...base.gamification, ...state.gamification },
    dayMeta: state.dayMeta ?? {},
    dailyLogs: state.dailyLogs ?? [],
    exerciseDb: state.exerciseDb?.length ? state.exerciseDb : base.exerciseDb,
    cardio: state.cardio ?? [],
    strength: state.strength ?? [],
    weights: state.weights ?? base.weights,
    version: SCHEMA_VERSION,
  };
}

// Modèle des objectifs quotidiens : régénéré chaque jour automatiquement.
export const DAILY_TEMPLATE: { key: string; title: string; category: Category }[] = [
  { key: "muscu", title: "Musculation (si prévue)", category: "sport" },
  { key: "cardio", title: "Cardio (si prévu)", category: "sport" },
  { key: "eau", title: "Boire 3 L d'eau", category: "alimentation" },
  { key: "pas", title: "10 000 pas", category: "personnel" },
  { key: "alim", title: "Respecter l'alimentation", category: "alimentation" },
  { key: "sommeil", title: "Dormir 8 heures", category: "personnel" },
];

/** Génère les tâches du jour à partir du modèle (utilisé au démarrage). */
export function templateTasksFor(date: string): Task[] {
  return DAILY_TEMPLATE.map((t, i) => ({
    id: uid(),
    title: t.title,
    status: "todo" as const,
    date,
    category: t.category,
    priority: "normal" as const,
    order: i,
    createdAt: Date.now() + i,
    templateKey: t.key,
  }));
}

// ---- État initial (profil pré-rempli) ----
export function defaultState(): AppState {
  const today = todayISO();
  // Concours visé : septembre (ajustable dans les paramètres).
  const now = new Date();
  const examYear = now.getMonth() >= 8 ? now.getFullYear() + 1 : now.getFullYear();
  const examISO = `${examYear}-09-01`;

  return {
    version: SCHEMA_VERSION,
    settings: {
      name: "Candidat",
      objectiveTitle: "Réussir le concours Sous-Officier de Gendarmerie",
      examDate: examISO,
      accent: "56 132 255",
      theme: "dark",
      heightCm: 175,
      startWeight: 76,
      targetWeight: 70,
      weeklyTrainingHours: 20,
      waterTargetL: 3,
      stepsTarget: 10000,
      sleepTargetH: 8,
      eveningHour: 20,
      autoWizard: true,
      notifications: false,
    },
    tasks: templateTasksFor(today),
    dayMeta: {},
    shopping: SHOPPING_SEED.map((s, i) => ({
      id: uid(),
      name: s[0],
      qty: 1,
      price: s[2],
      category: s[1],
      checked: false,
      order: i,
    })),
    goals: [
      {
        id: uid(),
        title: "Réussir le concours Sous-Officier de Gendarmerie",
        current: 0,
        target: 100,
        unit: "%",
        primary: true,
      },
      { id: uid(), title: "Atteindre le poids cible", current: 76, target: 70, unit: "kg" },
      { id: uid(), title: "Cardio — 10 km sans arrêt", current: 5, target: 10, unit: "km" },
      { id: uid(), title: "Séances de muscu / semaine", current: 0, target: 4, unit: "séances" },
    ],
    weights: [{ id: uid(), date: today, weight: 76 }],
    cardio: [],
    strength: [],
    dailyLogs: [],
    exerciseDb: defaultExercises(),
    notes: [
      {
        id: uid(),
        title: "Mon cap",
        body:
          "# Objectif : septembre\n\n- Perdre du gras\n- Améliorer mon cardio\n- Construire un physique athlétique\n- Être prêt pour le concours SOG\n\n> Régularité > intensité ponctuelle.",
        updatedAt: Date.now(),
      },
      {
        id: uid(),
        title: "Épreuves du concours",
        body:
          "# Épreuves\n\n- **Sport** : luc-léger, tractions, pompes, gainage\n- **Écrit** : culture générale, français\n- **Oral** : entretien de motivation",
        updatedAt: Date.now() - 1,
      },
    ],
    gamification: { xp: 0, unlockedBadges: [] },
    validatedDays: [],
  };
}

// Liste de courses pré-remplie (nom, catégorie, prix estimé €).
const SHOPPING_SEED: [string, AppState["shopping"][number]["category"], number][] = [
  // Protéines
  ["Blanc de poulet", "proteines", 7.5],
  ["Œufs", "proteines", 3.2],
  ["Thon", "proteines", 2.4],
  ["Fromage blanc 0 %", "proteines", 2.2],
  ["Whey", "proteines", 24.9],
  ["Gruyère", "proteines", 3.5],
  // Féculents
  ["Riz", "feculents", 3.1],
  ["Pâtes", "feculents", 1.6],
  ["Flocons d'avoine", "feculents", 2.3],
  ["Pommes de terre", "feculents", 2.9],
  // Légumes
  ["Brocolis", "legumes", 2.2],
  ["Carottes", "legumes", 1.4],
  ["Chou", "legumes", 1.9],
  ["Haricots verts", "legumes", 2.6],
  ["Salade", "legumes", 1.2],
  ["Tomates", "legumes", 2.8],
  ["Oignons", "legumes", 1.3],
  // Fruits
  ["Bananes", "fruits", 1.8],
  ["Pommes", "fruits", 2.4],
  // Bonnes graisses
  ["Amandes", "graisses", 4.5],
  ["Huile d'olive", "graisses", 6.9],
  // Divers
  ["Miel", "divers", 4.2],
  ["Sel", "divers", 0.8],
  ["Poivre", "divers", 1.9],
  ["Paprika", "divers", 1.5],
  ["Curry", "divers", 1.5],
  ["Ail", "divers", 1.1],
  ["Herbes de Provence", "divers", 1.6],
  ["Moutarde", "divers", 1.7],
];
