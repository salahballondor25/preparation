// ============================================================
//  Authentification
//
//  Comptes pseudo + mot de passe. Aujourd'hui : implémentation locale
//  (LocalStorage), les données restent sur l'appareil. Pour une vraie
//  synchro multi-appareils : fournir une implémentation `AuthProvider`
//  basée sur Supabase et changer la ligne `export const auth = ...`.
//  (Voir README — section « Synchro entre appareils ».)
// ============================================================

export interface Account {
  id: string;
  username: string; // affichage (casse d'origine)
  key: string; // username en minuscules, pour la recherche
  passHash: string;
  createdAt: number;
}

export interface AuthUser {
  id: string;
  username: string;
}

export interface AuthResult {
  ok: boolean;
  user?: AuthUser;
  error?: string;
}

export interface AuthProvider {
  signUp(username: string, password: string): Promise<AuthResult>;
  signIn(username: string, password: string): Promise<AuthResult>;
  signOut(): Promise<void>;
  current(): AuthUser | null;
}

const ACCOUNTS_KEY = "prepa-sog:accounts";
const SESSION_KEY = "prepa-sog:session";
const APP_SALT = "prepa-sog::salt::v1";

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

/** Hash SHA-256 (contexte sécurisé requis : https ou localhost). */
async function sha256(text: string): Promise<string> {
  const data = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export async function hashPassword(username: string, password: string): Promise<string> {
  return sha256(`${APP_SALT}:${username.toLowerCase()}:${password}`);
}

function readAccounts(): Account[] {
  try {
    return JSON.parse(localStorage.getItem(ACCOUNTS_KEY) ?? "[]");
  } catch {
    return [];
  }
}
function writeAccounts(list: Account[]) {
  localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(list));
}

class LocalAuthProvider implements AuthProvider {
  async signUp(username: string, password: string): Promise<AuthResult> {
    const name = username.trim();
    if (name.length < 3) return { ok: false, error: "Le pseudo doit faire au moins 3 caractères." };
    if (!/^[a-zA-Z0-9_.\- ]+$/.test(name))
      return { ok: false, error: "Pseudo invalide (lettres, chiffres, . _ - autorisés)." };
    if (password.length < 4) return { ok: false, error: "Le mot de passe doit faire au moins 4 caractères." };

    const accounts = readAccounts();
    const key = name.toLowerCase();
    if (accounts.some((a) => a.key === key)) return { ok: false, error: "Ce pseudo est déjà pris." };

    const account: Account = {
      id: uid(),
      username: name,
      key,
      passHash: await hashPassword(name, password),
      createdAt: Date.now(),
    };
    writeAccounts([...accounts, account]);
    localStorage.setItem(SESSION_KEY, account.id);
    return { ok: true, user: { id: account.id, username: account.username } };
  }

  async signIn(username: string, password: string): Promise<AuthResult> {
    const key = username.trim().toLowerCase();
    const account = readAccounts().find((a) => a.key === key);
    if (!account) return { ok: false, error: "Aucun compte avec ce pseudo." };
    const hash = await hashPassword(account.username, password);
    if (hash !== account.passHash) return { ok: false, error: "Mot de passe incorrect." };
    localStorage.setItem(SESSION_KEY, account.id);
    return { ok: true, user: { id: account.id, username: account.username } };
  }

  async signOut(): Promise<void> {
    localStorage.removeItem(SESSION_KEY);
  }

  current(): AuthUser | null {
    const id = localStorage.getItem(SESSION_KEY);
    if (!id) return null;
    const account = readAccounts().find((a) => a.id === id);
    return account ? { id: account.id, username: account.username } : null;
  }
}

// 👉 Point d'extension unique : remplacer par SupabaseAuthProvider le jour venu.
export const auth: AuthProvider = new LocalAuthProvider();
