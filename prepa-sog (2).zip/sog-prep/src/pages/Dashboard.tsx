import { useMemo } from "react";
import { Link } from "react-router-dom";
import {
  Moon,
  Flame,
  Dumbbell,
  Footprints,
  Scale,
  Quote,
  Sparkles,
  Clock,
  Check,
  ChevronRight,
  CheckCircle2,
} from "lucide-react";
import { useStore, useDayTasks, TODAY } from "../lib/store";
import { useWizard } from "../components/WizardHost";
import { dayProgress, currentStreak, daysUntilExam } from "../lib/selectors";
import { analyzeDay } from "../lib/analysis";
import { Ring } from "../components/ui/Primitives";
import { formatLongDate, fromISO, startOfWeek, addDays, todayISO, paceLabel } from "../lib/utils";
import { quoteOfDay } from "../lib/quotes";

const INSIGHT_STYLE: Record<string, string> = {
  success: "border-emerald-500/30 bg-emerald-500/10",
  pr: "border-amber-400/30 bg-amber-400/10",
  warning: "border-red-500/30 bg-red-500/10",
  tip: "border-sky-500/30 bg-sky-500/10",
  info: "border-surface-line bg-surface-base",
};

function greeting() {
  const h = new Date().getHours();
  if (h < 6) return "Bonne nuit";
  if (h < 12) return "Bonjour";
  if (h < 18) return "Bon après-midi";
  return "Bonsoir";
}

export default function Dashboard() {
  const { state, updateTask } = useStore();
  const wizard = useWizard();
  const tasks = useDayTasks(TODAY);
  const prog = dayProgress(state, TODAY);
  const streak = currentStreak(state.validatedDays);
  const daysLeft = daysUntilExam(state.settings.examDate);
  const q = useMemo(() => quoteOfDay(TODAY), []);

  const lastStrength = useMemo(
    () => [...state.strength].sort((a, b) => b.date.localeCompare(a.date))[0],
    [state.strength],
  );
  const lastCardio = useMemo(
    () => [...state.cardio].sort((a, b) => b.date.localeCompare(a.date))[0],
    [state.cardio],
  );
  const weights = useMemo(() => [...state.weights].sort((a, b) => a.date.localeCompare(b.date)), [state.weights]);
  const currentWeight = weights.at(-1)?.weight ?? state.settings.startWeight;
  const weightDelta = Math.round((currentWeight - state.settings.startWeight) * 10) / 10;

  const insights = useMemo(
    () => (wizard.doneToday ? analyzeDay(state, TODAY).slice(0, 3) : []),
    [wizard.doneToday, state],
  );

  const weekDays = useMemo(() => {
    const start = startOfWeek(TODAY);
    return Array.from({ length: 7 }, (_, i) => {
      const d = addDays(start, i);
      return {
        date: d,
        letter: ["L", "M", "M", "J", "V", "S", "D"][i],
        validated: state.validatedDays.includes(d),
        isToday: d === todayISO(),
        future: d > todayISO(),
      };
    });
  }, [state.validatedDays]);

  return (
    <div className="space-y-6">
      {/* En-tête + compte à rebours */}
      <div className="flex flex-wrap items-end justify-between gap-3 animate-fade-in">
        <div>
          <p className="text-sm capitalize text-content-lo">{formatLongDate()}</p>
          <h1 className="mt-0.5 text-3xl font-bold tracking-tight text-content-hi sm:text-4xl">
            {greeting()}, {state.settings.name}.
          </h1>
        </div>
        <div className="rounded-2xl border border-surface-line bg-surface-base px-4 py-2 text-center">
          <div className="flex items-center gap-1.5 text-2xl font-bold tnum" style={{ color: "rgb(var(--accent))" }}>
            <Clock size={18} /> {daysLeft}
          </div>
          <div className="text-[11px] text-content-lo">jours avant le concours</div>
        </div>
      </div>

      {/* CTA Bilan du soir */}
      {wizard.doneToday ? (
        <div className="card p-5 animate-fade-in">
          <div className="flex items-center gap-2 text-sm font-semibold text-emerald-400">
            <CheckCircle2 size={18} /> Bilan du soir fait ✓
          </div>
          {insights.length > 0 && (
            <div className="mt-3 space-y-2">
              {insights.map((ins, i) => (
                <div key={i} className={`flex items-start gap-2.5 rounded-xl border p-3 text-sm ${INSIGHT_STYLE[ins.kind]}`}>
                  <span>{ins.icon}</span>
                  <span className="text-content-hi">{ins.text}</span>
                </div>
              ))}
              <Link to="/journal" className="inline-flex items-center gap-1 text-xs text-content-lo hover:text-content-mid">
                Voir le journal <ChevronRight size={13} />
              </Link>
            </div>
          )}
        </div>
      ) : (
        <button
          onClick={wizard.open}
          className="group relative w-full overflow-hidden rounded-2xl border border-surface-line p-5 text-left transition-all hover:-translate-y-0.5 hover:shadow-pop animate-fade-in"
          style={{ background: "linear-gradient(135deg, rgb(var(--accent) / 0.16), rgb(var(--accent) / 0.04))" }}
        >
          <div className="flex items-center gap-4">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl" style={{ background: "rgb(var(--accent))" }}>
              <Moon size={22} className="text-white" />
            </span>
            <div className="flex-1">
              <div className="flex items-center gap-2 font-semibold text-content-hi">
                Faire mon bilan du soir <Sparkles size={15} style={{ color: "rgb(var(--accent))" }} />
              </div>
              <p className="text-sm text-content-mid">2 minutes — l'app enregistre et analyse ta journée.</p>
            </div>
            <ChevronRight size={20} className="text-content-lo transition-transform group-hover:translate-x-1" />
          </div>
        </button>
      )}

      {/* Progression du jour + semaine */}
      <div className="grid gap-4 md:grid-cols-3">
        <div className="card flex items-center gap-5 p-5">
          <Ring percent={prog.percent} size={104}>
            <div className="text-center">
              <div className="text-2xl font-bold tnum text-content-hi">{prog.percent}%</div>
              <div className="text-[10px] uppercase tracking-wide text-content-lo">Jour</div>
            </div>
          </Ring>
          <div className="space-y-1.5 text-sm">
            <div className="flex items-center gap-2"><Flame size={15} className="text-orange-400" /><b className="tnum text-content-hi">{streak}</b><span className="text-content-lo">jours de série</span></div>
            <div className="flex items-center gap-2"><Check size={15} className="text-emerald-400" /><b className="tnum text-content-hi">{prog.done}</b><span className="text-content-lo">/ {prog.total} objectifs</span></div>
          </div>
        </div>

        <div className="card p-5 md:col-span-2">
          <span className="label">Ma semaine</span>
          <div className="mt-3 flex justify-between">
            {weekDays.map((d) => (
              <div key={d.date} className="flex flex-col items-center gap-1.5">
                <span className="text-xs text-content-lo">{d.letter}</span>
                <span
                  className="grid h-9 w-9 place-items-center rounded-full text-xs font-semibold transition-colors"
                  style={{
                    background: d.validated ? "rgb(var(--accent))" : "rgb(var(--surface-base))",
                    color: d.validated ? "#fff" : d.future ? "rgb(var(--content-lo))" : "rgb(var(--content-mid))",
                    border: d.isToday ? "2px solid rgb(var(--accent))" : "1px solid rgb(var(--surface-line))",
                    opacity: d.future ? 0.5 : 1,
                  }}
                >
                  {d.validated ? <Check size={15} /> : fromISO(d.date).getDate()}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-center gap-2 text-sm">
            <Quote size={15} className="shrink-0" style={{ color: "rgb(var(--accent))" }} />
            <p className="text-content-mid">« {q.text} » <span className="text-content-lo">— {q.author}</span></p>
          </div>
        </div>
      </div>

      {/* Cartes récap */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <RecapCard icon={<Dumbbell size={16} />} accent="#a78bfa" label="Dernière séance"
          value={lastStrength ? lastStrength.title : "—"}
          sub={lastStrength ? `${fromISO(lastStrength.date).toLocaleDateString("fr-FR", { day: "2-digit", month: "short" })} · ${lastStrength.exercises.length} exos` : "Aucune séance"}
          to="/entrainement" />
        <RecapCard icon={<Footprints size={16} />} accent="#38bdf8" label="Dernière course"
          value={lastCardio ? `${lastCardio.distanceKm} km` : "—"}
          sub={lastCardio ? `${fromISO(lastCardio.date).toLocaleDateString("fr-FR", { day: "2-digit", month: "short" })} · ${paceLabel(lastCardio.distanceKm, lastCardio.durationMin)}` : "Aucune course"}
          to="/entrainement" />
        <RecapCard icon={<Scale size={16} />} accent="#34d399" label="Poids actuel"
          value={`${currentWeight} kg`}
          sub={`${weightDelta === 0 ? "±0" : weightDelta > 0 ? "+" + weightDelta : weightDelta} kg · objectif ${state.settings.targetWeight} kg`}
          to="/poids" />
      </div>

      {/* Objectifs du jour */}
      <div>
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-content-hi">Objectifs du jour</h2>
          <Link to="/calendrier" className="text-sm text-content-lo hover:text-content-mid">Calendrier →</Link>
        </div>
        <div className="space-y-2">
          {tasks.map((t) => {
            const done = t.status === "done";
            return (
              <button
                key={t.id}
                onClick={() => updateTask(t.id, { status: done ? "todo" : "done" })}
                className="flex w-full items-center gap-3 rounded-xl border border-surface-line bg-surface-base px-4 py-3 text-left transition-colors hover:border-content-lo"
              >
                <span
                  className="grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 transition-colors"
                  style={{
                    borderColor: done ? "rgb(var(--accent))" : "rgb(var(--surface-line))",
                    background: done ? "rgb(var(--accent))" : "transparent",
                  }}
                >
                  {done && <Check size={13} className="text-white" />}
                </span>
                <span className={`flex-1 text-sm ${done ? "text-content-lo line-through" : "text-content-hi"}`}>{t.title}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function RecapCard({
  icon,
  accent,
  label,
  value,
  sub,
  to,
}: {
  icon: React.ReactNode;
  accent: string;
  label: string;
  value: string;
  sub: string;
  to: string;
}) {
  return (
    <Link to={to} className="card group flex items-center gap-3 p-4 transition-all hover:-translate-y-0.5 hover:shadow-pop">
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl" style={{ background: `${accent}22`, color: accent }}>
        {icon}
      </span>
      <div className="min-w-0 flex-1">
        <div className="text-xs text-content-lo">{label}</div>
        <div className="truncate font-semibold text-content-hi">{value}</div>
        <div className="truncate text-xs text-content-lo">{sub}</div>
      </div>
      <ChevronRight size={16} className="text-content-lo transition-transform group-hover:translate-x-0.5" />
    </Link>
  );
}
