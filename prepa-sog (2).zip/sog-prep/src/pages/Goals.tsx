import { useEffect, useState } from "react";
import { Plus, Star, Trash2, Minus } from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { ProgressBar, Modal } from "../components/ui/Primitives";
import { useStore } from "../lib/store";
import type { Goal } from "../lib/types";
import { pct } from "../lib/utils";

export default function Goals() {
  const { state, addGoal, updateGoal, removeGoal } = useStore();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Goal | null>(null);

  const primary = state.goals.find((g) => g.primary);
  const others = state.goals.filter((g) => !g.primary);

  const step = (g: Goal, dir: number) => {
    // Incrément adaptatif selon l'unité
    const inc = g.unit === "%" ? 1 : g.unit === "kg" ? 0.5 : 1;
    updateGoal(g.id, { current: Math.round((g.current + dir * inc) * 10) / 10 });
  };

  return (
    <div>
      <PageHeader
        title="Objectifs"
        subtitle="Ton cap principal et tes cibles mesurables."
        actions={
          <button
            className="btn-primary"
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus size={16} /> Objectif
          </button>
        }
      />

      {primary && (
        <div className="card relative mb-4 overflow-hidden p-5">
          <div
            className="pointer-events-none absolute right-0 top-0 h-32 w-32 rounded-full opacity-20 blur-3xl"
            style={{ background: "rgb(var(--accent))" }}
          />
          <div className="mb-2 flex items-center gap-2">
            <Star size={16} className="fill-current" style={{ color: "rgb(var(--accent))" }} />
            <span className="label">Objectif principal</span>
          </div>
          <div className="flex items-baseline justify-between">
            <h2 className="text-2xl font-bold text-content-hi">{primary.title}</h2>
            <span className="text-3xl font-bold tnum" style={{ color: "rgb(var(--accent))" }}>
              {pct(primary.current, primary.target)}%
            </span>
          </div>
          <ProgressBar value={pct(primary.current, primary.target)} className="mt-4" height={14} />
          <div className="mt-3 flex items-center gap-2">
            <button className="btn-outline !py-1" onClick={() => step(primary, -1)}>
              <Minus size={14} />
            </button>
            <span className="tnum text-sm text-content-mid">
              {primary.current} / {primary.target} {primary.unit}
            </span>
            <button className="btn-outline !py-1" onClick={() => step(primary, 1)}>
              <Plus size={14} />
            </button>
            <button
              className="btn-ghost ml-auto !p-2"
              onClick={() => {
                setEditing(primary);
                setOpen(true);
              }}
            >
              Modifier
            </button>
          </div>
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2">
        {others.map((g) => (
          <div key={g.id} className="card group p-4">
            <div className="flex items-start justify-between gap-2">
              <h3 className="font-medium text-content-hi">{g.title}</h3>
              <button
                className="btn-ghost !p-1.5 text-content-lo opacity-0 transition-opacity hover:text-red-400 group-hover:opacity-100"
                onClick={() => removeGoal(g.id)}
                aria-label="Supprimer"
              >
                <Trash2 size={14} />
              </button>
            </div>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="tnum text-sm text-content-mid">
                {g.current} / {g.target} {g.unit}
              </span>
              <span className="tnum text-sm font-semibold" style={{ color: "rgb(var(--accent))" }}>
                {pct(g.current, g.target)}%
              </span>
            </div>
            <ProgressBar value={pct(g.current, g.target)} className="mt-2" />
            <div className="mt-3 flex items-center gap-2">
              <button className="btn-outline flex-1 !py-1" onClick={() => step(g, -1)}>
                <Minus size={14} />
              </button>
              <button className="btn-outline flex-1 !py-1" onClick={() => step(g, 1)}>
                <Plus size={14} />
              </button>
              <button
                className="btn-ghost !py-1"
                onClick={() => {
                  setEditing(g);
                  setOpen(true);
                }}
              >
                Éditer
              </button>
            </div>
          </div>
        ))}
      </div>

      <GoalEditor
        open={open}
        onClose={() => setOpen(false)}
        initial={editing}
        onSave={(draft) => {
          if (editing) updateGoal(editing.id, draft);
          else addGoal(draft);
        }}
      />
    </div>
  );
}

function GoalEditor({
  open,
  onClose,
  onSave,
  initial,
}: {
  open: boolean;
  onClose: () => void;
  onSave: (g: Omit<Goal, "id">) => void;
  initial: Goal | null;
}) {
  const [title, setTitle] = useState("");
  const [current, setCurrent] = useState(0);
  const [target, setTarget] = useState(100);
  const [unit, setUnit] = useState("%");
  const [primary, setPrimary] = useState(false);

  useEffect(() => {
    if (open) {
      setTitle(initial?.title ?? "");
      setCurrent(initial?.current ?? 0);
      setTarget(initial?.target ?? 100);
      setUnit(initial?.unit ?? "%");
      setPrimary(initial?.primary ?? false);
    }
  }, [open, initial]);

  const save = () => {
    if (!title.trim()) return;
    onSave({ title: title.trim(), current, target, unit, primary });
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={initial ? "Modifier l'objectif" : "Nouvel objectif"}
      footer={
        <>
          <button className="btn-ghost" onClick={onClose}>
            Annuler
          </button>
          <button className="btn-primary" onClick={save} disabled={!title.trim()}>
            {initial ? "Enregistrer" : "Ajouter"}
          </button>
        </>
      }
    >
      <div className="space-y-4">
        <div>
          <label className="label mb-1.5 block">Intitulé</label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} className="input" autoFocus />
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="label mb-1.5 block">Actuel</label>
            <input type="number" value={current} onChange={(e) => setCurrent(Number(e.target.value))} className="input" />
          </div>
          <div>
            <label className="label mb-1.5 block">Cible</label>
            <input type="number" value={target} onChange={(e) => setTarget(Number(e.target.value))} className="input" />
          </div>
          <div>
            <label className="label mb-1.5 block">Unité</label>
            <input value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="%" className="input" />
          </div>
        </div>
        <label className="flex items-center gap-2.5 text-sm text-content-mid">
          <input
            type="checkbox"
            checked={primary}
            onChange={(e) => setPrimary(e.target.checked)}
            className="h-4 w-4 accent-[rgb(var(--accent))]"
          />
          Objectif principal (affiché sur le tableau de bord)
        </label>
      </div>
    </Modal>
  );
}
