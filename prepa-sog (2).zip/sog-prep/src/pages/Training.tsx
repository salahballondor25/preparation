import { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import {
  Plus,
  Trash2,
  Dumbbell,
  Footprints,
  Timer,
  Gauge,
  Flame,
  X,
  Pencil,
  TrendingUp,
} from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { StatCard, Segmented, Modal, EmptyState } from "../components/ui/Primitives";
import { useStore } from "../lib/store";
import type { ExerciseDef, MuscleGroup, SessionType, StrengthExercise } from "../lib/types";
import {
  fromISO,
  todayISO,
  paceLabel,
  estimateRunCalories,
  MUSCLE_META,
  SESSION_TYPE_META,
} from "../lib/utils";
import { exerciseHistory, trackedExercises, trainingSummary } from "../lib/analysis";

type Tab = "seances" | "cardio" | "exercices" | "progression";

export default function Training() {
  const [tab, setTab] = useState<Tab>("seances");
  const summary = useTrainingSummary();

  return (
    <div>
      <PageHeader title="Entraînement" subtitle="Séances, cardio, exercices et progression — tout au même endroit." />

      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={<Dumbbell size={16} />} label="Séances" value={summary.strengthSessions} accent="#a78bfa" />
        <StatCard icon={<Footprints size={16} />} label="Km / mois" value={`${summary.monthlyKm}`} accent="#38bdf8" />
        <StatCard icon={<Timer size={16} />} label="Temps total" value={`${Math.round(summary.totalTrainingMin / 6) / 10} h`} />
        <StatCard icon={<Flame size={16} />} label="Meilleure semaine" value={`${summary.bestWeek} séances`} accent="#fb923c" />
      </div>

      <div className="mb-5 overflow-x-auto">
        <Segmented
          value={tab}
          onChange={(v) => setTab(v as Tab)}
          options={[
            { value: "seances", label: "Séances" },
            { value: "cardio", label: "Cardio" },
            { value: "exercices", label: "Exercices" },
            { value: "progression", label: "Progression" },
          ]}
        />
      </div>

      {tab === "seances" && <SessionsTab />}
      {tab === "cardio" && <CardioTab />}
      {tab === "exercices" && <ExercisesTab />}
      {tab === "progression" && <ProgressionTab />}
    </div>
  );
}

function useTrainingSummary() {
  const { state } = useStore();
  return useMemo(() => trainingSummary(state), [state]);
}

// ---------------- Séances ----------------
function SessionsTab() {
  const { state, removeStrength } = useStore();
  const [open, setOpen] = useState(false);

  return (
    <div>
      <div className="mb-3 flex justify-end">
        <button className="btn-primary" onClick={() => setOpen(true)}>
          <Plus size={16} /> Séance
        </button>
      </div>
      {state.strength.length === 0 ? (
        <EmptyState
          icon={<Dumbbell size={28} />}
          title="Aucune séance"
          hint="Ajoute une séance ici, ou remplis ton bilan du soir depuis le tableau de bord."
        />
      ) : (
        <div className="space-y-3">
          {state.strength.map((s) => (
            <div key={s.id} className="card group p-4">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="flex items-center gap-2 font-semibold text-content-hi">
                    {s.type ? SESSION_TYPE_META[s.type].emoji : "💪"} {s.title}
                  </h3>
                  <p className="text-xs capitalize text-content-lo">
                    {fromISO(s.date).toLocaleDateString("fr-FR", { weekday: "long", day: "2-digit", month: "long" })}
                  </p>
                </div>
                <button
                  className="btn-ghost !p-1.5 text-content-lo opacity-0 transition-opacity hover:text-red-400 group-hover:opacity-100"
                  onClick={() => removeStrength(s.id)}
                >
                  <Trash2 size={15} />
                </button>
              </div>
              <div className="mt-3 space-y-2">
                {s.exercises.map((ex, i) => (
                  <div key={i} className="rounded-xl border border-surface-line bg-surface-base p-3">
                    <div className="text-sm font-medium text-content-hi">{ex.name}</div>
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      {ex.sets.map((set, j) => (
                        <span key={j} className="chip bg-surface-raised text-content-mid tnum">
                          {set.reps} × {set.weight > 0 ? `${set.weight} kg` : "PdC"}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              {s.comment && <p className="mt-3 text-sm italic text-content-mid">« {s.comment} »</p>}
            </div>
          ))}
        </div>
      )}
      <SessionModal open={open} onClose={() => setOpen(false)} />
    </div>
  );
}

function SessionModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { state, addStrength } = useStore();
  const [date, setDate] = useState(todayISO());
  const [type, setType] = useState<SessionType>("push");
  const [exercises, setExercises] = useState<StrengthExercise[]>([{ name: "", sets: [{ reps: 10, weight: 20 }] }]);

  const save = () => {
    const clean = exercises.filter((e) => e.name.trim()).map((e) => ({ ...e, name: e.name.trim() }));
    if (clean.length === 0) return;
    addStrength({ date, title: SESSION_TYPE_META[type].label, type, exercises: clean });
    setExercises([{ name: "", sets: [{ reps: 10, weight: 20 }] }]);
    setType("push");
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Nouvelle séance"
      footer={
        <>
          <button className="btn-ghost" onClick={onClose}>Annuler</button>
          <button className="btn-primary" onClick={save}>Enregistrer</button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <label className="block">
            <span className="label mb-1.5 block">Type</span>
            <select value={type} onChange={(e) => setType(e.target.value as SessionType)} className="input">
              {(Object.keys(SESSION_TYPE_META) as SessionType[]).map((t) => (
                <option key={t} value={t}>{SESSION_TYPE_META[t].label}</option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label mb-1.5 block">Date</span>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" />
          </label>
        </div>
        <div className="space-y-3">
          {exercises.map((ex, i) => (
            <div key={i} className="rounded-xl border border-surface-line bg-surface-base p-3">
              <div className="flex items-center gap-2">
                <input
                  value={ex.name}
                  onChange={(e) => setExercises((x) => x.map((v, k) => (k === i ? { ...v, name: e.target.value } : v)))}
                  placeholder="Exercice"
                  list="exdb"
                  className="input flex-1"
                />
                {exercises.length > 1 && (
                  <button className="btn-ghost !p-2 text-content-lo hover:text-red-400" onClick={() => setExercises((x) => x.filter((_, k) => k !== i))}>
                    <X size={16} />
                  </button>
                )}
              </div>
              <div className="mt-2 space-y-1.5">
                {ex.sets.map((set, j) => (
                  <div key={j} className="flex items-center gap-2 text-sm">
                    <span className="w-6 text-xs text-content-lo">{j + 1}.</span>
                    <input type="number" value={set.reps} onChange={(e) => setExercises((x) => x.map((v, k) => k === i ? { ...v, sets: v.sets.map((s, l) => l === j ? { ...s, reps: Number(e.target.value) } : s) } : v))} className="input !py-1.5 w-16 text-center" />
                    <span className="text-content-lo">×</span>
                    <input type="number" value={set.weight} onChange={(e) => setExercises((x) => x.map((v, k) => k === i ? { ...v, sets: v.sets.map((s, l) => l === j ? { ...s, weight: Number(e.target.value) } : s) } : v))} className="input !py-1.5 w-16 text-center" />
                    <span className="text-content-lo">kg</span>
                  </div>
                ))}
                <button className="btn-ghost !py-1 text-xs" onClick={() => setExercises((x) => x.map((v, k) => k === i ? { ...v, sets: [...v.sets, v.sets.at(-1) ?? { reps: 10, weight: 20 }] } : v))}>
                  <Plus size={12} /> Série
                </button>
              </div>
            </div>
          ))}
          <datalist id="exdb">
            {state.exerciseDb.map((e) => <option key={e.id} value={e.name} />)}
          </datalist>
          <button className="btn-outline w-full" onClick={() => setExercises((x) => [...x, { name: "", sets: [{ reps: 10, weight: 20 }] }])}>
            <Plus size={15} /> Exercice
          </button>
        </div>
      </div>
    </Modal>
  );
}

// ---------------- Cardio ----------------
function CardioTab() {
  const { state, addCardio, removeCardio } = useStore();
  const [date, setDate] = useState(todayISO());
  const [dist, setDist] = useState("");
  const [dur, setDur] = useState("");

  const sorted = useMemo(() => [...state.cardio].sort((a, b) => a.date.localeCompare(b.date)), [state.cardio]);
  const data = sorted.map((c) => ({ label: fromISO(c.date).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }), km: c.distanceKm }));
  const totalKm = Math.round(sorted.reduce((a, c) => a + c.distanceKm, 0) * 10) / 10;
  const best = sorted.reduce((m, c) => Math.max(m, c.distanceKm), 0);

  const add = () => {
    const d = parseFloat(dist.replace(",", ".")), t = parseFloat(dur.replace(",", "."));
    if (!d || !t) return;
    addCardio({ date, distanceKm: d, durationMin: t, calories: estimateRunCalories(d, state.settings.targetWeight) });
    setDist(""); setDur("");
  };

  return (
    <div>
      <div className="card mb-4 grid grid-cols-2 gap-3 p-4 sm:grid-cols-4 sm:items-end">
        <label className="block"><span className="label mb-1.5 block">Date</span><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" /></label>
        <label className="block"><span className="label mb-1.5 block">Distance (km)</span><input type="number" step="0.1" value={dist} onChange={(e) => setDist(e.target.value)} placeholder="5" className="input" /></label>
        <label className="block"><span className="label mb-1.5 block">Temps (min)</span><input type="number" step="0.1" value={dur} onChange={(e) => setDur(e.target.value)} placeholder="28" className="input" /></label>
        <button className="btn-primary" onClick={add} disabled={!dist || !dur}><Plus size={16} /> Ajouter</button>
      </div>

      <div className="mb-4 grid grid-cols-3 gap-3">
        <StatCard icon={<Footprints size={16} />} label="Total" value={`${totalKm} km`} />
        <StatCard icon={<Gauge size={16} />} label="Record" value={`${best} km`} />
        <StatCard icon={<Timer size={16} />} label="Sorties" value={sorted.length} />
      </div>

      {data.length > 0 && (
        <div className="card mb-4 p-4">
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
                <defs>
                  <linearGradient id="kmg" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="rgb(var(--accent))" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="rgb(var(--accent))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgb(var(--surface-line))" vertical={false} />
                <XAxis dataKey="label" tick={{ fill: "rgb(var(--content-lo))", fontSize: 11 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fill: "rgb(var(--content-lo))", fontSize: 11 }} tickLine={false} axisLine={false} width={30} />
                <Tooltip contentStyle={tooltipStyle} formatter={(v) => [`${v} km`, "Distance"]} />
                <Area type="monotone" dataKey="km" stroke="rgb(var(--accent))" strokeWidth={2.5} fill="url(#kmg)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div className="space-y-1.5">
        {[...sorted].reverse().map((c) => (
          <div key={c.id} className="group flex items-center justify-between rounded-xl border border-surface-line bg-surface-base px-3 py-2.5">
            <div>
              <div className="text-sm font-medium text-content-hi">{c.distanceKm} km · {c.durationMin} min</div>
              <div className="text-xs text-content-lo">
                {fromISO(c.date).toLocaleDateString("fr-FR", { day: "2-digit", month: "short" })} · {paceLabel(c.distanceKm, c.durationMin)}{c.calories ? ` · ${c.calories} kcal` : ""}
              </div>
            </div>
            <button className="btn-ghost !p-1.5 text-content-lo opacity-0 transition-opacity hover:text-red-400 group-hover:opacity-100" onClick={() => removeCardio(c.id)}>
              <Trash2 size={15} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------------- Base d'exercices ----------------
function ExercisesTab() {
  const { state, addExercise, updateExercise, removeExercise } = useStore();
  const [name, setName] = useState("");
  const [muscle, setMuscle] = useState<MuscleGroup>("pectoraux");
  const [editing, setEditing] = useState<ExerciseDef | null>(null);

  const grouped = useMemo(() => {
    const map = new Map<MuscleGroup, ExerciseDef[]>();
    for (const e of state.exerciseDb) {
      const arr = map.get(e.muscle) ?? [];
      arr.push(e); map.set(e.muscle, arr);
    }
    return [...map.entries()].sort((a, b) => Object.keys(MUSCLE_META).indexOf(a[0]) - Object.keys(MUSCLE_META).indexOf(b[0]));
  }, [state.exerciseDb]);

  const submit = () => {
    if (!name.trim()) return;
    if (editing) { updateExercise(editing.id, { name: name.trim(), muscle }); setEditing(null); }
    else addExercise({ name: name.trim(), muscle });
    setName("");
  };

  return (
    <div>
      <div className="card mb-4 flex flex-wrap items-end gap-3 p-4">
        <label className="flex-1 min-w-[140px]"><span className="label mb-1.5 block">Exercice</span>
          <input value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} placeholder="Ex : Rowing haltère" className="input" />
        </label>
        <label className="min-w-[130px]"><span className="label mb-1.5 block">Groupe</span>
          <select value={muscle} onChange={(e) => setMuscle(e.target.value as MuscleGroup)} className="input">
            {(Object.keys(MUSCLE_META) as MuscleGroup[]).map((m) => <option key={m} value={m}>{MUSCLE_META[m].label}</option>)}
          </select>
        </label>
        <button className="btn-primary" onClick={submit}>{editing ? <><Pencil size={15} /> Modifier</> : <><Plus size={16} /> Ajouter</>}</button>
      </div>

      <div className="space-y-5">
        {grouped.map(([m, list]) => (
          <div key={m}>
            <h3 className="mb-2 text-sm font-semibold text-content-mid">{MUSCLE_META[m].emoji} {MUSCLE_META[m].label} <span className="text-xs font-normal text-content-lo">{list.length}</span></h3>
            <div className="flex flex-wrap gap-1.5">
              {list.map((e) => (
                <span key={e.id} className="group inline-flex items-center gap-1.5 rounded-full border border-surface-line bg-surface-base py-1 pl-3 pr-1.5 text-sm text-content-hi">
                  {e.name}
                  <button className="text-content-lo hover:text-accent" onClick={() => { setEditing(e); setName(e.name); setMuscle(e.muscle); }}><Pencil size={12} /></button>
                  <button className="text-content-lo hover:text-red-400" onClick={() => removeExercise(e.id)}><X size={13} /></button>
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------------- Progression par exercice ----------------
function ProgressionTab() {
  const { state } = useStore();
  const tracked = useMemo(() => trackedExercises(state), [state]);
  const [selected, setSelected] = useState(tracked[0] ?? "");
  const active = selected || tracked[0] || "";
  const history = useMemo(() => (active ? exerciseHistory(state, active) : []), [state, active]);

  if (tracked.length === 0) {
    return <EmptyState icon={<TrendingUp size={28} />} title="Pas encore de données" hint="Enregistre des séances pour voir la progression de chaque exercice." />;
  }

  const data = history.map((p) => ({
    label: fromISO(p.date).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }),
    charge: p.topWeight, volume: p.volume, reps: p.totalReps, rm: p.best1RM,
  }));
  const last = history.at(-1);
  const first = history[0];
  const gain = last && first ? Math.round((last.topWeight - first.topWeight) * 10) / 10 : 0;

  return (
    <div>
      <div className="mb-4 flex flex-wrap gap-1.5">
        {tracked.map((name) => (
          <button key={name} onClick={() => setSelected(name)} className="chip border transition-colors"
            style={{
              borderColor: active === name ? "rgb(var(--accent))" : "rgb(var(--surface-line))",
              background: active === name ? "rgb(var(--accent) / 0.14)" : "transparent",
              color: active === name ? "rgb(var(--accent))" : "rgb(var(--content-mid))",
            }}>
            {name}
          </button>
        ))}
      </div>

      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="Charge max" value={last ? `${last.topWeight} kg` : "—"} />
        <StatCard label="1RM estimé" value={last ? `${last.best1RM} kg` : "—"} accent="#a78bfa" />
        <StatCard label="Progression" value={`${gain > 0 ? "+" : ""}${gain} kg`} accent={gain >= 0 ? "#10b981" : "#ef4444"} />
        <StatCard label="Séances" value={history.length} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <MiniChart title="Charge max (kg)" data={data} dataKey="charge" type="line" />
        <MiniChart title="Volume total" data={data} dataKey="volume" type="area" />
        <MiniChart title="Répétitions totales" data={data} dataKey="reps" type="area" />
        <MiniChart title="1RM estimé (kg)" data={data} dataKey="rm" type="line" />
      </div>
    </div>
  );
}

function MiniChart({ title, data, dataKey, type }: { title: string; data: Record<string, unknown>[]; dataKey: string; type: "line" | "area" }) {
  return (
    <div className="card p-4">
      <h4 className="mb-3 text-sm font-semibold text-content-mid">{title}</h4>
      <div className="h-44">
        <ResponsiveContainer width="100%" height="100%">
          {type === "line" ? (
            <LineChart data={data} margin={{ top: 6, right: 6, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgb(var(--surface-line))" vertical={false} />
              <XAxis dataKey="label" tick={{ fill: "rgb(var(--content-lo))", fontSize: 10 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fill: "rgb(var(--content-lo))", fontSize: 10 }} tickLine={false} axisLine={false} width={30} />
              <Tooltip contentStyle={tooltipStyle} />
              <Line type="monotone" dataKey={dataKey} stroke="rgb(var(--accent))" strokeWidth={2.5} dot={{ r: 2.5, fill: "rgb(var(--accent))" }} />
            </LineChart>
          ) : (
            <AreaChart data={data} margin={{ top: 6, right: 6, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id={`g-${dataKey}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="rgb(var(--accent))" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="rgb(var(--accent))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgb(var(--surface-line))" vertical={false} />
              <XAxis dataKey="label" tick={{ fill: "rgb(var(--content-lo))", fontSize: 10 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fill: "rgb(var(--content-lo))", fontSize: 10 }} tickLine={false} axisLine={false} width={30} />
              <Tooltip contentStyle={tooltipStyle} />
              <Area type="monotone" dataKey={dataKey} stroke="rgb(var(--accent))" strokeWidth={2.5} fill={`url(#g-${dataKey})`} />
            </AreaChart>
          )}
        </ResponsiveContainer>
      </div>
    </div>
  );
}

const tooltipStyle = {
  background: "rgb(var(--surface-raised))",
  border: "1px solid rgb(var(--surface-line))",
  borderRadius: 12,
  color: "rgb(var(--content-hi))",
} as const;
