import { useMemo, useRef, useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  CheckCheck,
  ListChecks,
  Timer,
  Percent,
} from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { Segmented, ProgressBar } from "../components/ui/Primitives";
import { TaskRow } from "../components/TaskRow";
import { TaskEditor, type TaskDraft } from "../components/TaskEditor";
import { useStore } from "../lib/store";
import { dayProgress } from "../lib/selectors";
import type { Task } from "../lib/types";
import {
  addDays,
  formatDayLabel,
  fromISO,
  isSameMonth,
  monthGrid,
  monthLabel,
  shortWeekday,
  startOfWeek,
  todayISO,
} from "../lib/utils";

const TODAY = todayISO();

export default function Calendar() {
  const { state, addTask, updateTask, removeTask, cycleTask, reorderTasks, awardXp, setDayNote, validateDay } =
    useStore();
  const [view, setView] = useState<"month" | "week">("month");
  const [cursor, setCursor] = useState(TODAY); // date de référence (mois/semaine affiché)
  const [selected, setSelected] = useState(TODAY);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);

  const cDate = fromISO(cursor);
  const year = cDate.getFullYear();
  const month = cDate.getMonth();

  const tasksByDay = useMemo(() => {
    const map = new Map<string, Task[]>();
    for (const t of state.tasks) {
      const arr = map.get(t.date) ?? [];
      arr.push(t);
      map.set(t.date, arr);
    }
    for (const arr of map.values()) arr.sort((a, b) => a.order - b.order);
    return map;
  }, [state.tasks]);

  const dayTasks = (tasksByDay.get(selected) ?? []).slice();
  const prog = dayProgress(state, selected);
  const estimated = dayTasks.reduce((a, t) => a + (t.estimatedMin ?? 0), 0);
  const validated = state.validatedDays.includes(selected);

  const shift = (dir: number) => {
    if (view === "month") {
      const d = new Date(year, month + dir, 1);
      setCursor(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`);
    } else {
      setCursor(addDays(cursor, dir * 7));
    }
  };

  const openNew = () => {
    setEditing(null);
    setEditorOpen(true);
  };
  const openEdit = (t: Task) => {
    setEditing(t);
    setEditorOpen(true);
  };
  const save = (draft: TaskDraft) => {
    if (editing) updateTask(editing.id, draft);
    else addTask({ ...draft, status: "todo" });
  };

  // ---- glisser-déposer ----
  const dragId = useRef<string | null>(null);
  const [dragging, setDragging] = useState<string | null>(null);
  const [orderedIds, setOrderedIds] = useState<string[] | null>(null);
  const displayTasks =
    orderedIds && dragging
      ? (orderedIds.map((id) => dayTasks.find((t) => t.id === id)!).filter(Boolean) as Task[])
      : dayTasks;

  const onDragStart = (id: string) => {
    dragId.current = id;
    setDragging(id);
    setOrderedIds(dayTasks.map((t) => t.id));
  };
  const onDragOverRow = (overId: string) => (e: React.DragEvent) => {
    e.preventDefault();
    if (!dragId.current || dragId.current === overId || !orderedIds) return;
    const next = orderedIds.filter((id) => id !== dragId.current);
    const idx = next.indexOf(overId);
    next.splice(idx, 0, dragId.current);
    setOrderedIds(next);
  };
  const onDrop = () => {
    if (orderedIds) reorderTasks(selected, orderedIds);
  };
  const onDragEnd = () => {
    dragId.current = null;
    setDragging(null);
    setOrderedIds(null);
  };

  const cycleWithXp = (t: Task) => {
    if (t.status === "todo") awardXp(10);
    cycleTask(t.id);
  };

  return (
    <div>
      <PageHeader
        title="Calendrier"
        subtitle="Chaque jour a sa propre liste. Clique sur une date pour l'ouvrir."
        actions={
          <Segmented
            value={view}
            onChange={setView}
            options={[
              { value: "month", label: "Mois" },
              { value: "week", label: "Semaine" },
            ]}
          />
        }
      />

      {/* Navigation */}
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-1">
          <button className="btn-ghost !p-2" onClick={() => shift(-1)} aria-label="Précédent">
            <ChevronLeft size={18} />
          </button>
          <button className="btn-ghost !p-2" onClick={() => shift(1)} aria-label="Suivant">
            <ChevronRight size={18} />
          </button>
          <h2 className="ml-2 text-lg font-semibold capitalize text-content-hi">
            {view === "month"
              ? monthLabel(year, month)
              : `Semaine du ${formatDayLabel(startOfWeek(cursor))}`}
          </h2>
        </div>
        <button
          className="btn-outline"
          onClick={() => {
            setCursor(TODAY);
            setSelected(TODAY);
          }}
        >
          Aujourd'hui
        </button>
      </div>

      {/* En-têtes de jours */}
      <div className="mb-1 grid grid-cols-7 gap-1.5 px-1 text-center text-[11px] font-medium text-content-lo">
        {[1, 2, 3, 4, 5, 6, 0].map((d) => (
          <div key={d}>{shortWeekday(d)}</div>
        ))}
      </div>

      {/* Grille */}
      {view === "month" ? (
        <div className="grid grid-cols-7 gap-1.5">
          {monthGrid(year, month).map((iso) => {
            const inMonth = isSameMonth(iso, year, month);
            const p = dayProgress(state, iso);
            const isToday = iso === TODAY;
            const isSel = iso === selected;
            const dayNum = fromISO(iso).getDate();
            return (
              <button
                key={iso}
                onClick={() => setSelected(iso)}
                className={`relative aspect-square rounded-xl border p-1.5 text-left transition-all sm:aspect-[4/3] ${
                  isSel
                    ? "border-accent bg-accent-soft"
                    : "border-surface-line bg-surface-card hover:border-surface-line/60"
                } ${inMonth ? "" : "opacity-35"}`}
              >
                <span
                  className={`inline-grid h-6 w-6 place-items-center rounded-full text-xs font-semibold tnum ${
                    isToday ? "text-white" : "text-content-hi"
                  }`}
                  style={isToday ? { background: "rgb(var(--accent))" } : undefined}
                >
                  {dayNum}
                </span>
                {p.total > 0 && (
                  <div className="absolute inset-x-1.5 bottom-1.5">
                    <div className="mb-1 hidden text-[10px] text-content-lo sm:block">
                      {p.done}/{p.total}
                    </div>
                    <ProgressBar
                      value={p.percent}
                      height={4}
                      color={p.percent >= 100 ? "#10b981" : undefined}
                    />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-7">
          {Array.from({ length: 7 }, (_, i) => addDays(startOfWeek(cursor), i)).map((iso) => {
            const p = dayProgress(state, iso);
            const isToday = iso === TODAY;
            const isSel = iso === selected;
            return (
              <button
                key={iso}
                onClick={() => setSelected(iso)}
                className={`rounded-xl border p-3 text-left transition-all sm:min-h-[120px] ${
                  isSel ? "border-accent bg-accent-soft" : "border-surface-line bg-surface-card"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs text-content-lo">{shortWeekday(fromISO(iso).getDay())}</span>
                  <span
                    className={`grid h-6 w-6 place-items-center rounded-full text-xs font-semibold ${
                      isToday ? "text-white" : "text-content-hi"
                    }`}
                    style={isToday ? { background: "rgb(var(--accent))" } : undefined}
                  >
                    {fromISO(iso).getDate()}
                  </span>
                </div>
                {p.total > 0 && (
                  <div className="mt-3 space-y-1">
                    <div className="text-[11px] text-content-lo">
                      {p.done}/{p.total} · {p.percent}%
                    </div>
                    <ProgressBar value={p.percent} height={4} color={p.percent >= 100 ? "#10b981" : undefined} />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* ---- Panneau du jour sélectionné ---- */}
      <div className="card mt-5 p-5 animate-fade-in">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-lg font-semibold capitalize text-content-hi">
              {formatDayLabel(selected)}
            </h3>
            <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-content-mid">
              <span className="inline-flex items-center gap-1">
                <ListChecks size={13} /> {prog.total} tâche{prog.total > 1 ? "s" : ""}
              </span>
              <span className="inline-flex items-center gap-1">
                <Percent size={13} /> {prog.percent}%
              </span>
              <span className="inline-flex items-center gap-1">
                <Timer size={13} /> {estimated} min estimées
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              className={`btn-outline ${validated ? "!border-emerald-500/50 !text-emerald-400" : ""}`}
              onClick={() => validateDay(selected)}
              disabled={validated}
            >
              <CheckCheck size={16} /> {validated ? "Journée validée" : "Valider la journée"}
            </button>
            <button className="btn-primary" onClick={openNew}>
              <Plus size={16} /> Tâche
            </button>
          </div>
        </div>

        {prog.total > 0 && <ProgressBar value={prog.percent} className="mt-4" height={8} />}

        {/* Liste des tâches */}
        <div className="mt-4 space-y-2">
          {displayTasks.length === 0 ? (
            <div className="rounded-xl border border-dashed border-surface-line py-8 text-center text-sm text-content-lo">
              Aucune tâche ce jour. Clique sur « Tâche » pour commencer.
            </div>
          ) : (
            displayTasks.map((t) => (
              <TaskRow
                key={t.id}
                task={t}
                onCycle={() => cycleWithXp(t)}
                onEdit={() => openEdit(t)}
                onRemove={() => removeTask(t.id)}
                drag={{
                  onDragStart: () => onDragStart(t.id),
                  onDragOver: onDragOverRow(t.id),
                  onDrop,
                  onDragEnd,
                  dragging: dragging === t.id,
                }}
              />
            ))
          )}
        </div>

        {/* Notes libres */}
        <div className="mt-5">
          <label className="label mb-1.5 block">Notes du jour</label>
          <textarea
            value={state.dayMeta[selected]?.note ?? ""}
            onChange={(e) => setDayNote(selected, e.target.value)}
            placeholder="Ressenti, séance, repas, points à améliorer…"
            rows={3}
            className="input resize-y"
          />
        </div>
      </div>

      <TaskEditor
        open={editorOpen}
        onClose={() => setEditorOpen(false)}
        onSave={save}
        initial={editing}
        defaultDate={selected}
      />
    </div>
  );
}
