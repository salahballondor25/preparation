import { useMemo } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import { Moon, Zap, Droplets, Footprints, BookOpen } from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { StatCard, EmptyState } from "../components/ui/Primitives";
import { useStore } from "../lib/store";
import { fromISO } from "../lib/utils";
import type { NutritionRating } from "../lib/types";

const NUTRI: Record<NutritionRating, { label: string; emoji: string; color: string }> = {
  oui: { label: "Respectée", emoji: "😎", color: "#10b981" },
  moyen: { label: "À peu près", emoji: "😐", color: "#fbbf24" },
  non: { label: "Non", emoji: "😅", color: "#ef4444" },
};

export default function Journal() {
  const { state } = useStore();
  const logs = useMemo(() => [...state.dailyLogs].sort((a, b) => a.date.localeCompare(b.date)), [state.dailyLogs]);

  if (logs.length === 0) {
    return (
      <div>
        <PageHeader title="Journal" subtitle="L'historique de tes bilans du soir." />
        <EmptyState icon={<BookOpen size={28} />} title="Aucun bilan pour l'instant" hint="Fais ton premier bilan du soir depuis le tableau de bord." />
      </div>
    );
  }

  const recent = logs.slice(-14);
  const chartData = recent.map((l) => ({
    label: fromISO(l.date).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }),
    sommeil: l.sleepQuality ?? null,
    energie: l.energy ?? null,
    motivation: l.motivation ?? null,
    eau: l.waterL ?? null,
    pas: l.steps ? Math.round(l.steps / 1000) : null,
  }));

  const avg = (key: "sleepQuality" | "energy" | "motivation" | "waterL") => {
    const vals = logs.map((l) => l[key]).filter((v): v is number => v != null);
    if (!vals.length) return "—";
    return (Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 10) / 10).toString();
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Journal" subtitle={`${logs.length} bilan${logs.length > 1 ? "s" : ""} enregistré${logs.length > 1 ? "s" : ""}.`} />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={<Moon size={16} />} label="Sommeil moyen" value={`${avg("sleepQuality")}/5`} accent="#818cf8" />
        <StatCard icon={<Zap size={16} />} label="Énergie moyenne" value={`${avg("energy")}/10`} accent="#fbbf24" />
        <StatCard icon={<Zap size={16} />} label="Motivation moy." value={`${avg("motivation")}/10`} accent="#fb923c" />
        <StatCard icon={<Droplets size={16} />} label="Eau moyenne" value={`${avg("waterL")} L`} accent="#38bdf8" />
      </div>

      <div className="card p-4">
        <h3 className="mb-3 text-sm font-semibold text-content-mid">Énergie & motivation</h3>
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 6, right: 8, bottom: 0, left: -22 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgb(var(--surface-line))" vertical={false} />
              <XAxis dataKey="label" tick={{ fill: "rgb(var(--content-lo))", fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis domain={[0, 10]} tick={{ fill: "rgb(var(--content-lo))", fontSize: 11 }} tickLine={false} axisLine={false} width={32} />
              <Tooltip contentStyle={ts} />
              <Line type="monotone" dataKey="energie" name="Énergie" stroke="#fbbf24" strokeWidth={2.5} dot={false} connectNulls />
              <Line type="monotone" dataKey="motivation" name="Motivation" stroke="rgb(var(--accent))" strokeWidth={2.5} dot={false} connectNulls />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="card p-4">
          <h3 className="mb-3 flex items-center gap-1.5 text-sm font-semibold text-content-mid"><Footprints size={14} /> Pas (milliers)</h3>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 6, right: 8, bottom: 0, left: -24 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgb(var(--surface-line))" vertical={false} />
                <XAxis dataKey="label" tick={{ fill: "rgb(var(--content-lo))", fontSize: 10 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fill: "rgb(var(--content-lo))", fontSize: 10 }} tickLine={false} axisLine={false} width={30} />
                <Tooltip contentStyle={ts} />
                <Bar dataKey="pas" fill="rgb(var(--accent))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="card p-4">
          <h3 className="mb-3 flex items-center gap-1.5 text-sm font-semibold text-content-mid"><Moon size={14} /> Sommeil (/5)</h3>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 6, right: 8, bottom: 0, left: -24 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgb(var(--surface-line))" vertical={false} />
                <XAxis dataKey="label" tick={{ fill: "rgb(var(--content-lo))", fontSize: 10 }} tickLine={false} axisLine={false} />
                <YAxis domain={[0, 5]} tick={{ fill: "rgb(var(--content-lo))", fontSize: 10 }} tickLine={false} axisLine={false} width={30} />
                <Tooltip contentStyle={ts} />
                <Bar dataKey="sommeil" fill="#818cf8" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div>
        <h3 className="mb-2 text-sm font-semibold text-content-mid">Historique</h3>
        <div className="space-y-1.5">
          {[...logs].reverse().map((l) => (
            <div key={l.date} className="flex items-center gap-3 rounded-xl border border-surface-line bg-surface-base px-3 py-2.5">
              <div className="flex-1">
                <div className="text-sm font-medium capitalize text-content-hi">
                  {fromISO(l.date).toLocaleDateString("fr-FR", { weekday: "long", day: "2-digit", month: "long" })}
                </div>
                <div className="mt-0.5 flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-content-lo">
                  {l.trained && <span>💪 séance</span>}
                  {l.ran && <span>🏃 course</span>}
                  {l.nutrition && <span>{NUTRI[l.nutrition].emoji} {NUTRI[l.nutrition].label}</span>}
                  {l.waterL != null && <span>💧 {l.waterL} L</span>}
                  {l.steps != null && <span>👟 {l.steps.toLocaleString("fr-FR")}</span>}
                  {l.sleepQuality != null && <span>😴 {l.sleepQuality}/5</span>}
                  {l.weight != null && <span>⚖️ {l.weight} kg</span>}
                </div>
              </div>
              {l.energy != null && (
                <span className="chip bg-surface-raised text-content-mid">⚡ {l.energy}/10</span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const ts = {
  background: "rgb(var(--surface-raised))",
  border: "1px solid rgb(var(--surface-line))",
  borderRadius: 12,
  color: "rgb(var(--content-hi))",
} as const;
