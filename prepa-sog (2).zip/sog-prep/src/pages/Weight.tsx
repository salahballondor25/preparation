import { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
} from "recharts";
import { Plus, Trash2, TrendingDown, TrendingUp } from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { StatCard, EmptyState } from "../components/ui/Primitives";
import { useStore } from "../lib/store";
import { bmi, fromISO, todayISO } from "../lib/utils";

export default function Weight() {
  const { state, addWeight, removeWeight } = useStore();
  const [date, setDate] = useState(todayISO());
  const [w, setW] = useState("");

  const sorted = useMemo(
    () => [...state.weights].sort((a, b) => a.date.localeCompare(b.date)),
    [state.weights],
  );

  const data = sorted.map((e) => ({
    date: e.date,
    label: fromISO(e.date).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }),
    weight: e.weight,
  }));

  const latest = sorted[sorted.length - 1];
  const first = sorted[0];
  const delta = latest && first ? Math.round((latest.weight - first.weight) * 10) / 10 : 0;
  const targetGoal = state.goals.find((g) => g.unit === "kg");
  const target = targetGoal?.target;
  const imc = latest ? bmi(latest.weight, state.settings.heightCm) : { value: 0, label: "—" };

  const weights = sorted.map((s) => s.weight);
  const yMin = weights.length ? Math.floor(Math.min(...weights, target ?? Infinity) - 2) : 0;
  const yMax = weights.length ? Math.ceil(Math.max(...weights, target ?? -Infinity) + 2) : 100;

  const add = () => {
    const val = parseFloat(w.replace(",", "."));
    if (!val || val <= 0) return;
    addWeight(date, val);
    setW("");
  };

  return (
    <div>
      <PageHeader title="Suivi du poids" subtitle="Ta courbe, ton IMC et ton évolution." />

      {/* Saisie */}
      <div className="card mb-4 flex flex-wrap items-end gap-3 p-4">
        <div className="flex-1 min-w-[120px]">
          <label className="label mb-1.5 block">Date</label>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" />
        </div>
        <div className="flex-1 min-w-[120px]">
          <label className="label mb-1.5 block">Poids (kg)</label>
          <input
            type="number"
            step="0.1"
            value={w}
            onChange={(e) => setW(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && add()}
            placeholder="82.4"
            className="input"
          />
        </div>
        <button className="btn-primary" onClick={add} disabled={!w}>
          <Plus size={16} /> Enregistrer
        </button>
      </div>

      {/* Stats */}
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="Actuel" value={latest ? `${latest.weight} kg` : "—"} />
        <StatCard
          label="Évolution"
          value={
            <span className="flex items-center gap-1">
              {delta < 0 ? (
                <TrendingDown size={18} className="text-emerald-400" />
              ) : delta > 0 ? (
                <TrendingUp size={18} className="text-red-400" />
              ) : null}
              {delta > 0 ? "+" : ""}
              {delta} kg
            </span>
          }
        />
        <StatCard label="Objectif" value={target ? `${target} kg` : "—"} />
        <StatCard label="IMC" value={imc.value || "—"} sub={imc.label} />
      </div>

      {/* Graphique */}
      {data.length === 0 ? (
        <EmptyState title="Aucune mesure" hint="Ajoute ton premier poids pour démarrer la courbe." />
      ) : (
        <div className="card p-4">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -16 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgb(var(--surface-line))" vertical={false} />
                <XAxis dataKey="label" tick={{ fill: "rgb(var(--content-lo))", fontSize: 11 }} tickLine={false} axisLine={false} />
                <YAxis
                  domain={[yMin, yMax]}
                  tick={{ fill: "rgb(var(--content-lo))", fontSize: 11 }}
                  tickLine={false}
                  axisLine={false}
                  width={40}
                />
                <Tooltip
                  contentStyle={{
                    background: "rgb(var(--surface-raised))",
                    border: "1px solid rgb(var(--surface-line))",
                    borderRadius: 12,
                    color: "rgb(var(--content-hi))",
                  }}
                  labelStyle={{ color: "rgb(var(--content-mid))" }}
                  formatter={(v) => [`${v} kg`, "Poids"]}
                />
                {target && (
                  <ReferenceLine
                    y={target}
                    stroke="rgb(var(--accent))"
                    strokeDasharray="5 5"
                    label={{ value: "cible", fill: "rgb(var(--accent))", fontSize: 11, position: "insideTopRight" }}
                  />
                )}
                <Line
                  type="monotone"
                  dataKey="weight"
                  stroke="rgb(var(--accent))"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: "rgb(var(--accent))" }}
                  activeDot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Historique */}
      {sorted.length > 0 && (
        <div className="mt-4">
          <h3 className="mb-2 text-sm font-semibold text-content-mid">Historique</h3>
          <div className="space-y-1.5">
            {[...sorted].reverse().map((e) => (
              <div
                key={e.id}
                className="group flex items-center justify-between rounded-xl border border-surface-line bg-surface-base px-3 py-2.5 text-sm"
              >
                <span className="capitalize text-content-mid">
                  {fromISO(e.date).toLocaleDateString("fr-FR", {
                    weekday: "short",
                    day: "2-digit",
                    month: "long",
                    year: "numeric",
                  })}
                </span>
                <div className="flex items-center gap-3">
                  <span className="tnum font-semibold text-content-hi">{e.weight} kg</span>
                  <button
                    className="btn-ghost !p-1 text-content-lo opacity-0 transition-opacity hover:text-red-400 group-hover:opacity-100"
                    onClick={() => removeWeight(e.id)}
                    aria-label="Supprimer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
