import { useMemo } from "react";
import {
  CheckCircle2,
  XCircle,
  Percent,
  Dumbbell,
  Footprints,
  Flame,
  Timer,
  ShoppingCart,
  Scale,
  Zap,
} from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { StatCard, ProgressBar } from "../components/ui/Primitives";
import { Heatmap, HeatmapLegend } from "../components/Heatmap";
import { useStore } from "../lib/store";
import { globalStats } from "../lib/selectors";
import { trainingSummary } from "../lib/analysis";
import { BADGES, levelFromXp } from "../lib/badges";
import { formatDuration, fromISO } from "../lib/utils";

export default function Stats() {
  const { state } = useStore();
  const s = useMemo(() => globalStats(state), [state]);
  const ts = useMemo(() => trainingSummary(state), [state]);
  const level = levelFromXp(state.gamification.xp);
  const unlocked = new Set(state.gamification.unlockedBadges);

  return (
    <div className="space-y-6">
      <PageHeader title="Statistiques" subtitle="Ta régularité et tes performances en un coup d'œil." />

      {/* Cartes principales */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        <StatCard icon={<CheckCircle2 size={16} />} label="Tâches réussies" value={s.done} accent="#10b981" />
        <StatCard icon={<XCircle size={16} />} label="Tâches ratées" value={s.failed} accent="#ef4444" />
        <StatCard icon={<Percent size={16} />} label="Taux de réussite" value={`${s.successRate}%`} />
        <StatCard icon={<Flame size={16} />} label="Série actuelle" value={`${s.current} j`} accent="#fb923c" />
        <StatCard icon={<Dumbbell size={16} />} label="Séances muscu" value={s.sessions} accent="#a78bfa" />
        <StatCard icon={<Footprints size={16} />} label="Kilomètres" value={`${s.totalKm} km`} accent="#38bdf8" />
        <StatCard icon={<Timer size={16} />} label="Temps d'entraînement" value={formatDuration(s.totalTrainingMin)} />
        <StatCard icon={<Zap size={16} />} label="Calories brûlées" value={s.caloriesBurned} accent="#fbbf24" />
        <StatCard icon={<ShoppingCart size={16} />} label="Articles de courses" value={s.shoppingCount} />
        <StatCard icon={<Flame size={16} />} label="Meilleure série" value={`${s.best} j`} accent="#fb923c" />
        <StatCard
          icon={<Scale size={16} />}
          label="Évolution du poids"
          value={`${s.weightDelta > 0 ? "+" : ""}${s.weightDelta} kg`}
        />
        <StatCard icon={<Footprints size={16} />} label="Sorties cardio" value={s.cardioSessions} accent="#38bdf8" />
      </div>

      {/* Records & agrégats automatiques */}
      <div className="card p-5">
        <h2 className="mb-4 font-semibold text-content-hi">Performances (calcul automatique)</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <StatCard label="Km cette semaine" value={`${ts.weeklyKm} km`} accent="#38bdf8" />
          <StatCard label="Km ce mois" value={`${ts.monthlyKm} km`} accent="#38bdf8" />
          <StatCard label="Meilleure semaine" value={`${ts.bestWeek} séances`} accent="#fb923c" />
          <StatCard
            label="Meilleure séance"
            value={ts.bestSession ? ts.bestSession.title : "—"}
            accent="#a78bfa"
          />
        </div>
        {ts.bestSession && (
          <p className="mt-3 text-xs text-content-lo">
            Meilleure séance : {ts.bestSession.title} du{" "}
            {fromISO(ts.bestSession.date).toLocaleDateString("fr-FR", { day: "2-digit", month: "long" })} · volume{" "}
            {ts.bestSession.volume.toLocaleString("fr-FR")}.
          </p>
        )}
      </div>

      {/* Heatmap */}
      <div className="card p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-semibold text-content-hi">Régularité</h2>
          <HeatmapLegend />
        </div>
        <Heatmap weeks={20} />
      </div>

      {/* Gamification */}
      <div className="card p-5">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-content-hi">Progression</h2>
          <span
            className="chip font-semibold"
            style={{ background: "rgb(var(--accent) / 0.14)", color: "rgb(var(--accent))" }}
          >
            <Zap size={13} /> Niveau {level.level}
          </span>
        </div>
        <div className="mt-3">
          <div className="mb-1.5 flex justify-between text-xs text-content-mid">
            <span className="tnum">{state.gamification.xp} XP au total</span>
            <span className="tnum">{level.xpForNext} XP → niveau {level.level + 1}</span>
          </div>
          <ProgressBar value={level.intoLevel} max={level.levelNeed} height={10} />
        </div>

        <h3 className="mb-3 mt-6 text-sm font-semibold text-content-mid">
          Badges · {unlocked.size}/{BADGES.length}
        </h3>
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          {BADGES.map((b) => {
            const got = unlocked.has(b.id);
            return (
              <div
                key={b.id}
                className={`rounded-2xl border p-3 text-center transition-all ${
                  got
                    ? "border-accent/40 bg-accent-soft"
                    : "border-surface-line bg-surface-base opacity-55 grayscale"
                }`}
              >
                <div className="text-2xl">{b.icon}</div>
                <div className="mt-1 text-xs font-semibold text-content-hi">{b.title}</div>
                <div className="mt-0.5 text-[10px] leading-tight text-content-lo">{b.desc}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
