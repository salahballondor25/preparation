import { useEffect, useMemo, useState } from "react";
import { Plus, Trash2, Eraser, Store as StoreIcon } from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { ProgressBar, Modal, EmptyState } from "../components/ui/Primitives";
import { useStore } from "../lib/store";
import type { ShoppingCategory, ShoppingItem } from "../lib/types";
import { SHOPPING_META, euro } from "../lib/utils";

export default function Shopping() {
  const { state, addShop, updateShop, removeShop, toggleShop, uncheckAllShop, clearAllShop } =
    useStore();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<ShoppingItem | null>(null);

  const items = state.shopping;
  const checkedCount = items.filter((i) => i.checked).length;
  const total = items.reduce((a, i) => a + i.price * i.qty, 0);
  const remainingTotal = items.filter((i) => !i.checked).reduce((a, i) => a + i.price * i.qty, 0);

  // Groupé par catégorie ; les articles cochés passent en bas de chaque groupe.
  const groups = useMemo(() => {
    const map = new Map<ShoppingCategory, ShoppingItem[]>();
    for (const it of items) {
      const arr = map.get(it.category) ?? [];
      arr.push(it);
      map.set(it.category, arr);
    }
    for (const arr of map.values())
      arr.sort((a, b) => Number(a.checked) - Number(b.checked) || a.order - b.order);
    return [...map.entries()].sort(
      (a, b) =>
        Object.keys(SHOPPING_META).indexOf(a[0]) - Object.keys(SHOPPING_META).indexOf(b[0]),
    );
  }, [items]);

  return (
    <div>
      <PageHeader
        title="Liste de courses"
        subtitle={`${items.length} article${items.length > 1 ? "s" : ""} · ${euro(total)} estimés`}
        actions={
          <button
            className="btn-primary"
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus size={16} /> Ajouter
          </button>
        }
      />

      {/* Résumé */}
      <div className="card mb-4 p-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-content-mid">
            {checkedCount}/{items.length} récupérés
          </span>
          <span className="font-semibold text-content-hi">
            Reste : <span style={{ color: "rgb(var(--accent))" }}>{euro(remainingTotal)}</span>
          </span>
        </div>
        <ProgressBar
          value={checkedCount}
          max={items.length || 1}
          className="mt-3"
          height={10}
          color="#10b981"
        />
        <div className="mt-3 flex gap-2">
          <button className="btn-outline flex-1" onClick={uncheckAllShop} disabled={checkedCount === 0}>
            <Eraser size={15} /> Tout décocher
          </button>
          <button
            className="btn-outline flex-1 text-content-mid hover:!text-red-400"
            onClick={() => {
              if (confirm("Supprimer tous les articles ?")) clearAllShop();
            }}
            disabled={items.length === 0}
          >
            <Trash2 size={15} /> Tout supprimer
          </button>
        </div>
      </div>

      {items.length === 0 ? (
        <EmptyState title="Liste vide" hint="Ajoute des articles pour préparer tes courses." />
      ) : (
        <div className="space-y-5">
          {groups.map(([cat, list]) => (
            <div key={cat}>
              <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-content-mid">
                <span>{SHOPPING_META[cat].emoji}</span>
                {SHOPPING_META[cat].label}
                <span className="text-xs font-normal text-content-lo">{list.length}</span>
              </h3>
              <div className="space-y-1.5">
                {list.map((it) => (
                  <ShopRow
                    key={it.id}
                    item={it}
                    onToggle={() => toggleShop(it.id)}
                    onEdit={() => {
                      setEditing(it);
                      setOpen(true);
                    }}
                    onRemove={() => removeShop(it.id)}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <ItemEditor
        open={open}
        onClose={() => setOpen(false)}
        initial={editing}
        onSave={(draft) => {
          if (editing) updateShop(editing.id, draft);
          else addShop(draft);
        }}
      />
    </div>
  );
}

function ShopRow({
  item,
  onToggle,
  onEdit,
  onRemove,
}: {
  item: ShoppingItem;
  onToggle: () => void;
  onEdit: () => void;
  onRemove: () => void;
}) {
  return (
    <div
      className={`group flex items-center gap-3 rounded-xl border border-surface-line bg-surface-base px-3 py-2.5 transition-all ${
        item.checked ? "opacity-55" : ""
      }`}
    >
      <button
        onClick={onToggle}
        className="grid h-5 w-5 shrink-0 place-items-center rounded-md border-2 transition-colors"
        style={{
          borderColor: item.checked ? "#10b981" : "rgb(var(--content-lo))",
          background: item.checked ? "#10b981" : "transparent",
        }}
        aria-label={item.checked ? "Décocher" : "Cocher"}
      >
        {item.checked && (
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3.5">
            <path d="M20 6L9 17l-5-5" />
          </svg>
        )}
      </button>

      <div className="min-w-0 flex-1 cursor-pointer" onClick={onEdit}>
        <div
          className={`truncate text-sm font-medium ${
            item.checked ? "text-content-lo line-through" : "text-content-hi"
          }`}
        >
          {item.name}
          {item.qty > 1 && <span className="ml-1.5 text-xs text-content-lo">× {item.qty}</span>}
        </div>
        {(item.store || item.price > 0) && (
          <div className="mt-0.5 flex items-center gap-2 text-[11px] text-content-lo">
            {item.price > 0 && <span>{euro(item.price * item.qty)}</span>}
            {item.store && (
              <span className="inline-flex items-center gap-0.5">
                <StoreIcon size={11} /> {item.store}
              </span>
            )}
          </div>
        )}
      </div>

      <button
        className="btn-ghost !p-1.5 text-content-lo opacity-0 transition-opacity hover:text-red-400 group-hover:opacity-100"
        onClick={onRemove}
        aria-label="Supprimer"
      >
        <Trash2 size={15} />
      </button>
    </div>
  );
}

function ItemEditor({
  open,
  onClose,
  onSave,
  initial,
}: {
  open: boolean;
  onClose: () => void;
  onSave: (d: Omit<ShoppingItem, "id" | "order" | "checked">) => void;
  initial: ShoppingItem | null;
}) {
  const [name, setName] = useState("");
  const [qty, setQty] = useState(1);
  const [price, setPrice] = useState(0);
  const [store, setStore] = useState("");
  const [category, setCategory] = useState<ShoppingCategory>("divers");

  // Réinitialise les champs à l'ouverture
  useEffect(() => {
    if (open) {
      setName(initial?.name ?? "");
      setQty(initial?.qty ?? 1);
      setPrice(initial?.price ?? 0);
      setStore(initial?.store ?? "");
      setCategory(initial?.category ?? "divers");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const save = () => {
    if (!name.trim()) return;
    onSave({ name: name.trim(), qty, price, store: store.trim() || undefined, category });
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={initial ? "Modifier l'article" : "Nouvel article"}
      footer={
        <>
          <button className="btn-ghost" onClick={onClose}>
            Annuler
          </button>
          <button className="btn-primary" onClick={save} disabled={!name.trim()}>
            {initial ? "Enregistrer" : "Ajouter"}
          </button>
        </>
      }
    >
      <div className="space-y-4">
        <div>
          <label className="label mb-1.5 block">Nom</label>
          <input
            autoFocus
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && save()}
            placeholder="Ex : Blanc de poulet"
            className="input"
          />
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="label mb-1.5 block">Quantité</label>
            <input
              type="number"
              min={1}
              value={qty}
              onChange={(e) => setQty(Math.max(1, Number(e.target.value)))}
              className="input"
            />
          </div>
          <div>
            <label className="label mb-1.5 block">Prix unit. (€)</label>
            <input
              type="number"
              min={0}
              step={0.1}
              value={price}
              onChange={(e) => setPrice(Number(e.target.value))}
              className="input"
            />
          </div>
          <div>
            <label className="label mb-1.5 block">Magasin</label>
            <input value={store} onChange={(e) => setStore(e.target.value)} placeholder="—" className="input" />
          </div>
        </div>
        <div>
          <label className="label mb-1.5 block">Catégorie</label>
          <div className="flex flex-wrap gap-1.5">
            {(Object.keys(SHOPPING_META) as ShoppingCategory[]).map((c) => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className="chip border transition-colors"
                style={{
                  borderColor: category === c ? "rgb(var(--accent))" : "rgb(var(--surface-line))",
                  background: category === c ? "rgb(var(--accent) / 0.14)" : "transparent",
                  color: category === c ? "rgb(var(--accent))" : "rgb(var(--content-mid))",
                }}
              >
                {SHOPPING_META[c].emoji} {SHOPPING_META[c].label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </Modal>
  );
}
