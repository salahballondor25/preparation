import { useMemo, useState } from "react";
import { Plus, Filter } from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { TaskRow } from "../components/TaskRow";
import { TaskEditor, type TaskDraft } from "../components/TaskEditor";
import { EmptyState } from "../components/ui/Primitives";
import { useStore } from "../lib/store";
import type { Category, Task } from "../lib/types";
import { CATEGORY_META, formatDayLabel, todayISO } from "../lib/utils";

const TODAY = todayISO();

export default function Tasks() {
  const { state, addTask, updateTask, removeTask, cycleTask, awardXp } = useStore();
  const [cat, setCat] = useState<Category | "all">("all");
  const [showDone, setShowDone] = useState(true);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);

  const grouped = useMemo(() => {
    const list = state.tasks
      .filter((t) => (cat === "all" ? true : t.category === cat))
      .filter((t) => (showDone ? true : t.status !== "done"))
      .sort((a, b) => a.date.localeCompare(b.date) || a.order - b.order);

    const map = new Map<string, Task[]>();
    for (const t of list) {
      const arr = map.get(t.date) ?? [];
      arr.push(t);
      map.set(t.date, arr);
    }
    return [...map.entries()];
  }, [state.tasks, cat, showDone]);

  const save = (draft: TaskDraft) => {
    if (editing) updateTask(editing.id, draft);
    else addTask({ ...draft, status: "todo" });
  };
  const cycleWithXp = (t: Task) => {
    if (t.status === "todo") awardXp(10);
    cycleTask(t.id);
  };

  const dateHeading = (iso: string) =>
    iso === TODAY ? "Aujourd'hui" : formatDayLabel(iso);

  return (
    <div>
      <PageHeader
        title="Tâches"
        subtitle="Toutes tes tâches, tous jours confondus."
        actions={
          <button
            className="btn-primary"
            onClick={() => {
              setEditing(null);
              setEditorOpen(true);
            }}
          >
            <Plus size={16} /> Nouvelle tâche
          </button>
        }
      />

      {/* Filtres */}
      <div className="mb-4 flex flex-wrap items-center gap-1.5">
        <span className="mr-1 inline-flex items-center gap-1 text-content-lo">
          <Filter size={14} />
        </span>
        <FilterChip active={cat === "all"} onClick={() => setCat("all")} label="Toutes" />
        {(Object.keys(CATEGORY_META) as Category[]).map((c) => (
          <FilterChip
            key={c}
            active={cat === c}
            onClick={() => setCat(c)}
            label={`${CATEGORY_META[c].emoji} ${CATEGORY_META[c].label}`}
            color={CATEGORY_META[c].color}
          />
        ))}
        <label className="ml-auto flex items-center gap-2 text-xs text-content-mid">
          <input
            type="checkbox"
            checked={showDone}
            onChange={(e) => setShowDone(e.target.checked)}
            className="h-4 w-4 accent-[rgb(var(--accent))]"
          />
          Afficher les réussies
        </label>
      </div>

      {grouped.length === 0 ? (
        <EmptyState title="Aucune tâche" hint="Ajoute ta première tâche pour organiser ta journée." />
      ) : (
        <div className="space-y-6">
          {grouped.map(([date, tasks]) => (
            <div key={date}>
              <h3 className="mb-2 text-sm font-semibold capitalize text-content-mid">
                {dateHeading(date)}
                <span className="ml-2 text-xs font-normal text-content-lo">{tasks.length}</span>
              </h3>
              <div className="space-y-2">
                {tasks.map((t) => (
                  <TaskRow
                    key={t.id}
                    task={t}
                    onCycle={() => cycleWithXp(t)}
                    onEdit={() => {
                      setEditing(t);
                      setEditorOpen(true);
                    }}
                    onRemove={() => removeTask(t.id)}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <TaskEditor
        open={editorOpen}
        onClose={() => setEditorOpen(false)}
        onSave={save}
        initial={editing}
        showDate
        defaultDate={editing?.date ?? TODAY}
      />
    </div>
  );
}

function FilterChip({
  active,
  onClick,
  label,
  color,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  color?: string;
}) {
  return (
    <button
      onClick={onClick}
      className="chip border transition-colors"
      style={{
        borderColor: active ? color ?? "rgb(var(--accent))" : "rgb(var(--surface-line))",
        background: active ? (color ?? "rgb(var(--accent))") + "22" : "transparent",
        color: active ? color ?? "rgb(var(--accent))" : "rgb(var(--content-mid))",
      }}
    >
      {label}
    </button>
  );
}
