import { useRef, useState } from "react";
import { Download, Upload, RotateCcw, Check, Bell, LogOut, User } from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { Segmented } from "../components/ui/Primitives";
import { InstallButton } from "../components/InstallButton";
import { useStore } from "../lib/store";
import { useAuth } from "../lib/authStore";
import type { AppState } from "../lib/types";

const ACCENTS: { name: string; rgb: string }[] = [
  { name: "Bleu électrique", rgb: "56 132 255" },
  { name: "Cyan", rgb: "34 211 238" },
  { name: "Violet", rgb: "139 92 246" },
  { name: "Émeraude", rgb: "16 185 129" },
  { name: "Ambre", rgb: "245 158 11" },
  { name: "Rose", rgb: "244 114 182" },
  { name: "Rouge", rgb: "239 68 68" },
];

function hexToRgbString(hex: string): string {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `${r} ${g} ${b}`;
}
function rgbStringToHex(rgb: string): string {
  const [r, g, b] = rgb.split(" ").map(Number);
  return "#" + [r, g, b].map((n) => n.toString(16).padStart(2, "0")).join("");
}

export default function SettingsPage() {
  const { state, patchSettings, importState, reset } = useStore();
  const { user, signOut } = useAuth();
  const s = state.settings;
  const fileRef = useRef<HTMLInputElement>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const flash = (m: string) => {
    setMsg(m);
    setTimeout(() => setMsg(null), 2500);
  };

  const exportData = () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `prepa-sog-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    flash("Données exportées");
  };

  const importData = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as AppState;
        if (!parsed || typeof parsed !== "object" || !("tasks" in parsed)) {
          throw new Error("format");
        }
        importState(parsed);
        flash("Données importées");
      } catch {
        flash("Fichier invalide");
      }
    };
    reader.readAsText(file);
  };

  const askNotifications = async (on: boolean) => {
    if (on && "Notification" in window) {
      const perm = await Notification.requestPermission();
      if (perm === "granted") {
        patchSettings({ notifications: true });
        new Notification("Rappels activés", { body: "Tu recevras des rappels pour tes tâches." });
      } else {
        flash("Autorisation refusée");
      }
    } else {
      patchSettings({ notifications: false });
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Paramètres" subtitle="Profil, apparence et gestion des données." />

      {msg && (
        <div className="glass flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm text-content-hi animate-fade-in">
          <Check size={16} className="text-emerald-400" /> {msg}
        </div>
      )}

      {/* Compte */}
      <section className="card p-5">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-full" style={{ background: "rgb(var(--accent) / 0.14)", color: "rgb(var(--accent))" }}>
              <User size={20} />
            </span>
            <div>
              <div className="font-semibold text-content-hi">{user?.username}</div>
              <div className="text-xs text-content-lo">Compte connecté sur cet appareil</div>
            </div>
          </div>
          <button
            className="btn-outline text-content-mid hover:!border-red-500/40 hover:!text-red-400"
            onClick={() => {
              if (confirm("Se déconnecter ? Tes données restent enregistrées sur cet appareil.")) signOut();
            }}
          >
            <LogOut size={16} /> Déconnexion
          </button>
        </div>
      </section>

      {/* Profil */}
      <section className="card space-y-4 p-5">
        <h2 className="font-semibold text-content-hi">Profil & objectif</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label mb-1.5 block">Nom / prénom</label>
            <input value={s.name} onChange={(e) => patchSettings({ name: e.target.value })} className="input" />
          </div>
          <div>
            <label className="label mb-1.5 block">Intitulé de l'objectif</label>
            <input
              value={s.objectiveTitle}
              onChange={(e) => patchSettings({ objectiveTitle: e.target.value })}
              className="input"
            />
          </div>
          <div>
            <label className="label mb-1.5 block">Date du concours</label>
            <input
              type="date"
              value={s.examDate}
              onChange={(e) => patchSettings({ examDate: e.target.value })}
              className="input"
            />
          </div>
          <div>
            <label className="label mb-1.5 block">Taille (cm) — pour l'IMC</label>
            <input
              type="number"
              value={s.heightCm}
              onChange={(e) => patchSettings({ heightCm: Number(e.target.value) })}
              className="input"
            />
          </div>
          <div>
            <label className="label mb-1.5 block">Poids de départ (kg)</label>
            <input type="number" step="0.1" value={s.startWeight} onChange={(e) => patchSettings({ startWeight: Number(e.target.value) })} className="input" />
          </div>
          <div>
            <label className="label mb-1.5 block">Poids objectif (kg)</label>
            <input type="number" step="0.1" value={s.targetWeight} onChange={(e) => patchSettings({ targetWeight: Number(e.target.value) })} className="input" />
          </div>
        </div>
      </section>

      {/* Objectifs quotidiens */}
      <section className="card space-y-4 p-5">
        <h2 className="font-semibold text-content-hi">Objectifs quotidiens</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <label className="label mb-1.5 block">Eau (L / jour)</label>
            <input type="number" step="0.5" value={s.waterTargetL} onChange={(e) => patchSettings({ waterTargetL: Number(e.target.value) })} className="input" />
          </div>
          <div>
            <label className="label mb-1.5 block">Pas / jour</label>
            <input type="number" step="500" value={s.stepsTarget} onChange={(e) => patchSettings({ stepsTarget: Number(e.target.value) })} className="input" />
          </div>
          <div>
            <label className="label mb-1.5 block">Sommeil (h)</label>
            <input type="number" step="0.5" value={s.sleepTargetH} onChange={(e) => patchSettings({ sleepTargetH: Number(e.target.value) })} className="input" />
          </div>
          <div>
            <label className="label mb-1.5 block">Entraînement / semaine (h)</label>
            <input type="number" value={s.weeklyTrainingHours} onChange={(e) => patchSettings({ weeklyTrainingHours: Number(e.target.value) })} className="input" />
          </div>
        </div>
      </section>

      {/* Bilan du soir */}
      <section className="card space-y-4 p-5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="flex items-center gap-2 font-semibold text-content-hi">🌙 Bilan du soir</h2>
            <p className="mt-1 text-sm text-content-mid">Ouverture automatique de l'assistant le soir.</p>
          </div>
          <button
            role="switch"
            aria-checked={s.autoWizard}
            onClick={() => patchSettings({ autoWizard: !s.autoWizard })}
            className="relative h-7 w-12 shrink-0 rounded-full transition-colors"
            style={{ background: s.autoWizard ? "rgb(var(--accent))" : "rgb(var(--surface-line))" }}
          >
            <span className="absolute top-1 h-5 w-5 rounded-full bg-white transition-transform" style={{ transform: s.autoWizard ? "translateX(22px)" : "translateX(4px)" }} />
          </button>
        </div>
        <div className="max-w-[12rem]">
          <label className="label mb-1.5 block">À partir de quelle heure</label>
          <input type="number" min={12} max={23} value={s.eveningHour} onChange={(e) => patchSettings({ eveningHour: Number(e.target.value) })} className="input" />
        </div>
      </section>

      {/* Apparence */}
      <section className="card space-y-4 p-5">
        <h2 className="font-semibold text-content-hi">Apparence</h2>
        <div>
          <label className="label mb-2 block">Thème</label>
          <Segmented
            value={s.theme}
            onChange={(v) => patchSettings({ theme: v })}
            options={[
              { value: "dark", label: "🌙 Sombre" },
              { value: "light", label: "☀️ Clair" },
            ]}
          />
        </div>
        <div>
          <label className="label mb-2 block">Couleur d'accent</label>
          <div className="flex flex-wrap items-center gap-2">
            {ACCENTS.map((a) => (
              <button
                key={a.rgb}
                onClick={() => patchSettings({ accent: a.rgb })}
                title={a.name}
                className="grid h-9 w-9 place-items-center rounded-full ring-2 ring-offset-2 ring-offset-surface-card transition-transform hover:scale-110"
                style={{
                  background: `rgb(${a.rgb})`,
                  // @ts-expect-error CSS var
                  "--tw-ring-color": s.accent === a.rgb ? `rgb(${a.rgb})` : "transparent",
                }}
              >
                {s.accent === a.rgb && <Check size={16} className="text-white" />}
              </button>
            ))}
            <label className="ml-1 flex h-9 cursor-pointer items-center gap-2 rounded-full border border-surface-line px-3 text-xs text-content-mid">
              Personnalisée
              <input
                type="color"
                value={rgbStringToHex(s.accent)}
                onChange={(e) => patchSettings({ accent: hexToRgbString(e.target.value) })}
                className="h-5 w-5 cursor-pointer border-0 bg-transparent p-0"
              />
            </label>
          </div>
        </div>
      </section>

      {/* Installer l'app */}
      <section className="card space-y-3 p-5">
        <div>
          <h2 className="flex items-center gap-2 font-semibold text-content-hi">
            <Download size={16} /> Installer sur ton téléphone
          </h2>
          <p className="mt-1 text-sm text-content-mid">
            Installe l'app pour l'ouvrir comme une vraie application, en plein écran et hors-ligne.
          </p>
        </div>
        <InstallButton />
      </section>

      {/* Notifications */}
      <section className="card p-5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="flex items-center gap-2 font-semibold text-content-hi">
              <Bell size={16} /> Rappels du navigateur
            </h2>
            <p className="mt-1 text-sm text-content-mid">
              Autorise les notifications pour être rappelé (boire de l'eau, courir, séance…).
            </p>
          </div>
          <button
            role="switch"
            aria-checked={s.notifications}
            onClick={() => askNotifications(!s.notifications)}
            className="relative h-7 w-12 shrink-0 rounded-full transition-colors"
            style={{ background: s.notifications ? "rgb(var(--accent))" : "rgb(var(--surface-line))" }}
          >
            <span
              className="absolute top-1 h-5 w-5 rounded-full bg-white transition-transform"
              style={{ transform: s.notifications ? "translateX(22px)" : "translateX(4px)" }}
            />
          </button>
        </div>
      </section>

      {/* Données */}
      <section className="card space-y-3 p-5">
        <h2 className="font-semibold text-content-hi">Données</h2>
        <p className="text-sm text-content-mid">
          Tout est sauvegardé automatiquement sur cet appareil. Exporte régulièrement une sauvegarde.
        </p>
        <div className="flex flex-wrap gap-2">
          <button className="btn-outline" onClick={exportData}>
            <Download size={16} /> Exporter (JSON)
          </button>
          <button className="btn-outline" onClick={() => fileRef.current?.click()}>
            <Upload size={16} /> Importer
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) importData(f);
              e.target.value = "";
            }}
          />
          <button
            className="btn-outline ml-auto text-content-mid hover:!border-red-500/40 hover:!text-red-400"
            onClick={() => {
              if (confirm("Réinitialiser toutes les données ? Cette action est irréversible.")) {
                reset();
                flash("Données réinitialisées");
              }
            }}
          >
            <RotateCcw size={16} /> Réinitialiser
          </button>
        </div>
      </section>

      <p className="pb-4 text-center text-xs text-content-lo">
        Préparation SOG · données stockées localement · v{state.version}
      </p>
    </div>
  );
}
