import { useMemo, useState } from "react";
import { Plus, Search, Trash2, Eye, Pencil, FileText } from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { useStore } from "../lib/store";
import { renderMarkdown } from "../lib/markdown";

export default function Notes() {
  const { state, addNote, updateNote, removeNote } = useStore();
  const [q, setQ] = useState("");
  const [activeId, setActiveId] = useState<string | null>(state.notes[0]?.id ?? null);
  const [preview, setPreview] = useState(false);

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    const list = [...state.notes].sort((a, b) => b.updatedAt - a.updatedAt);
    if (!query) return list;
    return list.filter(
      (n) => n.title.toLowerCase().includes(query) || n.body.toLowerCase().includes(query),
    );
  }, [state.notes, q]);

  const active = state.notes.find((n) => n.id === activeId) ?? null;

  const create = () => {
    const id = addNote();
    setActiveId(id);
    setPreview(false);
  };

  return (
    <div>
      <PageHeader
        title="Notes"
        subtitle="Prise de notes en Markdown, avec recherche."
        actions={
          <button className="btn-primary" onClick={create}>
            <Plus size={16} /> Note
          </button>
        }
      />

      <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
        {/* Liste */}
        <div className="space-y-2">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-content-lo" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Rechercher…"
              className="input !pl-9"
            />
          </div>
          <div className="space-y-1.5">
            {filtered.length === 0 && (
              <div className="rounded-xl border border-dashed border-surface-line py-6 text-center text-sm text-content-lo">
                Aucune note
              </div>
            )}
            {filtered.map((n) => (
              <button
                key={n.id}
                onClick={() => {
                  setActiveId(n.id);
                  setPreview(false);
                }}
                className={`w-full rounded-xl border px-3 py-2.5 text-left transition-colors ${
                  activeId === n.id
                    ? "border-accent bg-accent-soft"
                    : "border-surface-line bg-surface-base hover:border-surface-line/60"
                }`}
              >
                <div className="truncate text-sm font-medium text-content-hi">
                  {n.title || "Sans titre"}
                </div>
                <div className="truncate text-xs text-content-lo">
                  {n.body.replace(/[#*>`-]/g, "").slice(0, 60) || "Vide"}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Éditeur */}
        {active ? (
          <div className="card flex min-h-[420px] flex-col p-4">
            <div className="mb-3 flex items-center gap-2">
              <input
                value={active.title}
                onChange={(e) => updateNote(active.id, { title: e.target.value })}
                placeholder="Titre de la note"
                className="input flex-1 !border-transparent !bg-transparent !px-0 text-lg font-semibold focus:!ring-0"
              />
              <button
                className="btn-ghost !p-2"
                onClick={() => setPreview((p) => !p)}
                aria-label={preview ? "Éditer" : "Aperçu"}
                title={preview ? "Éditer" : "Aperçu"}
              >
                {preview ? <Pencil size={16} /> : <Eye size={16} />}
              </button>
              <button
                className="btn-ghost !p-2 text-content-lo hover:text-red-400"
                onClick={() => {
                  if (confirm("Supprimer cette note ?")) {
                    removeNote(active.id);
                    setActiveId(null);
                  }
                }}
                aria-label="Supprimer"
              >
                <Trash2 size={16} />
              </button>
            </div>

            {preview ? (
              <div
                className="prose-note flex-1 overflow-y-auto text-sm text-content-hi"
                dangerouslySetInnerHTML={{ __html: renderMarkdown(active.body) }}
              />
            ) : (
              <textarea
                value={active.body}
                onChange={(e) => updateNote(active.id, { body: e.target.value })}
                placeholder={"# Titre\n\nÉcris ici en **Markdown**…\n\n- point 1\n- point 2\n\n> Une citation"}
                className="flex-1 resize-none rounded-xl border border-surface-line bg-surface-base p-3 font-mono text-sm text-content-hi placeholder:text-content-lo focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/25"
              />
            )}
          </div>
        ) : (
          <div className="card grid min-h-[420px] place-items-center p-4 text-center">
            <div className="space-y-2 text-content-lo">
              <FileText size={32} className="mx-auto" />
              <p className="text-sm">Sélectionne une note ou crée-en une nouvelle.</p>
              <button className="btn-outline" onClick={create}>
                <Plus size={16} /> Nouvelle note
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
