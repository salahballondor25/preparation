export function PageFallback() {
  return (
    <div className="flex items-center justify-center py-24">
      <div
        className="h-8 w-8 animate-spin rounded-full border-2 border-surface-line"
        style={{ borderTopColor: "rgb(var(--accent))" }}
      />
    </div>
  );
}
