import { useEffect, useMemo, useRef, useState } from "react";
import {
  X,
  ChevronLeft,
  Check,
  Plus,
  Minus,
  Trash2,
  Dumbbell,
  Footprints,
  Moon,
  Sparkles,
} from "lucide-react";
import { useStore } from "../lib/store";
import type {
  DailyLog,
  NutritionRating,
  SessionType,
  StrengthExercise,
  StrengthSet,
} from "../lib/types";
import {
  SESSION_TYPE_META,
  MUSCLE_META,
  estimateRunCalories,
  paceLabel,
  todayISO,
} from "../lib/utils";
import { analyzeDay } from "../lib/analysis";

const INSIGHT_STYLE: Record<string, string> = {
  success: "border-emerald-500/30 bg-emerald-500/10",
  pr: "border-amber-400/30 bg-amber-400/10",
  warning: "border-red-500/30 bg-red-500/10",
  tip: "border-sky-500/30 bg-sky-500/10",
  info: "border-surface-line bg-surface-base",
};

export function EveningWizard({ open, onClose }: { open: boolean; onClose: () => void }) {
  const store = useStore();
  const { state } = store;
  const date = todayISO();
  const existing = state.dailyLogs.find((l) => l.date === date);

  // --- Brouillon ---
  const [trained, setTrained] = useState<boolean | null>(null);
  const [sessionType, setSessionType] = useState<SessionType>("push");
  const [exercises, setExercises] = useState<StrengthExercise[]>([]);
  const [ran, setRan] = useState<boolean | null>(null);
  const [distance, setDistance] = useState("");
  const [duration, setDuration] = useState("");
  const [nutrition, setNutrition] = useState<NutritionRating | null>(null);
  const [waterL, setWaterL] = useState(1.5);
  const [steps, setSteps] = useState(6000);
  const [weight, setWeight] = useState("");
  const [sleepQuality, setSleepQuality] = useState<number | null>(null);
  const [bedtime, setBedtime] = useState("");
  const [waketime, setWaketime] = useState("");
  const [energy, setEnergy] = useState<number | null>(null);
  const [motivation, setMotivation] = useState<number | null>(null);
  const [note, setNote] = useState("");
  const [step, setStep] = useState(0);
  const committed = useRef(false);

  // Réinitialise à l'ouverture (reprend d'éventuelles valeurs déjà saisies).
  useEffect(() => {
    if (!open) return;
    committed.current = false;
    setStep(0);
    const lastW = [...state.weights].sort((a, b) => a.date.localeCompare(b.date)).at(-1);
    setTrained(null);
    setSessionType("push");
    setExercises([]);
    setRan(null);
    setDistance("");
    setDuration("");
    setNutrition(existing?.nutrition ?? null);
    setWaterL(existing?.waterL ?? 1.5);
    setSteps(existing?.steps ?? 6000);
    setWeight(existing?.weight ? String(existing.weight) : "");
    setSleepQuality(existing?.sleepQuality ?? null);
    setBedtime(existing?.bedtime ?? "");
    setWaketime(existing?.waketime ?? "");
    setEnergy(existing?.energy ?? null);
    setMotivation(existing?.motivation ?? null);
    setNote(existing?.note ?? "");
    void lastW;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  // Écrans dynamiques selon les réponses.
  const screens = useMemo(() => {
    const s = ["intro", "trained"];
    if (trained) s.push("sessionType", "exercises");
    s.push("ran");
    if (ran) s.push("runDetail");
    s.push("nutrition", "water", "steps", "weight", "sleep", "energy", "motivation", "summary");
    return s;
  }, [trained, ran]);

  const current = screens[Math.min(step, screens.length - 1)];
  const progress = Math.round((step / (screens.length - 1)) * 100);

  const next = () => setStep((i) => Math.min(i + 1, screens.length - 1));
  const back = () => setStep((i) => Math.max(i - 1, 0));

  // Enregistrement à l'arrivée sur le résumé (une seule fois).
  useEffect(() => {
    if (current !== "summary" || committed.current) return;
    committed.current = true;

    const dist = parseFloat(distance.replace(",", ".")) || 0;
    const dur = parseFloat(duration.replace(",", ".")) || 0;
    const w = parseFloat(weight.replace(",", ".")) || 0;

    if (trained && exercises.some((e) => e.name.trim())) {
      store.addStrength({
        date,
        title: SESSION_TYPE_META[sessionType].label,
        type: sessionType,
        exercises: exercises.filter((e) => e.name.trim()),
        comment: note.trim() || undefined,
      });
    }
    if (ran && dist > 0 && dur > 0) {
      store.addCardio({
        date,
        distanceKm: dist,
        durationMin: dur,
        calories: estimateRunCalories(dist, w || state.settings.targetWeight),
      });
    }
    if (w > 0) store.addWeight(date, w);

    const log: DailyLog = {
      date,
      trained: !!trained,
      ran: !!ran,
      nutrition: nutrition ?? undefined,
      waterL,
      steps,
      weight: w || undefined,
      sleepQuality: sleepQuality ?? undefined,
      bedtime: bedtime || undefined,
      waketime: waketime || undefined,
      energy: energy ?? undefined,
      motivation: motivation ?? undefined,
      note: note.trim() || undefined,
      completedAt: Date.now(),
    };
    store.upsertDailyLog(log);

    // Coche automatiquement les objectifs du jour correspondants.
    const todayTasks = state.tasks.filter((t) => t.date === date && t.templateKey);
    const check = (key: string, done: boolean) => {
      const t = todayTasks.find((x) => x.templateKey === key);
      if (t) store.updateTask(t.id, { status: done ? "done" : "failed" });
    };
    check("muscu", !!trained);
    check("cardio", !!ran);
    check("eau", waterL >= state.settings.waterTargetL);
    check("pas", steps >= state.settings.stepsTarget);
    check("alim", nutrition === "oui" || nutrition === "moyen");
    if (sleepQuality != null) check("sommeil", sleepQuality >= 3);

    // Met à jour les objectifs mesurables.
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const weekISO = todayISO();
    const sessionsThisWeek =
      state.strength.filter((s) => s.date >= addDaysStr(weekISO, -7)).length + (trained ? 1 : 0);
    const gSess = state.goals.find((g) => g.unit === "séances");
    if (gSess) store.updateGoal(gSess.id, { current: sessionsThisWeek });
    const gWeight = state.goals.find((g) => g.unit === "kg");
    if (gWeight && w > 0) store.updateGoal(gWeight.id, { current: w });

    // Streak + XP.
    store.validateDay(date);
    let xp = 25;
    if (trained) xp += 15;
    if (ran) xp += 15;
    if (nutrition === "oui") xp += 10;
    if (waterL >= state.settings.waterTargetL) xp += 5;
    if (steps >= state.settings.stepsTarget) xp += 5;
    store.awardXp(xp);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[60] flex flex-col bg-surface-base/95 backdrop-blur-xl animate-fade-in">
      {/* Barre supérieure */}
      <div className="flex items-center gap-3 px-4 pt-4 sm:px-6">
        {step > 0 && current !== "summary" ? (
          <button className="btn-ghost !p-2" onClick={back} aria-label="Retour">
            <ChevronLeft size={20} />
          </button>
        ) : (
          <div className="w-9" />
        )}
        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-surface-line">
          <div
            className="h-full rounded-full transition-all duration-300"
            style={{ width: `${progress}%`, background: "rgb(var(--accent))" }}
          />
        </div>
        <button className="btn-ghost !p-2" onClick={onClose} aria-label="Fermer">
          <X size={20} />
        </button>
      </div>

      {/* Contenu */}
      <div className="flex flex-1 items-center justify-center overflow-y-auto px-5 py-6">
        <div key={current} className="w-full max-w-md animate-slide-up">
          {current === "intro" && (
            <Screen
              emoji="🌙"
              title="Bilan du soir"
              subtitle="2 minutes pour enregistrer ta journée. L'app calcule et analyse le reste."
            >
              <button className="btn-primary w-full justify-center !py-3 text-base" onClick={next}>
                Commencer
              </button>
            </Screen>
          )}

          {current === "trained" && (
            <Screen emoji="🏋️" title="As-tu fait ta séance de muscu aujourd'hui ?">
              <YesNo
                onYes={() => {
                  setTrained(true);
                  next();
                }}
                onNo={() => {
                  setTrained(false);
                  next();
                }}
                value={trained}
              />
            </Screen>
          )}

          {current === "sessionType" && (
            <Screen emoji="💪" title="Quel type de séance ?">
              <div className="grid grid-cols-2 gap-2.5">
                {(Object.keys(SESSION_TYPE_META) as SessionType[]).map((t) => (
                  <Choice
                    key={t}
                    active={sessionType === t}
                    onClick={() => {
                      setSessionType(t);
                      next();
                    }}
                  >
                    <span className="text-xl">{SESSION_TYPE_META[t].emoji}</span>
                    {SESSION_TYPE_META[t].label}
                  </Choice>
                ))}
              </div>
            </Screen>
          )}

          {current === "exercises" && (
            <ExercisesScreen exercises={exercises} setExercises={setExercises} onNext={next} />
          )}

          {current === "ran" && (
            <Screen emoji="🏃" title="As-tu couru aujourd'hui ?">
              <YesNo
                value={ran}
                onYes={() => {
                  setRan(true);
                  next();
                }}
                onNo={() => {
                  setRan(false);
                  next();
                }}
              />
            </Screen>
          )}

          {current === "runDetail" && (
            <Screen emoji="⚡" title="Ta course">
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Distance (km)">
                    <input
                      type="number"
                      step="0.1"
                      inputMode="decimal"
                      value={distance}
                      onChange={(e) => setDistance(e.target.value)}
                      placeholder="5"
                      className="input text-center text-lg"
                      autoFocus
                    />
                  </Field>
                  <Field label="Temps (min)">
                    <input
                      type="number"
                      step="0.1"
                      inputMode="decimal"
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      placeholder="28"
                      className="input text-center text-lg"
                    />
                  </Field>
                </div>
                {distance && duration && (
                  <div className="flex justify-around rounded-xl bg-surface-base py-3 text-sm">
                    <span className="text-content-mid">
                      Allure{" "}
                      <b className="text-content-hi">
                        {paceLabel(parseFloat(distance), parseFloat(duration))}
                      </b>
                    </span>
                    <span className="text-content-mid">
                      ≈{" "}
                      <b className="text-content-hi">
                        {estimateRunCalories(parseFloat(distance) || 0, state.settings.targetWeight)}
                      </b>{" "}
                      kcal
                    </span>
                  </div>
                )}
                <button className="btn-primary w-full justify-center !py-3" onClick={next}>
                  Continuer
                </button>
              </div>
            </Screen>
          )}

          {current === "nutrition" && (
            <Screen emoji="🥗" title="As-tu respecté ton alimentation ?">
              <div className="space-y-2.5">
                {(
                  [
                    ["oui", "Oui, nickel", "😎"],
                    ["moyen", "À peu près", "😐"],
                    ["non", "Non, pas terrible", "😅"],
                  ] as [NutritionRating, string, string][]
                ).map(([v, label, emoji]) => (
                  <Choice
                    key={v}
                    full
                    active={nutrition === v}
                    onClick={() => {
                      setNutrition(v);
                      next();
                    }}
                  >
                    <span className="text-xl">{emoji}</span>
                    {label}
                  </Choice>
                ))}
              </div>
            </Screen>
          )}

          {current === "water" && (
            <Screen emoji="💧" title="Combien d'eau aujourd'hui ?">
              <BigStepper
                value={waterL}
                unit="L"
                step={0.25}
                min={0}
                max={6}
                target={state.settings.waterTargetL}
                onChange={setWaterL}
              />
              <button className="btn-primary mt-5 w-full justify-center !py-3" onClick={next}>
                Continuer
              </button>
            </Screen>
          )}

          {current === "steps" && (
            <Screen emoji="👟" title="Combien de pas ?">
              <BigStepper
                value={steps}
                unit="pas"
                step={500}
                min={0}
                max={30000}
                target={state.settings.stepsTarget}
                onChange={setSteps}
                format={(n) => n.toLocaleString("fr-FR")}
              />
              <div className="mt-3 flex justify-center gap-2">
                {[5000, 8000, 10000, 12000].map((v) => (
                  <button key={v} className="chip bg-surface-base" onClick={() => setSteps(v)}>
                    {v.toLocaleString("fr-FR")}
                  </button>
                ))}
              </div>
              <button className="btn-primary mt-5 w-full justify-center !py-3" onClick={next}>
                Continuer
              </button>
            </Screen>
          )}

          {current === "weight" && (
            <Screen emoji="⚖️" title="Ton poids du jour ?" subtitle="Facultatif — laisse vide pour passer.">
              <input
                type="number"
                step="0.1"
                inputMode="decimal"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                placeholder={`${state.settings.targetWeight} kg`}
                className="input text-center text-2xl font-bold"
                autoFocus
              />
              <button className="btn-primary mt-5 w-full justify-center !py-3" onClick={next}>
                Continuer
              </button>
            </Screen>
          )}

          {current === "sleep" && (
            <Screen emoji="😴" title="Comment as-tu dormi ?">
              <div className="mb-4 flex justify-center gap-2">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    onClick={() => setSleepQuality(n)}
                    className="grid h-12 w-12 place-items-center rounded-2xl border text-xl transition-all"
                    style={{
                      borderColor:
                        sleepQuality === n ? "rgb(var(--accent))" : "rgb(var(--surface-line))",
                      background: sleepQuality === n ? "rgb(var(--accent) / 0.14)" : "transparent",
                      transform: sleepQuality === n ? "scale(1.08)" : "none",
                    }}
                  >
                    {["😫", "😕", "😐", "🙂", "😴"][n - 1]}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Couché à">
                  <input type="time" value={bedtime} onChange={(e) => setBedtime(e.target.value)} className="input" />
                </Field>
                <Field label="Réveil à">
                  <input type="time" value={waketime} onChange={(e) => setWaketime(e.target.value)} className="input" />
                </Field>
              </div>
              <button className="btn-primary mt-5 w-full justify-center !py-3" onClick={next}>
                Continuer
              </button>
            </Screen>
          )}

          {current === "energy" && (
            <Screen emoji="🔋" title="Ton énergie aujourd'hui ?">
              <Scale value={energy} onChange={(v) => { setEnergy(v); setTimeout(next, 200); }} />
            </Screen>
          )}

          {current === "motivation" && (
            <Screen emoji="🚀" title="Ta motivation ?">
              <Scale value={motivation} onChange={(v) => { setMotivation(v); setTimeout(next, 200); }} />
            </Screen>
          )}

          {current === "summary" && <Summary date={date} onClose={onClose} />}
        </div>
      </div>
    </div>
  );
}

// ---------- Écran générique ----------
function Screen({
  emoji,
  title,
  subtitle,
  children,
}: {
  emoji: string;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="text-center">
      <div className="mb-3 text-4xl">{emoji}</div>
      <h2 className="text-xl font-bold text-content-hi">{title}</h2>
      {subtitle && <p className="mx-auto mt-2 max-w-xs text-sm text-content-mid">{subtitle}</p>}
      <div className="mt-6 text-left">{children}</div>
    </div>
  );
}

function YesNo({
  value,
  onYes,
  onNo,
}: {
  value: boolean | null;
  onYes: () => void;
  onNo: () => void;
}) {
  return (
    <div className="grid grid-cols-2 gap-3">
      <button
        onClick={onYes}
        className="rounded-2xl border-2 py-6 text-lg font-semibold transition-all"
        style={{
          borderColor: value === true ? "rgb(var(--accent))" : "rgb(var(--surface-line))",
          background: value === true ? "rgb(var(--accent) / 0.14)" : "transparent",
          color: value === true ? "rgb(var(--accent))" : "rgb(var(--content-hi))",
        }}
      >
        ✅ Oui
      </button>
      <button
        onClick={onNo}
        className="rounded-2xl border-2 border-surface-line py-6 text-lg font-semibold text-content-hi transition-all hover:border-content-lo"
      >
        ❌ Non
      </button>
    </div>
  );
}

function Choice({
  active,
  full,
  onClick,
  children,
}: {
  active: boolean;
  full?: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2.5 rounded-2xl border-2 px-4 py-3.5 font-medium transition-all ${
        full ? "w-full" : "justify-center"
      }`}
      style={{
        borderColor: active ? "rgb(var(--accent))" : "rgb(var(--surface-line))",
        background: active ? "rgb(var(--accent) / 0.14)" : "transparent",
        color: active ? "rgb(var(--accent))" : "rgb(var(--content-hi))",
      }}
    >
      {children}
    </button>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="label mb-1.5 block">{label}</span>
      {children}
    </label>
  );
}

function BigStepper({
  value,
  unit,
  step,
  min,
  max,
  target,
  onChange,
  format,
}: {
  value: number;
  unit: string;
  step: number;
  min: number;
  max: number;
  target?: number;
  onChange: (n: number) => void;
  format?: (n: number) => string;
}) {
  const reached = target != null && value >= target;
  return (
    <div className="text-center">
      <div className="flex items-center justify-center gap-4">
        <button
          className="grid h-12 w-12 place-items-center rounded-full border border-surface-line text-content-hi active:scale-95"
          onClick={() => onChange(Math.max(min, Math.round((value - step) * 100) / 100))}
        >
          <Minus size={20} />
        </button>
        <div className="min-w-[7rem]">
          <div className="text-3xl font-bold tnum text-content-hi">{format ? format(value) : value}</div>
          <div className="text-xs text-content-lo">{unit}</div>
        </div>
        <button
          className="grid h-12 w-12 place-items-center rounded-full border border-surface-line text-content-hi active:scale-95"
          onClick={() => onChange(Math.min(max, Math.round((value + step) * 100) / 100))}
        >
          <Plus size={20} />
        </button>
      </div>
      {target != null && (
        <div className="mt-3 text-xs" style={{ color: reached ? "#10b981" : "rgb(var(--content-lo))" }}>
          {reached ? "✅ Objectif atteint" : `Objectif : ${format ? format(target) : target} ${unit}`}
        </div>
      )}
    </div>
  );
}

function Scale({ value, onChange }: { value: number | null; onChange: (n: number) => void }) {
  return (
    <div className="grid grid-cols-5 gap-2">
      {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => (
        <button
          key={n}
          onClick={() => onChange(n)}
          className="grid aspect-square place-items-center rounded-xl border-2 text-sm font-semibold transition-all"
          style={{
            borderColor: value === n ? "rgb(var(--accent))" : "rgb(var(--surface-line))",
            background: value === n ? "rgb(var(--accent))" : "transparent",
            color: value === n ? "#fff" : "rgb(var(--content-mid))",
          }}
        >
          {n}
        </button>
      ))}
    </div>
  );
}

// ---------- Écran exercices ----------
function ExercisesScreen({
  exercises,
  setExercises,
  onNext,
}: {
  exercises: StrengthExercise[];
  setExercises: React.Dispatch<React.SetStateAction<StrengthExercise[]>>;
  onNext: () => void;
}) {
  const { state } = useStore();
  const [picking, setPicking] = useState(exercises.length === 0);
  const [custom, setCustom] = useState("");

  // Dernières séries connues d'un exercice (pré-remplissage intelligent).
  const lastSetsFor = (name: string): StrengthSet[] => {
    const sessions = [...state.strength].sort((a, b) => b.date.localeCompare(a.date));
    for (const s of sessions) {
      const ex = s.exercises.find((e) => e.name.toLowerCase() === name.toLowerCase());
      if (ex) return ex.sets.map((x) => ({ ...x }));
    }
    return [{ reps: 10, weight: 20 }];
  };

  const addExercise = (name: string) => {
    if (!name.trim()) return;
    setExercises((ex) => [...ex, { name: name.trim(), sets: lastSetsFor(name) }]);
    setPicking(false);
    setCustom("");
  };

  const grouped = useMemo(() => {
    const map = new Map<string, typeof state.exerciseDb>();
    for (const e of state.exerciseDb) {
      const arr = map.get(e.muscle) ?? [];
      arr.push(e);
      map.set(e.muscle, arr);
    }
    return [...map.entries()];
  }, [state.exerciseDb]);

  if (picking) {
    return (
      <Screen emoji="🎯" title="Quel exercice ?">
        <div className="space-y-4">
          <div className="flex gap-2">
            <input
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addExercise(custom)}
              placeholder="Écris un exercice…"
              className="input flex-1"
              autoFocus
            />
            <button className="btn-primary" onClick={() => addExercise(custom)} disabled={!custom.trim()}>
              <Plus size={16} />
            </button>
          </div>
          <div className="max-h-[40vh] space-y-3 overflow-y-auto pr-1">
            {grouped.map(([muscle, list]) => (
              <div key={muscle}>
                <div className="mb-1.5 text-xs font-semibold text-content-lo">
                  {MUSCLE_META[muscle as keyof typeof MUSCLE_META].emoji}{" "}
                  {MUSCLE_META[muscle as keyof typeof MUSCLE_META].label}
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {list.map((e) => (
                    <button key={e.id} className="chip bg-surface-base hover:border-accent" onClick={() => addExercise(e.name)}>
                      {e.name}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          {exercises.length > 0 && (
            <button className="btn-ghost w-full justify-center" onClick={() => setPicking(false)}>
              Retour à ma séance
            </button>
          )}
        </div>
      </Screen>
    );
  }

  return (
    <Screen emoji="💪" title="Ta séance" subtitle="Ajuste tes séries — les valeurs sont pré-remplies.">
      <div className="space-y-3">
        {exercises.map((ex, i) => (
          <div key={i} className="rounded-2xl border border-surface-line bg-surface-base p-3">
            <div className="mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5 font-semibold text-content-hi">
                <Dumbbell size={15} style={{ color: "rgb(var(--accent))" }} /> {ex.name}
              </span>
              <button
                className="btn-ghost !p-1 text-content-lo hover:text-red-400"
                onClick={() => setExercises((e) => e.filter((_, k) => k !== i))}
              >
                <Trash2 size={15} />
              </button>
            </div>
            <div className="space-y-1.5">
              {ex.sets.map((set, j) => (
                <div key={j} className="flex items-center gap-2 text-sm">
                  <span className="w-6 text-xs text-content-lo">{j + 1}.</span>
                  <input
                    type="number"
                    inputMode="numeric"
                    value={set.reps}
                    onChange={(e) =>
                      setExercises((ex2) =>
                        ex2.map((x, k) =>
                          k === i
                            ? { ...x, sets: x.sets.map((s, l) => (l === j ? { ...s, reps: Number(e.target.value) } : s)) }
                            : x,
                        ),
                      )
                    }
                    className="input !py-1.5 w-16 text-center"
                  />
                  <span className="text-content-lo">×</span>
                  <input
                    type="number"
                    inputMode="numeric"
                    value={set.weight}
                    onChange={(e) =>
                      setExercises((ex2) =>
                        ex2.map((x, k) =>
                          k === i
                            ? { ...x, sets: x.sets.map((s, l) => (l === j ? { ...s, weight: Number(e.target.value) } : s)) }
                            : x,
                        ),
                      )
                    }
                    className="input !py-1.5 w-16 text-center"
                  />
                  <span className="text-content-lo">kg</span>
                  {ex.sets.length > 1 && (
                    <button
                      className="btn-ghost !p-1 text-content-lo hover:text-red-400"
                      onClick={() =>
                        setExercises((ex2) =>
                          ex2.map((x, k) => (k === i ? { ...x, sets: x.sets.filter((_, l) => l !== j) } : x)),
                        )
                      }
                    >
                      <X size={13} />
                    </button>
                  )}
                </div>
              ))}
              <button
                className="btn-ghost !py-1 text-xs"
                onClick={() =>
                  setExercises((ex2) =>
                    ex2.map((x, k) =>
                      k === i ? { ...x, sets: [...x.sets, x.sets.at(-1) ?? { reps: 10, weight: 20 }] } : x,
                    ),
                  )
                }
              >
                <Plus size={12} /> Série
              </button>
            </div>
          </div>
        ))}
        <button className="btn-outline w-full justify-center" onClick={() => setPicking(true)}>
          <Plus size={15} /> Ajouter un exercice
        </button>
        <button className="btn-primary w-full justify-center !py-3" onClick={onNext}>
          {exercises.length ? "Séance terminée" : "Passer"}
        </button>
      </div>
    </Screen>
  );
}

// ---------- Résumé + analyse ----------
function Summary({ date, onClose }: { date: string; onClose: () => void }) {
  const { state } = useStore();
  const insights = useMemo(() => analyzeDay(state, date), [state, date]);

  return (
    <div className="text-center">
      <div className="mb-2 inline-flex items-center gap-2 rounded-full px-3 py-1 text-sm font-semibold"
        style={{ background: "rgb(var(--accent) / 0.14)", color: "rgb(var(--accent))" }}>
        <Sparkles size={15} /> Bilan enregistré
      </div>
      <h2 className="mt-2 text-xl font-bold text-content-hi">Ton analyse du jour</h2>

      <div className="mt-5 space-y-2.5 text-left">
        {insights.map((ins, i) => (
          <div
            key={i}
            className={`flex items-start gap-3 rounded-2xl border p-3.5 animate-slide-up ${
              INSIGHT_STYLE[ins.kind]
            }`}
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <span className="text-xl">{ins.icon}</span>
            <span className="text-sm text-content-hi">{ins.text}</span>
          </div>
        ))}
      </div>

      <div className="mt-6 flex items-center justify-center gap-2 text-sm text-content-mid">
        <Moon size={15} /> Repose-toi bien.
      </div>
      <button className="btn-primary mt-4 w-full justify-center !py-3 text-base" onClick={onClose}>
        <Check size={18} /> Terminer
      </button>
      <span className="sr-only">
        <Footprints />
      </span>
    </div>
  );
}

function addDaysStr(iso: string, n: number): string {
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(y, m - 1, d + n);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
}
