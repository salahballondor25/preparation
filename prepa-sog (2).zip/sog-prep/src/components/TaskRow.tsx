import { useState } from "react";
import { GripVertical, Pencil, Trash2, Clock, Bell } from "lucide-react";
import type { Task } from "../lib/types";
import { CATEGORY_META, PRIORITY_META, formatDuration } from "../lib/utils";

const STATUS_STYLE: Record<Task["status"], { ring: string; fill: string; label: string }> = {
  todo: { ring: "border-content-lo", fill: "transparent", label: "Pas commencé" },
  done: { ring: "border-emerald-500", fill: "#10b981", label: "Réussi" },
  failed: { ring: "border-red-500", fill: "#ef4444", label: "Raté" },
};

export function TaskRow({
  task,
  onCycle,
  onEdit,
  onRemove,
  drag,
}: {
  task: Task;
  onCycle: () => void;
  onEdit?: () => void;
  onRemove?: () => void;
  drag?: {
    onDragStart: () => void;
    onDragOver: (e: React.DragEvent) => void;
    onDrop: () => void;
    onDragEnd: () => void;
    dragging: boolean;
  };
}) {
  const [hover, setHover] = useState(false);
  const cat = CATEGORY_META[task.category];
  const prio = PRIORITY_META[task.priority];
  const st = STATUS_STYLE[task.status];

  return (
    <div
      draggable={!!drag}
      onDragStart={drag?.onDragStart}
      onDragOver={drag?.onDragOver}
      onDrop={drag?.onDrop}
      onDragEnd={drag?.onDragEnd}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      className={`group flex items-center gap-3 rounded-xl border border-surface-line bg-surface-base px-3 py-2.5 transition-all ${
        drag?.dragging ? "opacity-40" : "hover:border-surface-line/80"
      }`}
    >
      {drag && (
        <GripVertical
          size={16}
          className="shrink-0 cursor-grab text-content-lo opacity-0 transition-opacity group-hover:opacity-100 active:cursor-grabbing"
        />
      )}

      {/* Pastille de statut cliquable (⚪ → 🟢 → 🔴 → ⚪) */}
      <button
        onClick={onCycle}
        aria-label={`Statut : ${st.label}. Cliquer pour changer.`}
        className="grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 transition-transform active:scale-90"
        style={{ borderColor: st.fill === "transparent" ? undefined : st.fill }}
      >
        <span
          className={`block h-full w-full rounded-full border-2 ${st.ring} ${
            task.status !== "todo" ? "animate-pop" : ""
          }`}
          style={{ background: st.fill }}
        />
      </button>

      <div className="min-w-0 flex-1" onClick={onEdit} role={onEdit ? "button" : undefined}>
        <div
          className={`truncate text-sm font-medium ${
            task.status === "done"
              ? "text-content-lo line-through"
              : task.status === "failed"
                ? "text-content-mid line-through decoration-red-500/60"
                : "text-content-hi"
          }`}
        >
          {task.title}
        </div>
        <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-content-lo">
          <span style={{ color: cat.color }}>
            {cat.emoji} {cat.label}
          </span>
          {task.priority !== "normal" && (
            <span style={{ color: prio.color }}>• {prio.label}</span>
          )}
          {task.time && (
            <span className="inline-flex items-center gap-0.5">
              • <Clock size={11} /> {task.time}
            </span>
          )}
          {task.reminder && <Bell size={11} className="text-accent" />}
          {task.estimatedMin ? <span>• {formatDuration(task.estimatedMin)}</span> : null}
        </div>
      </div>

      {(hover || !onEdit) && (onEdit || onRemove) && (
        <div className="flex shrink-0 items-center gap-0.5">
          {onEdit && (
            <button className="btn-ghost !p-1.5" onClick={onEdit} aria-label="Modifier">
              <Pencil size={15} />
            </button>
          )}
          {onRemove && (
            <button
              className="btn-ghost !p-1.5 text-content-lo hover:text-red-400"
              onClick={onRemove}
              aria-label="Supprimer"
            >
              <Trash2 size={15} />
            </button>
          )}
        </div>
      )}
    </div>
  );
}
