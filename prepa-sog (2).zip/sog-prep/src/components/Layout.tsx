import { Suspense, useEffect, useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { PageFallback } from "./PageFallback";
import { Search, Flame, Menu, Download, Command } from "lucide-react";
import { NAV, MOBILE_PRIMARY } from "./nav";
import { CommandPalette } from "./CommandPalette";
import { useStore } from "../lib/store";
import { currentStreak } from "../lib/selectors";
import { levelFromXp } from "../lib/badges";

export function Layout() {
  const { state } = useStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [installEvt, setInstallEvt] = useState<any>(null);

  const streak = currentStreak(state.validatedDays);
  const level = levelFromXp(state.gamification.xp);

  // Capture de l'invite d'installation PWA
  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setInstallEvt(e);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  // Raccourcis clavier (PC)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement;
      const typing =
        el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.isContentEditable;

      // Palette : Cmd/Ctrl+K ou "/"
      if ((e.key === "k" && (e.metaKey || e.ctrlKey)) || (e.key === "/" && !typing)) {
        e.preventDefault();
        setPaletteOpen(true);
        return;
      }
      if (typing || e.metaKey || e.ctrlKey || e.altKey) return;

      // Navigation par touche unique
      const item = NAV.find((n) => n.key === e.key);
      if (item) {
        e.preventDefault();
        navigate(item.to);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [navigate]);

  useEffect(() => setMoreOpen(false), [location.pathname]);

  const doInstall = async () => {
    if (!installEvt) return;
    installEvt.prompt();
    await installEvt.userChoice;
    setInstallEvt(null);
  };

  const mobileTabs = NAV.filter((n) => MOBILE_PRIMARY.includes(n.to));

  return (
    <div className="min-h-screen">
      {/* ============ Sidebar (desktop) ============ */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-surface-line bg-surface-card/60 p-4 lg:flex">
        <div className="flex items-center gap-2.5 px-2 py-1">
          <div
            className="grid h-9 w-9 place-items-center rounded-xl font-black text-white"
            style={{ background: "rgb(var(--accent))" }}
          >
            S
          </div>
          <div className="leading-tight">
            <div className="text-sm font-semibold text-content-hi">Préparation</div>
            <div className="text-xs text-content-lo">{state.settings.objectiveTitle}</div>
          </div>
        </div>

        <button
          onClick={() => setPaletteOpen(true)}
          className="mt-5 flex items-center gap-2 rounded-xl border border-surface-line bg-surface-base px-3 py-2 text-sm text-content-lo transition-colors hover:text-content-mid"
        >
          <Search size={16} />
          <span className="flex-1 text-left">Rechercher…</span>
          <kbd className="flex items-center gap-0.5 rounded-md border border-surface-line px-1 py-0.5 text-[10px]">
            <Command size={10} /> K
          </kbd>
        </button>

        <nav className="mt-4 flex-1 space-y-0.5 overflow-y-auto">
          {NAV.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.to === "/"}
              className={({ isActive }) =>
                `group flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-accent-soft text-content-hi"
                    : "text-content-mid hover:bg-surface-raised hover:text-content-hi"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <n.icon
                    size={18}
                    className={isActive ? "" : "text-content-lo group-hover:text-content-mid"}
                    style={isActive ? { color: "rgb(var(--accent))" } : undefined}
                  />
                  <span className="flex-1">{n.label}</span>
                  {n.key && (
                    <kbd className="hidden rounded border border-surface-line px-1 text-[10px] text-content-lo group-hover:inline">
                      {n.key === "," ? "⌥," : n.key.toUpperCase()}
                    </kbd>
                  )}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Streak + niveau */}
        <div className="mt-3 space-y-2">
          {installEvt && (
            <button onClick={doInstall} className="btn-outline w-full">
              <Download size={16} /> Installer l'app
            </button>
          )}
          <div className="flex items-center gap-3 rounded-xl border border-surface-line bg-surface-base px-3 py-2.5">
            <div className="flex items-center gap-1.5 text-sm font-semibold text-content-hi">
              <Flame size={16} className="text-orange-400" /> {streak}j
            </div>
            <div className="h-4 w-px bg-surface-line" />
            <div className="text-sm text-content-mid">
              Niv. <span className="font-semibold text-content-hi">{level.level}</span>
            </div>
          </div>
        </div>
      </aside>

      {/* ============ Barre supérieure (mobile) ============ */}
      <header className="glass sticky top-0 z-20 flex items-center gap-3 px-4 py-3 lg:hidden">
        <div
          className="grid h-8 w-8 place-items-center rounded-lg font-black text-white"
          style={{ background: "rgb(var(--accent))" }}
        >
          S
        </div>
        <button
          onClick={() => setPaletteOpen(true)}
          className="flex flex-1 items-center gap-2 rounded-xl border border-surface-line bg-surface-base px-3 py-2 text-sm text-content-lo"
        >
          <Search size={16} /> Rechercher…
        </button>
        <div className="flex items-center gap-1 rounded-lg bg-surface-raised px-2 py-1.5 text-sm font-semibold text-content-hi">
          <Flame size={14} className="text-orange-400" />
          {streak}
        </div>
      </header>

      {/* ============ Contenu ============ */}
      <main className="lg:pl-64">
        <div className="mx-auto max-w-5xl px-4 pb-28 pt-5 lg:px-8 lg:pb-12 lg:pt-8">
          <Suspense fallback={<PageFallback />}>
            <Outlet />
          </Suspense>
        </div>
      </main>

      {/* ============ Navigation basse (mobile) ============ */}
      <nav className="glass fixed inset-x-0 bottom-0 z-30 flex items-stretch justify-around px-1 pb-[env(safe-area-inset-bottom)] lg:hidden">
        {mobileTabs.map((n) => (
          <NavLink
            key={n.to}
            to={n.to}
            end={n.to === "/"}
            className={({ isActive }) =>
              `flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[10px] font-medium transition-colors ${
                isActive ? "" : "text-content-lo"
              }`
            }
            style={({ isActive }) => (isActive ? { color: "rgb(var(--accent))" } : undefined)}
          >
            <n.icon size={22} />
            {n.label.split(" ")[0]}
          </NavLink>
        ))}
        <button
          onClick={() => setMoreOpen(true)}
          className="flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[10px] font-medium text-content-lo"
        >
          <Menu size={22} />
          Plus
        </button>
      </nav>

      {/* Feuille "Plus" (mobile) */}
      {moreOpen && (
        <div
          className="fixed inset-0 z-40 flex items-end bg-black/60 backdrop-blur-sm lg:hidden animate-fade-in"
          onClick={() => setMoreOpen(false)}
        >
          <div
            className="glass w-full rounded-t-3xl p-4 pb-8 animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-surface-line" />
            <div className="grid grid-cols-3 gap-2">
              {NAV.map((n) => (
                <NavLink
                  key={n.to}
                  to={n.to}
                  end={n.to === "/"}
                  className="flex flex-col items-center gap-1.5 rounded-2xl border border-surface-line bg-surface-base p-4 text-xs font-medium text-content-mid"
                >
                  <n.icon size={22} style={{ color: "rgb(var(--accent))" }} />
                  {n.label}
                </NavLink>
              ))}
            </div>
            {installEvt && (
              <button onClick={doInstall} className="btn-outline mt-3 w-full">
                <Download size={16} /> Installer l'application
              </button>
            )}
          </div>
        </div>
      )}

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} />
    </div>
  );
}
