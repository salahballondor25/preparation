import { useState, type ReactNode } from "react";
import { User, Lock, Eye, EyeOff, ArrowRight, ShieldCheck } from "lucide-react";
import { useAuth } from "../lib/authStore";
import type { AuthUser } from "../lib/auth";
import { InstallButton } from "./InstallButton";

export function AuthGate({ children }: { children: (user: AuthUser) => ReactNode }) {
  const { user, ready } = useAuth();
  if (!ready) return <Splash />;
  if (!user) return <AuthScreen />;
  return <>{children(user)}</>;
}

function Splash() {
  return (
    <div className="grid min-h-screen place-items-center bg-surface-base">
      <div className="grid h-12 w-12 animate-pulse place-items-center rounded-2xl font-black text-white" style={{ background: "rgb(var(--accent))" }}>
        S
      </div>
    </div>
  );
}

function AuthScreen() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError(null);
    if (mode === "signup" && password !== confirm) {
      setError("Les mots de passe ne correspondent pas.");
      return;
    }
    setBusy(true);
    const r = mode === "login" ? await signIn(username, password) : await signUp(username, password);
    setBusy(false);
    if (!r.ok) setError(r.error ?? "Une erreur est survenue.");
  };

  return (
    <div className="grid min-h-screen place-items-center bg-surface-base px-5 py-10">
      <div className="w-full max-w-sm">
        {/* Logo + titre */}
        <div className="mb-8 text-center">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl text-2xl font-black text-white" style={{ background: "rgb(var(--accent))" }}>
            S
          </div>
          <h1 className="mt-4 text-2xl font-bold text-content-hi">Préparation SOG</h1>
          <p className="mt-1 text-sm text-content-mid">
            {mode === "login" ? "Connecte-toi pour retrouver ta progression." : "Crée ton compte pour sauvegarder ta progression."}
          </p>
        </div>

        {/* Onglets */}
        <div className="mb-5 grid grid-cols-2 gap-1 rounded-xl border border-surface-line bg-surface-card p-1">
          {(["login", "signup"] as const).map((m) => (
            <button
              key={m}
              onClick={() => { setMode(m); setError(null); }}
              className="rounded-lg py-2 text-sm font-medium transition-colors"
              style={{
                background: mode === m ? "rgb(var(--accent))" : "transparent",
                color: mode === m ? "#fff" : "rgb(var(--content-mid))",
              }}
            >
              {m === "login" ? "Se connecter" : "Créer un compte"}
            </button>
          ))}
        </div>

        <div className="card space-y-3 p-5">
          <label className="block">
            <span className="label mb-1.5 block">Pseudo</span>
            <div className="relative">
              <User size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-content-lo" />
              <input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoCapitalize="none"
                autoComplete="username"
                placeholder="ton_pseudo"
                className="input !pl-9"
                onKeyDown={(e) => e.key === "Enter" && submit()}
              />
            </div>
          </label>

          <label className="block">
            <span className="label mb-1.5 block">Mot de passe</span>
            <div className="relative">
              <Lock size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-content-lo" />
              <input
                type={show ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete={mode === "login" ? "current-password" : "new-password"}
                placeholder="••••••"
                className="input !pl-9 !pr-9"
                onKeyDown={(e) => e.key === "Enter" && submit()}
              />
              <button type="button" onClick={() => setShow((s) => !s)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-content-lo hover:text-content-mid">
                {show ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </label>

          {mode === "signup" && (
            <label className="block">
              <span className="label mb-1.5 block">Confirmer le mot de passe</span>
              <div className="relative">
                <Lock size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-content-lo" />
                <input
                  type={show ? "text" : "password"}
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  autoComplete="new-password"
                  placeholder="••••••"
                  className="input !pl-9"
                  onKeyDown={(e) => e.key === "Enter" && submit()}
                />
              </div>
            </label>
          )}

          {error && (
            <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-400">
              {error}
            </div>
          )}

          <button className="btn-primary w-full justify-center !py-2.5" onClick={submit} disabled={busy || !username || !password}>
            {busy ? "…" : mode === "login" ? "Se connecter" : "Créer mon compte"}
            {!busy && <ArrowRight size={16} />}
          </button>
        </div>

        <div className="mt-4 flex items-start gap-2 px-1 text-xs text-content-lo">
          <ShieldCheck size={14} className="mt-0.5 shrink-0" />
          <p>
            Ton compte et tes données sont enregistrés sur cet appareil. Pour les retrouver sur un autre
            téléphone/PC, active la synchro (voir README).
          </p>
        </div>

        <div className="mt-5">
          <InstallButton variant="compact" />
        </div>
      </div>
    </div>
  );
}
