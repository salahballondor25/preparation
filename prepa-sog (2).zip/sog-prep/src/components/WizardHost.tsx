import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { EveningWizard } from "./EveningWizard";
import { useStore } from "../lib/store";
import { todayISO } from "../lib/utils";

interface WizardCtx {
  open: () => void;
  close: () => void;
  isOpen: boolean;
  doneToday: boolean;
}
const Ctx = createContext<WizardCtx | null>(null);

const DISMISS_KEY = "prepa-sog:wizardDismissed";

export function WizardProvider({ children }: { children: ReactNode }) {
  const { state, ready } = useStore();
  const [isOpen, setOpen] = useState(false);
  const today = todayISO();
  const doneToday = state.dailyLogs.some((l) => l.date === today);

  // Ouverture automatique le soir (une fois par jour, si non fait et non ignoré).
  useEffect(() => {
    if (!ready) return;
    if (!state.settings.autoWizard || doneToday) return;
    const hour = new Date().getHours();
    if (hour < state.settings.eveningHour) return;
    const dismissed = sessionStorage.getItem(DISMISS_KEY) === today;
    if (dismissed) return;
    const t = setTimeout(() => setOpen(true), 900);
    return () => clearTimeout(t);
  }, [ready, doneToday, state.settings.autoWizard, state.settings.eveningHour, today]);

  const close = () => {
    setOpen(false);
    sessionStorage.setItem(DISMISS_KEY, today);
  };

  return (
    <Ctx.Provider value={{ open: () => setOpen(true), close, isOpen, doneToday }}>
      {children}
      <EveningWizard open={isOpen} onClose={close} />
    </Ctx.Provider>
  );
}

export function useWizard(): WizardCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useWizard doit être utilisé dans <WizardProvider>");
  return ctx;
}
