import { useEffect, type ReactNode } from "react";
import { X } from "lucide-react";
import { clamp } from "../../lib/utils";

// ---- Barre de progression ----
export function ProgressBar({
  value,
  max = 100,
  className = "",
  color,
  height = 8,
}: {
  value: number;
  max?: number;
  className?: string;
  color?: string;
  height?: number;
}) {
  const p = clamp(max === 0 ? 0 : (value / max) * 100, 0, 100);
  return (
    <div
      className={`w-full overflow-hidden rounded-full bg-surface-line/60 ${className}`}
      style={{ height }}
      role="progressbar"
      aria-valuenow={Math.round(p)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className="h-full rounded-full transition-[width] duration-500 ease-out"
        style={{
          width: `${p}%`,
          background: color ?? "rgb(var(--accent))",
        }}
      />
    </div>
  );
}

// ---- Anneau de progression (dashboard) ----
export function Ring({
  percent,
  size = 128,
  stroke = 10,
  children,
}: {
  percent: number;
  size?: number;
  stroke?: number;
  children?: ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const p = clamp(percent, 0, 100);
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="rgb(var(--surface-line))"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="rgb(var(--accent))"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (p / 100) * c}
          style={{ transition: "stroke-dashoffset 0.7s cubic-bezier(0.16,1,0.3,1)" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

// ---- Carte statistique ----
export function StatCard({
  icon,
  label,
  value,
  sub,
  accent,
}: {
  icon?: ReactNode;
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  accent?: string;
}) {
  return (
    <div className="card p-4 animate-fade-in">
      <div className="flex items-center gap-2 text-content-lo">
        {icon && (
          <span
            className="grid h-8 w-8 place-items-center rounded-lg"
            style={{ background: (accent ?? "rgb(var(--accent))") + "22", color: accent ?? "rgb(var(--accent))" }}
          >
            {icon}
          </span>
        )}
        <span className="label">{label}</span>
      </div>
      <div className="mt-2 text-2xl font-bold tnum text-content-hi">{value}</div>
      {sub && <div className="mt-0.5 text-xs text-content-mid">{sub}</div>}
    </div>
  );
}

// ---- Contrôle segmenté ----
export function Segmented<T extends string>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string }[];
}) {
  return (
    <div className="inline-flex rounded-xl border border-surface-line bg-surface-base p-1">
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className={`rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
            value === o.value
              ? "bg-surface-raised text-content-hi shadow-sm"
              : "text-content-mid hover:text-content-hi"
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

// ---- Modale ----
export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 grid place-items-end sm:place-items-center bg-black/60 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div
        className="glass w-full sm:max-w-lg rounded-t-3xl sm:rounded-3xl p-5 shadow-pop animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-content-hi">{title}</h3>
          <button className="btn-ghost !p-2" onClick={onClose} aria-label="Fermer">
            <X size={18} />
          </button>
        </div>
        <div className="max-h-[70vh] overflow-y-auto">{children}</div>
        {footer && <div className="mt-5 flex justify-end gap-2">{footer}</div>}
      </div>
    </div>
  );
}

// ---- État vide ----
export function EmptyState({
  icon,
  title,
  hint,
  action,
}: {
  icon?: ReactNode;
  title: string;
  hint?: string;
  action?: ReactNode;
}) {
  return (
    <div className="card grid place-items-center gap-2 p-10 text-center">
      {icon && <div className="text-content-lo">{icon}</div>}
      <p className="font-medium text-content-hi">{title}</p>
      {hint && <p className="max-w-xs text-sm text-content-mid">{hint}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}
