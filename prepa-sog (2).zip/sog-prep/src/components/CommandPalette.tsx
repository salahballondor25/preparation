import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, CornerDownLeft } from "lucide-react";
import { useStore } from "../lib/store";
import { NAV } from "./nav";
import { CATEGORY_META, formatDayLabel, fromISO } from "../lib/utils";

interface Result {
  id: string;
  icon: string;
  label: string;
  hint: string;
  action: () => void;
}

export function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { state } = useStore();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setQ("");
      setActive(0);
      setTimeout(() => inputRef.current?.focus(), 10);
    }
  }, [open]);

  const results = useMemo<Result[]>(() => {
    const query = q.trim().toLowerCase();
    const go = (to: string) => () => {
      navigate(to);
      onClose();
    };

    // Pages
    const pages: Result[] = NAV.map((n) => ({
      id: "page:" + n.to,
      icon: "→",
      label: n.label,
      hint: "Aller à la page",
      action: go(n.to),
    }));

    if (!query) return pages;

    const match = (s: string) => s.toLowerCase().includes(query);
    const out: Result[] = [];

    for (const p of pages) if (match(p.label)) out.push(p);

    for (const t of state.tasks)
      if (match(t.title))
        out.push({
          id: "task:" + t.id,
          icon: CATEGORY_META[t.category].emoji,
          label: t.title,
          hint: `Tâche · ${formatDayLabel(t.date)}`,
          action: go("/calendrier"),
        });

    for (const s of state.shopping)
      if (match(s.name))
        out.push({
          id: "shop:" + s.id,
          icon: "🛒",
          label: s.name,
          hint: "Liste de courses",
          action: go("/courses"),
        });

    for (const n of state.notes)
      if (match(n.title) || match(n.body))
        out.push({
          id: "note:" + n.id,
          icon: "📝",
          label: n.title,
          hint: "Note",
          action: go("/notes"),
        });

    for (const s of state.strength)
      if (match(s.title))
        out.push({
          id: "str:" + s.id,
          icon: "🏋️",
          label: s.title,
          hint: `Séance · ${formatDayLabel(s.date)}`,
          action: go("/entrainement"),
        });

    // Recherche par date (ex : "15/03" ou "2025-03-15")
    if (/\d/.test(query)) {
      const iso = state.tasks.find((t) => t.date.includes(query))?.date;
      if (iso)
        out.push({
          id: "date:" + iso,
          icon: "📅",
          label: formatDayLabel(iso),
          hint: "Ouvrir la journée",
          action: go("/calendrier"),
        });
    }

    return out.slice(0, 20);
  }, [q, state, navigate, onClose]);

  useEffect(() => setActive(0), [q]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActive((a) => Math.min(a + 1, results.length - 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setActive((a) => Math.max(a - 1, 0));
      } else if (e.key === "Enter") {
        e.preventDefault();
        results[active]?.action();
      } else if (e.key === "Escape") {
        onClose();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, results, active, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-start justify-center bg-black/60 backdrop-blur-sm p-4 pt-[12vh] animate-fade-in"
      onClick={onClose}
    >
      <div
        className="glass w-full max-w-xl overflow-hidden rounded-2xl shadow-pop animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 border-b border-surface-line px-4">
          <Search size={18} className="text-content-lo" />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Rechercher une tâche, une course, une note, une date…"
            className="w-full bg-transparent py-4 text-content-hi placeholder:text-content-lo focus:outline-none"
          />
          <kbd className="hidden sm:block rounded-md border border-surface-line px-1.5 py-0.5 text-[10px] text-content-lo">
            ESC
          </kbd>
        </div>
        <div className="max-h-[50vh] overflow-y-auto p-2">
          {results.length === 0 && (
            <div className="px-3 py-8 text-center text-sm text-content-lo">Aucun résultat</div>
          )}
          {results.map((r, i) => (
            <button
              key={r.id}
              onMouseEnter={() => setActive(i)}
              onClick={r.action}
              className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors ${
                i === active ? "bg-accent-soft" : "hover:bg-surface-raised"
              }`}
            >
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-surface-raised text-sm">
                {r.icon}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-medium text-content-hi">{r.label}</span>
                <span className="block truncate text-xs text-content-lo">{r.hint}</span>
              </span>
              {i === active && <CornerDownLeft size={14} className="text-content-lo" />}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
