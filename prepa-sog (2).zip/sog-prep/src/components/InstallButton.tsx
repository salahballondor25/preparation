import { useEffect, useState } from "react";
import { Download, Check, Share, Plus } from "lucide-react";

interface BIPEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: string }>;
}

function isStandalone() {
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    // iOS Safari
    (navigator as unknown as { standalone?: boolean }).standalone === true
  );
}

export function InstallButton({ variant = "full" }: { variant?: "full" | "compact" }) {
  const [evt, setEvt] = useState<BIPEvent | null>(null);
  const [installed, setInstalled] = useState(isStandalone());

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setEvt(e as BIPEvent);
    };
    const onInstalled = () => setInstalled(true);
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  const ua = navigator.userAgent;
  const isIOS = /iphone|ipad|ipod/i.test(ua);

  if (installed) {
    return (
      <div className="flex items-center gap-2 text-sm text-emerald-400">
        <Check size={16} /> Application installée sur cet appareil.
      </div>
    );
  }

  // Android / Chrome / Edge desktop : invite native disponible.
  if (evt) {
    const install = async () => {
      await evt.prompt();
      await evt.userChoice;
      setEvt(null);
    };
    return (
      <button className={variant === "compact" ? "btn-outline w-full" : "btn-primary"} onClick={install}>
        <Download size={16} /> Installer l'application
      </button>
    );
  }

  // iOS : pas d'invite native, on explique.
  if (isIOS) {
    return (
      <div className="rounded-xl border border-surface-line bg-surface-base p-3 text-sm text-content-mid">
        <p className="mb-1.5 font-medium text-content-hi">Installer sur iPhone / iPad</p>
        <p className="flex flex-wrap items-center gap-1.5">
          Appuie sur <Share size={15} className="inline" /> <b>Partager</b> en bas de Safari, puis
          <b>« Sur l'écran d'accueil »</b> <Plus size={14} className="inline" />.
        </p>
      </div>
    );
  }

  // Autres cas (déjà installable via le menu du navigateur).
  return (
    <div className="rounded-xl border border-surface-line bg-surface-base p-3 text-sm text-content-mid">
      <p className="mb-1 font-medium text-content-hi">Installer l'application</p>
      <p>
        Ouvre le menu de ton navigateur (⋮) puis <b>« Installer l'application »</b> ou{" "}
        <b>« Ajouter à l'écran d'accueil »</b>.
      </p>
    </div>
  );
}
