import {
  LayoutDashboard,
  Dumbbell,
  BookOpen,
  Scale,
  ShoppingCart,
  Target,
  BarChart3,
  StickyNote,
  Settings,
  type LucideIcon,
} from "lucide-react";

export interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  key?: string;
}

// Navigation simplifiée : le tableau de bord est le centre de commande.
export const NAV: NavItem[] = [
  { to: "/", label: "Tableau de bord", icon: LayoutDashboard, key: "d" },
  { to: "/entrainement", label: "Entraînement", icon: Dumbbell, key: "e" },
  { to: "/journal", label: "Journal", icon: BookOpen, key: "j" },
  { to: "/poids", label: "Poids", icon: Scale, key: "p" },
  { to: "/courses", label: "Courses", icon: ShoppingCart, key: "l" },
  { to: "/objectifs", label: "Objectifs", icon: Target, key: "o" },
  { to: "/stats", label: "Statistiques", icon: BarChart3, key: "s" },
  { to: "/notes", label: "Notes", icon: StickyNote, key: "n" },
  { to: "/parametres", label: "Paramètres", icon: Settings, key: "," },
];

// Barre du bas (mobile) : les 4 essentiels + tableau de bord.
export const MOBILE_PRIMARY = ["/", "/entrainement", "/journal", "/stats"];
