import { useEffect, useState } from "react";
import { Modal } from "./ui/Primitives";
import type { Category, Priority, Task } from "../lib/types";
import { CATEGORY_META, PRIORITY_META } from "../lib/utils";

export interface TaskDraft {
  title: string;
  category: Category;
  priority: Priority;
  date: string;
  time?: string;
  estimatedMin?: number;
  reminder?: boolean;
}

export function TaskEditor({
  open,
  onClose,
  onSave,
  initial,
  showDate = false,
  defaultDate,
}: {
  open: boolean;
  onClose: () => void;
  onSave: (draft: TaskDraft) => void;
  initial?: Task | null;
  showDate?: boolean;
  defaultDate: string;
}) {
  const [d, setD] = useState<TaskDraft>({
    title: "",
    category: "sport",
    priority: "normal",
    date: defaultDate,
  });

  useEffect(() => {
    if (open) {
      setD(
        initial
          ? {
              title: initial.title,
              category: initial.category,
              priority: initial.priority,
              date: initial.date,
              time: initial.time,
              estimatedMin: initial.estimatedMin,
              reminder: initial.reminder,
            }
          : { title: "", category: "sport", priority: "normal", date: defaultDate },
      );
    }
  }, [open, initial, defaultDate]);

  const save = () => {
    if (!d.title.trim()) return;
    onSave({ ...d, title: d.title.trim() });
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={initial ? "Modifier la tâche" : "Nouvelle tâche"}
      footer={
        <>
          <button className="btn-ghost" onClick={onClose}>
            Annuler
          </button>
          <button className="btn-primary" onClick={save} disabled={!d.title.trim()}>
            {initial ? "Enregistrer" : "Ajouter"}
          </button>
        </>
      }
    >
      <div className="space-y-4">
        <div>
          <label className="label mb-1.5 block">Intitulé</label>
          <input
            autoFocus
            value={d.title}
            onChange={(e) => setD({ ...d, title: e.target.value })}
            onKeyDown={(e) => e.key === "Enter" && save()}
            placeholder="Ex : Courir 5 km"
            className="input"
          />
        </div>

        <div>
          <label className="label mb-1.5 block">Catégorie</label>
          <div className="flex flex-wrap gap-1.5">
            {(Object.keys(CATEGORY_META) as Category[]).map((c) => {
              const m = CATEGORY_META[c];
              const active = d.category === c;
              return (
                <button
                  key={c}
                  onClick={() => setD({ ...d, category: c })}
                  className="chip border transition-colors"
                  style={{
                    borderColor: active ? m.color : "rgb(var(--surface-line))",
                    background: active ? m.color + "22" : "transparent",
                    color: active ? m.color : "rgb(var(--content-mid))",
                  }}
                >
                  {m.emoji} {m.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label mb-1.5 block">Priorité</label>
            <div className="flex gap-1.5">
              {(Object.keys(PRIORITY_META) as Priority[]).map((p) => {
                const m = PRIORITY_META[p];
                const active = d.priority === p;
                return (
                  <button
                    key={p}
                    onClick={() => setD({ ...d, priority: p })}
                    className="chip flex-1 justify-center border"
                    style={{
                      borderColor: active ? m.color : "rgb(var(--surface-line))",
                      background: active ? m.color + "22" : "transparent",
                      color: active ? m.color : "rgb(var(--content-mid))",
                    }}
                  >
                    {m.label}
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <label className="label mb-1.5 block">Heure</label>
            <input
              type="time"
              value={d.time ?? ""}
              onChange={(e) => setD({ ...d, time: e.target.value || undefined })}
              className="input"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {showDate && (
            <div>
              <label className="label mb-1.5 block">Date</label>
              <input
                type="date"
                value={d.date}
                onChange={(e) => setD({ ...d, date: e.target.value })}
                className="input"
              />
            </div>
          )}
          <div>
            <label className="label mb-1.5 block">Durée estimée (min)</label>
            <input
              type="number"
              min={0}
              value={d.estimatedMin ?? ""}
              onChange={(e) =>
                setD({ ...d, estimatedMin: e.target.value ? Number(e.target.value) : undefined })
              }
              placeholder="—"
              className="input"
            />
          </div>
        </div>

        <label className="flex items-center gap-2.5 text-sm text-content-mid">
          <input
            type="checkbox"
            checked={!!d.reminder}
            onChange={(e) => setD({ ...d, reminder: e.target.checked })}
            className="h-4 w-4 accent-[rgb(var(--accent))]"
          />
          Activer un rappel
        </label>
      </div>
    </Modal>
  );
}
