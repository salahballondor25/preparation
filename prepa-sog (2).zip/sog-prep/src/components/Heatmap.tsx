import { useMemo } from "react";
import { heatmap } from "../lib/selectors";
import { useStore } from "../lib/store";
import { formatDayLabel } from "../lib/utils";

const LEVEL_ALPHA = [0.06, 0.25, 0.45, 0.7, 1]; // 0..4

export function Heatmap({ weeks = 20 }: { weeks?: number }) {
  const { state } = useStore();
  const { cells } = useMemo(() => heatmap(state, weeks), [state, weeks]);

  // Organiser en colonnes de 7 (semaines)
  const columns: (typeof cells)[] = [];
  for (let i = 0; i < cells.length; i += 7) columns.push(cells.slice(i, i + 7));

  const dayLabels = ["L", "", "M", "", "J", "", "D"];

  return (
    <div className="flex gap-2 overflow-x-auto pb-1">
      <div className="flex flex-col gap-1 pt-0.5 text-[10px] text-content-lo">
        {dayLabels.map((d, i) => (
          <div key={i} className="h-3.5 leading-3.5">
            {d}
          </div>
        ))}
      </div>
      <div className="flex gap-1">
        {columns.map((col, ci) => (
          <div key={ci} className="flex flex-col gap-1">
            {col.map((cell) => {
              if (cell.level < 0)
                return <div key={cell.date} className="h-3.5 w-3.5 rounded-[3px] opacity-0" />;
              return (
                <div
                  key={cell.date}
                  title={`${formatDayLabel(cell.date)} — ${cell.percent}% (${cell.count} réussie${cell.count > 1 ? "s" : ""})`}
                  className="h-3.5 w-3.5 rounded-[3px] transition-transform hover:scale-125"
                  style={{
                    background:
                      cell.level === 0
                        ? "rgb(var(--surface-line) / 0.5)"
                        : `rgb(var(--accent) / ${LEVEL_ALPHA[cell.level]})`,
                  }}
                />
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

export function HeatmapLegend() {
  return (
    <div className="flex items-center gap-1.5 text-xs text-content-lo">
      <span>Moins</span>
      {LEVEL_ALPHA.map((a, i) => (
        <div
          key={i}
          className="h-3 w-3 rounded-[3px]"
          style={{ background: i === 0 ? "rgb(var(--surface-line) / 0.5)" : `rgb(var(--accent) / ${a})` }}
        />
      ))}
      <span>Plus</span>
    </div>
  );
}
